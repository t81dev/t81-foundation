(module
 (type $0 (func (param i64 i64 i64 i64) (result i64)))
 (memory $0 1)
 (export "memory" (memory $0))
 (export "run" (func $0))
 (func $0 (param $0 i64) (param $1 i64) (param $2 i64) (param $3 i64) (result i64)
  (block $block1
   (return
    (i64.extend_i32_u
     (block $block (result i32)
      (if
       (i64.eqz
        (local.get $0)
       )
       (then
        (drop
         (br_if $block
          (i32.const 0)
          (i64.eqz
           (local.get $1)
          )
         )
        )
        (br_if $block1
         (i64.eqz
          (local.get $3)
         )
        )
        (br $block
         (i64.eq
          (select
           (local.get $3)
           (i64.const 0)
           (i64.lt_u
            (i64.add
             (local.get $3)
             (i64.const 1)
            )
            (i64.const 3)
           )
          )
          (local.get $2)
         )
        )
       )
      )
      (drop
       (br_if $block
        (i32.const 1)
        (i32.eqz
         (i64.eqz
          (local.get $1)
         )
        )
       )
      )
      (br_if $block1
       (i64.eqz
        (local.get $3)
       )
      )
      (i64.eq
       (select
        (local.get $3)
        (i64.const 0)
        (i64.lt_u
         (i64.add
          (local.get $3)
          (i64.const 1)
         )
         (i64.const 3)
        )
       )
       (local.get $2)
      )
     )
    )
   )
  )
  (unreachable)
 )
)

