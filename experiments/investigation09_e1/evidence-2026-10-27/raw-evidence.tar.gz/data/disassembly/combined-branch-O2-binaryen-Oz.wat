(module
 (type $0 (func (param i64 i64 i64 i64) (result i64)))
 (memory $0 1)
 (export "memory" (memory $0))
 (export "run" (func $0))
 (func $0 (param $0 i64) (param $1 i64) (param $2 i64) (param $3 i64) (result i64)
  (i64.add
   (block $block3 (result i64)
    (if
     (i64.le_u
      (local.get $0)
      (i64.const 2)
     )
     (then
      (block $block1
       (block $block
        (block $block2
         (br_table $block $block1 $block2
          (i32.sub
           (i32.wrap_i64
            (local.get $0)
           )
           (i32.const 1)
          )
         )
        )
        (br $block3
         (i64.sub
          (i64.const 0)
          (local.get $1)
         )
        )
       )
       (br $block3
        (select
         (local.get $1)
         (local.get $2)
         (i64.lt_s
          (local.get $1)
          (local.get $2)
         )
        )
       )
      )
      (br $block3
       (select
        (local.get $1)
        (local.get $2)
        (i64.gt_s
         (local.get $1)
         (local.get $2)
        )
       )
      )
     )
    )
    (i64.add
     (i64.add
      (i64.add
       (i64.mul
        (local.get $3)
        (i64.const -3)
       )
       (i64.mul
        (local.tee $0
         (select
          (local.get $1)
          (local.get $2)
          (i64.lt_s
           (local.get $1)
           (local.get $2)
          )
         )
        )
        (i64.const 9)
       )
      )
      (select
       (local.get $0)
       (local.tee $1
        (i64.sub
         (i64.const 0)
         (local.get $3)
        )
       )
       (i64.gt_s
        (local.get $0)
        (local.get $1)
       )
      )
     )
     (i64.const 12)
    )
   )
   (i64.const 1)
  )
 )
)

