(module
 (type $0 (func (param i64 i64 i64 i64) (result i64)))
 (global $global$0 (mut i32) (i32.const 65536))
 (memory $0 2)
 (data $0 (i32.const 65536) "\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\ff\ff\ff\ff\ff\ff\ff\ff\00\00\00\00\00\00\00\00\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\ff\ff\ff\ff\ff\ff\ff\ff\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\ff\ff\ff\ff\ff\ff\ff\ff\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00")
 (export "memory" (memory $0))
 (export "run" (func $0))
 (func $0 (param $0 i64) (param $1 i64) (param $2 i64) (param $3 i64) (result i64)
  (block $block4
   (block $block
    (br_if $block
     (i64.gt_u
      (local.get $0)
      (i64.const 2)
     )
    )
    (block $block3
     (block $block2
      (block $block1
       (br_table $block1 $block2 $block3 $block1
        (i32.wrap_i64
         (local.get $0)
        )
       )
      )
      (local.set $0
       (i64.load
        (i32.add
         (i32.shl
          (i32.wrap_i64
           (local.get $1)
          )
          (i32.const 3)
         )
         (i32.const 65544)
        )
       )
      )
      (br $block4)
     )
     (local.set $0
      (i64.load
       (i32.add
        (i32.shl
         (i32.wrap_i64
          (i64.add
           (i64.mul
            (local.get $1)
            (i64.const 3)
           )
           (local.get $2)
          )
         )
         (i32.const 3)
        )
        (i32.const 65600)
       )
      )
     )
     (br $block4)
    )
    (local.set $0
     (i64.load
      (i32.add
       (i32.shl
        (i32.wrap_i64
         (i64.add
          (i64.mul
           (local.get $1)
           (i64.const 3)
          )
          (local.get $2)
         )
        )
        (i32.const 3)
       )
       (i32.const 65680)
      )
     )
    )
    (br $block4)
   )
   (local.set $0
    (i64.add
     (i64.add
      (i64.add
       (i64.mul
        (local.tee $0
         (i64.load
          (i32.add
           (i32.shl
            (i32.wrap_i64
             (i64.add
              (i64.mul
               (local.get $1)
               (i64.const 3)
              )
              (local.get $2)
             )
            )
            (i32.const 3)
           )
           (i32.const 65600)
          )
         )
        )
        (i64.const 9)
       )
       (i64.mul
        (local.tee $1
         (i64.load
          (i32.add
           (i32.shl
            (i32.wrap_i64
             (local.get $3)
            )
            (i32.const 3)
           )
           (i32.const 65544)
          )
         )
        )
        (i64.const 3)
       )
      )
      (i64.load
       (i32.add
        (i32.shl
         (i32.wrap_i64
          (i64.add
           (i64.mul
            (local.get $0)
            (i64.const 3)
           )
           (local.get $1)
          )
         )
         (i32.const 3)
        )
        (i32.const 65680)
       )
      )
     )
     (i64.const 12)
    )
   )
  )
  (i64.add
   (local.get $0)
   (i64.const 1)
  )
 )
)

