(module
 (type $0 (func (param i64 i64 i64 i64) (result i64)))
 (global $global$0 (mut i32) (i32.const 65536))
 (memory $0 1)
 (export "memory" (memory $0))
 (export "run" (func $0))
 (func $0 (param $0 i64) (param $1 i64) (param $2 i64) (param $3 i64) (result i64)
  (i64.add
   (select
    (local.get $1)
    (local.get $2)
    (i64.lt_s
     (local.get $1)
     (local.get $2)
    )
   )
   (i64.const 1)
  )
 )
)

