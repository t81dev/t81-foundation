(module
 (type $0 (func (param i64 i64 i64 i64) (result i64)))
 (memory $0 2)
 (data $0 (i32.const 65536) "\01")
 (data $1 (i32.const 65552) "\ff\ff\ff\ff\ff\ff\ff\ff\00\00\00\00\00\00\00\00\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff")
 (data $2 (i32.const 65616) "\ff\ff\ff\ff\ff\ff\ff\ff\00\00\00\00\00\00\00\00\01")
 (data $3 (i32.const 65648) "\ff\ff\ff\ff\ff\ff\ff\ff\00\00\00\00\00\00\00\00\01")
 (data $4 (i32.const 65688) "\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01")
 (export "memory" (memory $0))
 (export "run" (func $0))
 (func $0 (param $0 i64) (param $1 i64) (param $2 i64) (param $3 i64) (result i64)
  (i64.add
   (block $block3 (result i64)
    (if
     (i64.le_u
      (local.get $0)
      (i64.const 2)
     )
     (then
      (block $block1
       (block $block
        (block $block2
         (br_table $block $block1 $block2
          (i32.sub
           (i32.wrap_i64
            (local.get $0)
           )
           (i32.const 1)
          )
         )
        )
        (br $block3
         (i64.load
          (i32.add
           (i32.shl
            (i32.wrap_i64
             (local.get $1)
            )
            (i32.const 3)
           )
           (i32.const 65544)
          )
         )
        )
       )
       (br $block3
        (i64.load
         (i32.add
          (i32.shl
           (i32.wrap_i64
            (i64.add
             (i64.mul
              (local.get $1)
              (i64.const 3)
             )
             (local.get $2)
            )
           )
           (i32.const 3)
          )
          (i32.const 65600)
         )
        )
       )
      )
      (br $block3
       (i64.load
        (i32.add
         (i32.shl
          (i32.wrap_i64
           (i64.add
            (i64.mul
             (local.get $1)
             (i64.const 3)
            )
            (local.get $2)
           )
          )
          (i32.const 3)
         )
         (i32.const 65680)
        )
       )
      )
     )
    )
    (i64.add
     (i64.add
      (i64.add
       (i64.mul
        (local.tee $0
         (i64.load
          (i32.add
           (i32.shl
            (i32.wrap_i64
             (i64.add
              (i64.mul
               (local.get $1)
               (i64.const 3)
              )
              (local.get $2)
             )
            )
            (i32.const 3)
           )
           (i32.const 65600)
          )
         )
        )
        (i64.const 9)
       )
       (i64.mul
        (local.tee $1
         (i64.load
          (i32.add
           (i32.shl
            (i32.wrap_i64
             (local.get $3)
            )
            (i32.const 3)
           )
           (i32.const 65544)
          )
         )
        )
        (i64.const 3)
       )
      )
      (i64.load
       (i32.add
        (i32.shl
         (i32.wrap_i64
          (i64.add
           (i64.mul
            (local.get $0)
            (i64.const 3)
           )
           (local.get $1)
          )
         )
         (i32.const 3)
        )
        (i32.const 65680)
       )
      )
     )
     (i64.const 12)
    )
   )
   (i64.const 1)
  )
 )
)

