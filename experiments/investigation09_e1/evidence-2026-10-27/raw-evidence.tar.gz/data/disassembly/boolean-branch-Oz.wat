(module
 (type $0 (func (param i64 i64 i64 i64) (result i64)))
 (global $global$0 (mut i32) (i32.const 65536))
 (memory $0 1)
 (export "memory" (memory $0))
 (export "run" (func $0))
 (func $0 (param $0 i64) (param $1 i64) (param $2 i64) (param $3 i64) (result i64)
  (local $4 i32)
  (block $block3
   (block $block2
    (block $block
     (br_if $block
      (i64.ne
       (local.get $0)
       (i64.const 0)
      )
     )
     (block $block1
      (br_if $block1
       (i32.eqz
        (i64.eqz
         (local.get $1)
        )
       )
      )
      (local.set $4
       (i32.const 0)
      )
      (br $block2)
     )
     (br_if $block3
      (i64.eq
       (local.get $3)
       (i64.const 0)
      )
     )
     (local.set $4
      (i64.eq
       (select
        (local.get $3)
        (i64.const 0)
        (i64.lt_u
         (i64.add
          (local.get $3)
          (i64.const 1)
         )
         (i64.const 3)
        )
       )
       (local.get $2)
      )
     )
     (br $block2)
    )
    (block $block4
     (br_if $block4
      (i64.eq
       (local.get $1)
       (i64.const 0)
      )
     )
     (local.set $4
      (i32.const 1)
     )
     (br $block2)
    )
    (br_if $block3
     (i64.eq
      (local.get $3)
      (i64.const 0)
     )
    )
    (local.set $4
     (i64.eq
      (select
       (local.get $3)
       (i64.const 0)
       (i64.lt_u
        (i64.add
         (local.get $3)
         (i64.const 1)
        )
        (i64.const 3)
       )
      )
      (local.get $2)
     )
    )
   )
   (return
    (i64.extend_i32_u
     (local.get $4)
    )
   )
  )
  (unreachable)
 )
)

