(module
 (type $0 (func (param i64 i64 i64 i64) (result i64)))
 (global $global$0 (mut i32) (i32.const 65536))
 (memory $0 1)
 (export "memory" (memory $0))
 (export "run" (func $0))
 (func $0 (param $0 i64) (param $1 i64) (param $2 i64) (param $3 i64) (result i64)
  (block $block4
   (block $block
    (br_if $block
     (i64.gt_u
      (local.get $0)
      (i64.const 2)
     )
    )
    (block $block3
     (block $block2
      (block $block1
       (br_table $block1 $block2 $block3 $block1
        (i32.wrap_i64
         (local.get $0)
        )
       )
      )
      (local.set $0
       (i64.sub
        (i64.const 0)
        (local.get $1)
       )
      )
      (br $block4)
     )
     (local.set $0
      (select
       (local.get $1)
       (local.get $2)
       (i64.lt_s
        (local.get $1)
        (local.get $2)
       )
      )
     )
     (br $block4)
    )
    (local.set $0
     (select
      (local.get $1)
      (local.get $2)
      (i64.gt_s
       (local.get $1)
       (local.get $2)
      )
     )
    )
    (br $block4)
   )
   (local.set $0
    (i64.add
     (i64.add
      (i64.add
       (i64.mul
        (local.get $3)
        (i64.const -3)
       )
       (i64.mul
        (local.tee $0
         (select
          (local.get $1)
          (local.get $2)
          (i64.lt_s
           (local.get $1)
           (local.get $2)
          )
         )
        )
        (i64.const 9)
       )
      )
      (select
       (local.get $0)
       (local.tee $1
        (i64.sub
         (i64.const 0)
         (local.get $3)
        )
       )
       (i64.gt_s
        (local.get $0)
        (local.get $1)
       )
      )
     )
     (i64.const 12)
    )
   )
  )
  (i64.add
   (local.get $0)
   (i64.const 1)
  )
 )
)

