(module
 (type $0 (func (param i64 i64 i64 i64) (result i64)))
 (global $global$0 (mut i32) (i32.const 65536))
 (memory $0 2)
 (data $0 (i32.const 65536) "\ff\ff\ff\ff\ff\ff\ff\ff\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00")
 (export "memory" (memory $0))
 (export "run" (func $0))
 (func $0 (param $0 i64) (param $1 i64) (param $2 i64) (param $3 i64) (result i64)
  (i64.add
   (i64.load
    (i32.add
     (i32.shl
      (i32.wrap_i64
       (i64.add
        (i64.mul
         (local.get $1)
         (i64.const 3)
        )
        (local.get $2)
       )
      )
      (i32.const 3)
     )
     (i32.const 65568)
    )
   )
   (i64.const 1)
  )
 )
)

