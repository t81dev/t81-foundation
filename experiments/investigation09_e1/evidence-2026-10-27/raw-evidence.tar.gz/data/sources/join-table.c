typedef long long V;
static const V lows[9]={-1,-1,-1,-1,0,0,-1,0,1};
static const V highs[9]={-1,0,1,0,0,1,1,1,1};
static const V negs[3]={1,0,-1};
static V lo(V a,V b){return lows[(a+1)*3+b+1];}
static V hi(V a,V b){return highs[(a+1)*3+b+1];}
static V neg(V a){return negs[a+1];}
__attribute__((visibility("default"))) V run(V k,V a,V b,V c){return hi(a,b)+1;}
