typedef long long V;
static V lo(V a,V b){return a<b?a:b;}
static V hi(V a,V b){return a>b?a:b;}
static V neg(V a){return -a;}
__attribute__((visibility("default"))) V run(V k,V a,V b,V c){return neg(a)+1;}
