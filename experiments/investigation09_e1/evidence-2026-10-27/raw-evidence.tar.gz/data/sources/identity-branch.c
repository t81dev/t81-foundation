typedef long long V;
static V lo(V a,V b){if(a<b)return a;return b;}
static V hi(V a,V b){if(a>b)return a;return b;}
static V neg(V a){return -a;}
__attribute__((visibility("default"))) V run(V k,V a,V b,V c){return a;}
