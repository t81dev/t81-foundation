#include <bit>
#include "arch003/evidence.hpp"
namespace arch003 {
Sha256::Sha256()
    : h_{0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
         0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19} {}
void Sha256::compress() {
  constexpr std::uint32_t k[] = {
      0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4,
      0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe,
      0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f,
      0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
      0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
      0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b,
      0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116,
      0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
      0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7,
      0xc67178f2};
  std::uint32_t w[64]{};
  for (unsigned i = 0; i < 16; ++i)
    for (unsigned j = 0; j < 4; ++j) w[i] = (w[i] << 8) | block_[i * 4 + j];
  for (unsigned i = 16; i < 64; ++i) {
    auto x = w[i - 15], y = w[i - 2];
    w[i] = w[i - 16] + (std::rotr(x, 7) ^ std::rotr(x, 18) ^ (x >> 3)) + w[i - 7] +
           (std::rotr(y, 17) ^ std::rotr(y, 19) ^ (y >> 10));
  }
  auto a = h_[0], b = h_[1], c = h_[2], d = h_[3], e = h_[4], f = h_[5], g = h_[6], h = h_[7];
  for (unsigned i = 0; i < 64; ++i) {
    auto t = h + (std::rotr(e, 6) ^ std::rotr(e, 11) ^ std::rotr(e, 25)) + ((e & f) ^ (~e & g)) +
             k[i] + w[i];
    auto u =
        (std::rotr(a, 2) ^ std::rotr(a, 13) ^ std::rotr(a, 22)) + ((a & b) ^ (a & c) ^ (b & c));
    h = g;
    g = f;
    f = e;
    e = d + t;
    d = c;
    c = b;
    b = a;
    a = t + u;
  }
  h_[0] += a;
  h_[1] += b;
  h_[2] += c;
  h_[3] += d;
  h_[4] += e;
  h_[5] += f;
  h_[6] += g;
  h_[7] += h;
}
void Sha256::update(std::span<const std::uint8_t> s) {
  size_ += s.size();
  for (auto c : s) {
    block_[used_++] = c;
    if (used_ == 64) {
      compress();
      used_ = 0;
    }
  }
}
Hash Sha256::finish() {
  auto bits = size_ * 8;
  block_[used_++] = 0x80;
  if (used_ > 56) {
    while (used_ < 64) block_[used_++] = 0;
    compress();
    used_ = 0;
  }
  while (used_ < 56) block_[used_++] = 0;
  for (unsigned i = 0; i < 8; ++i) block_[63 - i] = static_cast<std::uint8_t>(bits >> (8 * i));
  compress();
  Hash out{};
  for (unsigned i = 0; i < 32; ++i)
    out[i] = static_cast<std::uint8_t>(h_[i / 4] >> (24 - 8 * (i % 4)));
  return out;
}
}  // namespace arch003
