"""Independent bounded properties, saved-ledger checks and intentional mutations."""
import copy
from fractions import Fraction
import itertools
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import h04_radix_adaptation as candidate
import verify_h04_radix_adaptation as verifier


class H04Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.packet = candidate.build_packet()

    def test_signed_domain_minimality(self):
        for b, k in zip((8, 16, 32, 64), (6, 11, 21, 41)):
            self.assertEqual(candidate.trits(b), k)
            lo, hi = -(2**(b-1)), 2**(b-1)-1
            self.assertGreaterEqual((3**k-1)//2, -lo)
            self.assertLess((3**(k-1)-1)//2, -lo)
            for radix, width in [(2, b), (3, k)]:
                for v in [lo, lo+1, -1, 0, 1, hi-1, hi]:
                    self.assertEqual(verifier.numeric(candidate.encode(v, width, radix), radix), v)

    def test_exhaustive_binary_codebook(self):
        for v in range(-128, 128):
            observed = candidate.encode(v, 8, 2)
            standard = list(map(int, reversed(format(v if v >= 0 else v+256, '08b'))))
            self.assertEqual(observed, standard)
            self.assertEqual(candidate.decode(observed, 2), v)

    def test_exhaustive_balanced_codebook(self):
        for width in range(1, 7):
            codebook = {}
            for digits in itertools.product((-1, 0, 1), repeat=width):
                v = sum(d*3**i for i, d in enumerate(digits))
                self.assertNotIn(v, codebook)
                codebook[v] = digits
                self.assertEqual(candidate.encode(v, width, 3), list(digits))
                self.assertEqual(candidate.decode(digits, 3), v)
            radius = (3**width-1)//2
            self.assertEqual(set(codebook), set(range(-radius, radius+1)))

    def test_exhaustive_bounded_addition(self):
        for a in range(-128, 128):
            for b in range(-128, 128):
                for radix, width in [(2, 8), (3, 6)]:
                    digits = candidate.add_digits(candidate.encode(a, width, radix), candidate.encode(b, width, radix), radix)
                    self.assertEqual(verifier.numeric(digits, radix), a+b)

    def test_seeded_large_arithmetic(self):
        rng = random.Random(93401)
        for _ in range(500):
            a, b = rng.randrange(-(2**63), 2**63), rng.randrange(-(2**63), 2**63)
            for radix, width in [(2, 64), (3, 41)]:
                wide = candidate.add_digits(candidate.encode(a, width, radix), candidate.encode(b, width, radix), radix)
                self.assertEqual(verifier.numeric(wide, radix), a+b)

    def test_no_wrapping_or_discarded_overflow(self):
        for arm in candidate.ARMS:
            for a, b in [(2**63-1, 1), (-2**63, -1), (2**63, 0), (-2**63-1, 0)]:
                with self.assertRaises(OverflowError):
                    candidate.evaluate(a, b, 64, arm, 'overflow')
        with self.assertRaises(OverflowError):
            candidate.encode(128, 8, 2)
        with self.assertRaises(OverflowError):
            candidate.encode(365, 6, 3)

    def test_mode_domain_is_not_value_width(self):
        for arm in ('AB', 'AT'):
            r = candidate.evaluate(127, 1, 64, arm, 'boundary')
            self.assertEqual((r['input_mode'], r['output_mode']), (8, 16))
            self.assertEqual(r['transition_edges'], [[64, 8], [8, 16]])
            self.assertEqual((r['promotions'], r['demotions']), (1, 1))
            self.assertEqual(r['count_vector']['selector_invocations'], 2)
            self.assertEqual(r['conversions']['mode_resize_subtype'], 1)
        r = candidate.evaluate(127, 1, 64, 'AT', 'boundary')
        self.assertEqual(r['storage']['value_symbols'][-1], 6)
        self.assertEqual(r['storage']['domain_symbols'][-1], 11)

    def test_disabled_policy_matches_fixed(self):
        for row in self.packet['ledger.json']['rows']:
            for fixed, adaptive in [('FB', 'AB'), ('FT', 'AT')]:
                observed = candidate.evaluate(int(row['a']), int(row['b']), 64, adaptive, row['trace_id'], True)
                observed['correct'] = True
                expected = copy.deepcopy(row['arms'][fixed])
                observed.pop('arm'); expected.pop('arm')
                self.assertEqual(observed, expected)

    def test_mode_relabeling_invariant(self):
        other = candidate.build_packet(labels={8: 'zeta', 16: 'alpha', 32: 'mu', 64: 'beta'})
        for name in ('ledger.json', 'controls.json'):
            for x, y in zip(self.packet[name]['rows'], other[name]['rows']):
                self.assertEqual(x['trace_id'], y['trace_id'])
                for arm in x['arms']:
                    a, b = dict(x['arms'][arm]), dict(y['arms'][arm])
                    a.pop('mode_labels'); b.pop('mode_labels')
                    self.assertEqual(a, b)
        self.assertEqual(self.packet['analysis.json'], other['analysis.json'])
        verifier.verify_data(other['ledger.json'], other['analysis.json'], other['controls.json'])

    def test_independent_saved_data_verification(self):
        r = verifier.verify_data(self.packet['ledger.json'], self.packet['analysis.json'], self.packet['controls.json'])
        self.assertEqual((r['verified_operations'], r['verified_arm_evaluations'], r['verified_disabled_equalities']), (96, 384, 192))

    def test_required_boundaries_and_four_traces(self):
        rows = self.packet['ledger.json']['rows']
        pairs = {(int(r['a']), int(r['b'])) for r in rows}
        for pair in [(-128, 0), (127, 1), (32767, 1), (2147483647, 1), (-2**63, 0), (2**63-1, 0), (0, 0)]:
            self.assertIn(pair, pairs)
        self.assertEqual({x['family'] for x in rows}, {'constant-small', 'constant-large', 'phased', 'alternating'})

    def test_finite_thresholds_and_negative_result(self):
        a = self.packet['analysis.json']
        self.assertEqual(a['payload_only_break_even']['constant-small']['AT_vs_AB'], '4/3')
        self.assertTrue(all(v['FT_vs_FB'] == '64/41' for v in a['payload_only_break_even'].values()))
        for p in a['points']:
            if p['family'] == 'constant-large' and p['profile'] != 'zero_overhead_limit':
                self.assertEqual(p['comparisons']['AT_vs_FT'], 'loss')
        interaction_counterexample = next(p for p in a['points'] if p['family'] == 'constant-large' and p['profile'] == 'metadata_only' and p['r'] == '2')
        self.assertLess(Fraction(interaction_counterexample['interaction']), 1)
        self.assertEqual(interaction_counterexample['comparisons']['AT_vs_AB'], 'loss')
        self.assertEqual(interaction_counterexample['comparisons']['AT_vs_FT'], 'loss')
        self.assertIn('2', a['r_grid'])
        self.assertTrue(any(p['comparisons']['AT_vs_AB'] == 'loss' for p in a['points']))

    def test_packing_has_no_binary_only_penalty(self):
        for row in self.packet['ledger.json']['rows']:
            for b, t in [('FB', 'FT'), ('AB', 'AT')]:
                for q in ['1', '8', '64']:
                    x, y = row['arms'][b]['host_packing'][q], row['arms'][t]['host_packing'][q]
                    self.assertEqual(x['domain_optimal_payload_bits'], y['domain_optimal_payload_bits'])
                    self.assertEqual(x['metadata_bits'], y['metadata_bits'])
                    self.assertGreaterEqual(y['all_pattern_payload_bits'], x['all_pattern_payload_bits'])

    def test_mutation_arithmetic_is_detected(self):
        original = candidate.add_digits
        def broken(a, b, radix):
            result = original(a, b, radix)
            result[0] = 0 if result[0] else 1
            return result
        with patch.object(candidate, 'add_digits', broken):
            with self.assertRaises(ArithmeticError):
                candidate.build_packet()

    def test_mutation_accounting_is_detected(self):
        mutations = [lambda r: r['arms']['AT']['count_vector'].__setitem__('transitions', 0),
                     lambda r: r['arms']['AB']['storage'].__setitem__('allocated_symbols', 999),
                     lambda r: r['arms']['AB']['host_packing']['8'].__setitem__('domain_optimal_payload_bits', 999),
                     lambda r: r['arms']['AT']['conversions'].__setitem__('operations', 0)]
        for mutate in mutations:
            p = copy.deepcopy(self.packet)
            mutate(p['ledger.json']['rows'][0])
            with self.assertRaises(ValueError):
                verifier.verify_data(p['ledger.json'], p['analysis.json'], p['controls.json'])

    def test_mutation_result_and_disabled_control_detected(self):
        for target in ['result', 'control']:
            p = copy.deepcopy(self.packet)
            if target == 'result':
                p['ledger.json']['rows'][0]['arms']['FB']['result'] = '7'
            else:
                p['controls.json']['rows'][0]['arms']['AB']['count_vector']['selector_invocations'] = 1
            with self.assertRaises(ValueError):
                verifier.verify_data(p['ledger.json'], p['analysis.json'], p['controls.json'])

    def test_mutation_omitted_sweep_point_detected(self):
        p = copy.deepcopy(self.packet)
        p['analysis.json']['points'].pop()
        with self.assertRaises(ValueError):
            verifier.verify_data(p['ledger.json'], p['analysis.json'], p['controls.json'])

    def test_external_mutants_fail_original_verification_test(self):
        # Run an unchanged verification test against defective source, not just
        # a malformed digest. Each subprocess must actually fail.
        source = Path(candidate.__file__).parent
        changes = [("digit = (total+1) % 3-1", "digit = 0", "OverflowError"),
                   ("transitions=len(edges)", "transitions=0", "ValueError")]
        for before, after, message in changes:
            with tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp)
                for name in ['h04_radix_adaptation.py', 'verify_h04_radix_adaptation.py', 'test_h04_radix_adaptation.py']:
                    text = (source/name).read_text()
                    if name == 'h04_radix_adaptation.py':
                        self.assertEqual(text.count(before), 1)
                        text = text.replace(before, after)
                    (root/name).write_text(text)
                run = subprocess.run([sys.executable, '-m', 'unittest',
                                      'test_h04_radix_adaptation.H04Tests.test_independent_saved_data_verification', '-v'],
                                     cwd=root, text=True, capture_output=True)
                self.assertNotEqual(run.returncode, 0)
                self.assertIn(message, run.stderr)

    def test_repeated_subprocess_bytes_and_manifest(self):
        script = Path(candidate.__file__)
        with tempfile.TemporaryDirectory() as tmp:
            first, second = Path(tmp)/'first', Path(tmp)/'second'
            for out in [first, second]:
                subprocess.run([sys.executable, str(script), '--output-dir', str(out)], check=True, capture_output=True)
                verifier.verify_packet(out)
            for name in ['ledger.json', 'analysis.json', 'controls.json', 'manifest.json']:
                self.assertEqual((first/name).read_bytes(), (second/name).read_bytes())
            with (first/'ledger.json').open('ab') as f:
                f.write(b' ')
            with self.assertRaises(ValueError):
                verifier.verify_packet(first)


if __name__ == '__main__':
    unittest.main()
