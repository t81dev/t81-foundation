#!/usr/bin/env python3
"""Offline H04-R01 verifier. No producer imports or candidate arithmetic helpers."""
import argparse
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path
import re

WIDTHS = (8, 16, 32, 64)
TRITS = (6, 11, 21, 41)
NAMES = ("FB", "FT", "AB", "AT")
PAIRS = (("FT", "FB"), ("AT", "AB"), ("AB", "FB"), ("AT", "FT"))


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def decimal(text):
    require(isinstance(text, str) and re.fullmatch(r"0|-?[1-9][0-9]*", text), "decimal encoding")
    return int(text)


def signed_ok(value, width):
    return -2**(width-1) <= value < 2**(width-1)


def numeric(digits, radix):
    require(digits and all(type(d) is int for d in digits), "digit types")
    require(all(d in ((0, 1) if radix == 2 else (-1, 0, 1)) for d in digits), "digit domain")
    if radix == 2:
        return int("".join(map(str, reversed(digits))), 2) - (2**len(digits) if digits[-1] else 0)
    value = 0
    for d in reversed(digits):
        value = 3*value+d
    return value


def minimum(value, radix):
    width = 1
    if radix == 2:
        while not signed_ok(value, width):
            width += 1
    else:
        radius = 1
        while abs(value) > radius:
            width, radius = width+1, 3*radius+1
    return width


def check_arm(value, a, b, expected, previous, arm, identity, disabled=False):
    radix = 2 if arm in ("FB", "AB") else 3
    adaptive = arm in ("AB", "AT") and not disabled
    start = next(w for w in WIDTHS if signed_ok(a, w) and signed_ok(b, w)) if adaptive else 64
    finish = next(w for w in WIDTHS if w >= start and signed_ok(expected, w))
    n = start if radix == 2 else TRITS[WIDTHS.index(start)]
    m = finish if radix == 2 else TRITS[WIDTHS.index(finish)]
    require(value['arm'] == arm and value['trace_id'] == identity, "arm identity")
    require(value['radix'] == radix and value['adaptive'] is adaptive, "radix/policy")
    require((value['previous_mode'], value['input_mode'], value['output_mode']) == (previous, start, finish), "online mode policy")
    for digits, original in zip(value['input_digits'], (a, b)):
        require(len(digits) == n and numeric(digits, radix) == original, "input encoding")
    require(len(value['input_digits']) == 2, "two operands")
    require(len(value['scratch_digits']) == n+1 and numeric(value['scratch_digits'], radix) == expected, "widened addition")
    require(len(value['result_digits']) == m and numeric(value['result_digits'], radix) == expected, "output encoding")
    require(decimal(value['result']) == expected and value['correct'] is True, "oracle result")
    modes = [previous, start, finish]
    edges = [[modes[i], modes[i+1]] for i in (0, 1) if modes[i] != modes[i+1]]
    require(value['transition_edges'] == edges, "mode edges")
    require(value['promotions'] == len([e for e in edges if e[1] > e[0]]), "promotions")
    require(value['demotions'] == len([e for e in edges if e[1] < e[0]]), "demotions")
    calls = int(adaptive)+int(finish > start)
    comparisons = 4*(WIDTHS.index(start)+1) if adaptive else 0
    if finish > start:
        comparisons += 6*(WIDTHS.index(finish)-WIDTHS.index(start)+1)
    require(value['selector_comparisons'] == comparisons, "selection acquisition")
    visits = 2*n+(n+1)+2*m
    require(value['conversions'] == {'input_encodes': 2, 'scratch_decodes': 1, 'result_encodes': 1,
                                    'output_decodes': 1, 'operations': 5, 'symbol_visits': visits,
                                    'mode_resize_subtype': int(finish != start)}, "conversions")
    s = value['storage']
    intrinsic = [minimum(x, radix) for x in (a, b, expected)]
    payload, tags = 2*n+m, 4 if adaptive else 0
    expected_storage = dict(value_symbols=intrinsic, domain_symbols=[n, n, m], domain_bits=[start, start, finish],
                            unused_domain_codewords=[str(radix**w-2**b) for w, b in zip((n, n, m), (start, start, finish))],
                            logical_symbols=payload, allocated_symbols=payload, allocation_padding_symbols=0,
                            unused_value_symbols=payload-sum(intrinsic), utilization=str(Q(sum(intrinsic), payload)),
                            mode_metadata_bits=tags, scratch_symbols=n+1, peak_live_symbols=2*n+(n+1)+m,
                            external_handles=3, per_value_domain_bit_lower_bounds=[start, start, finish])
    require(s == expected_storage, "storage/capacity distinction")
    raw = [w if radix == 2 else (3**w-1).bit_length() for w in (n, n, m)]
    for quantum in (1, 8, 64):
        def allocation(width):
            return 0 if not width else quantum*(1+(width-1)//quantum)
        require(value['host_packing'][str(quantum)] == {
            'all_pattern_payload_bits': sum(map(allocation, raw)),
            'domain_optimal_payload_bits': sum(map(allocation, [start, start, finish])),
            'metadata_bits': allocation(tags),
            'all_pattern_padding_bits': sum(allocation(w)-w for w in raw)}, "packing fairness")
    vector = dict(binary_cell_slots=payload if radix == 2 else 0,
                  ternary_cell_slots=payload if radix == 3 else 0, metadata_bits=tags,
                  selector_invocations=calls, selector_bound_comparisons=comparisons,
                  transitions=len(edges), conversion_binary_symbols=visits if radix == 2 else 0,
                  conversion_ternary_symbols=visits if radix == 3 else 0,
                  arithmetic_binary_columns=n if radix == 2 else 0,
                  arithmetic_ternary_columns=n if radix == 3 else 0)
    require(value['count_vector'] == vector, "typed count vector")
    return finish


def verify_data(ledger, analysis, controls):
    require(ledger['reference_commit'] == '860558b4ad1cf4160af30860b00b15c46165acd5', "reference")
    for mode, width, k in zip(ledger['modes'], WIDTHS, TRITS):
        require(mode == {'bits': width, 'trits': k, 'low': str(-2**(width-1)), 'high': str(2**(width-1)-1)}, "mode declaration")
        require((3**k-1)//2 >= 2**(width-1) and (3**(k-1)-1)//2 < 2**(width-1), "negative extreme / minimal trits")
    require(len(ledger['modes']) == 4 and len(ledger['rows']) == 96, "declared dimensions")
    previous, totals, seen, families = {}, {}, set(), {}
    require(controls['adaptation_disabled'] is True and controls['equalities_checked'] == 192, "control count")
    control_rows = {r['trace_id']: r for r in controls['rows']}
    require(len(control_rows) == 96, "control coverage")
    for row in ledger['rows']:
        family, seed, index = row['family'], row['seed'], row['index']
        expected_seed = {'constant-small': 8101, 'constant-large': 8102, 'phased': 8103, 'alternating': 8104}
        require(family in expected_seed and seed == expected_seed[family], "family seed")
        require(index == families.get(family, 0), "operation order")
        families[family] = index+1
        a, b, expected = decimal(row['a']), decimal(row['b']), decimal(row['expected'])
        require(expected == a+b and all(signed_ok(x, 64) for x in (a, b, expected)), "independent oracle / domain")
        require(row['operation'] == 'add', "operation")
        if family == 'constant-small':
            require(all(signed_ok(x, 8) for x in (a, b, expected)), "constant small")
        if family == 'constant-large':
            require(not (signed_ok(a, 32) and signed_ok(b, 32)), "constant large")
        identity = {k: row[k] for k in ('family', 'seed', 'index', 'operation', 'a', 'b')}
        data = (json.dumps(identity, sort_keys=True, separators=(',', ':'))+'\n').encode()
        require(row['trace_id'] == hashlib.sha256(data).hexdigest() and row['trace_id'] not in seen, "stable trace id")
        seen.add(row['trace_id'])
        require(set(row['arms']) == set(NAMES), "all four arms")
        for arm in NAMES:
            key = family, arm
            previous[key] = check_arm(row['arms'][arm], a, b, expected, previous.get(key, 64), arm, row['trace_id'])
            v = row['arms'][arm]
            acc = totals.setdefault(family, {}).setdefault(arm, {})
            counts = dict(v['count_vector'], promotions=v['promotions'], demotions=v['demotions'],
                          conversion_operations=5, mode_resizes=v['conversions']['mode_resize_subtype'])
            for k, x in counts.items():
                acc[k] = acc.get(k, 0)+x
        control = control_rows[row['trace_id']]
        require(set(control['arms']) == {'AB', 'AT'}, "recorded disabled arms")
        for fixed, adaptive in (('FB', 'AB'), ('FT', 'AT')):
            check_arm(control['arms'][adaptive], a, b, expected, 64, adaptive, row['trace_id'], True)
            left, right = dict(row['arms'][fixed]), dict(control['arms'][adaptive])
            left.pop('arm'); right.pop('arm')
            require(left == right and control[fixed+'_equals_'+adaptive] is True, "disabled behavior equality")
        for x, y in (('FB', 'FT'), ('AB', 'AT')):
            require(row['arms'][x]['input_mode'] == row['arms'][y]['input_mode'] and row['arms'][x]['output_mode'] == row['arms'][y]['output_mode'], "equal adaptation information")
            for q in ('1', '8', '64'):
                require(row['arms'][x]['host_packing'][q]['domain_optimal_payload_bits'] == row['arms'][y]['host_packing'][q]['domain_optimal_payload_bits'], "competitive bit packing")
    require(set(families.values()) == {24} and len(families) == 4, "four families")
    require(analysis['family_totals'] == totals, "independent totals")
    keys = ('metadata_bits', 'selector_invocations', 'transitions', 'conversion_binary_symbols', 'conversion_ternary_symbols')
    patterns = {'zero_overhead_limit': (0, 0, 0, 0, 0), 'metadata_only': (1, 0, 0, 0, 0),
                'selection': (1, 1, 0, 0, 0), 'transition': (1, 0, 1, 0, 0),
                'conversion': (1, 0, 0, 1, 1), 'ternary_conversion_only': (1, 0, 0, 0, 1),
                'all_unit_penalties': (1, 1, 1, 1, 1)}
    require(analysis['profiles'] == {name: dict(zip(keys, v)) for name, v in patterns.items()}, "predeclared coefficients")
    grid = {Q(x) for x in ('1/2', '1', '4/3', '3/2', '64/41', '317/200', '8/5', '2')}
    def cost(v, w, r):
        return v['binary_cell_slots']+r*v['ternary_cell_slots']+sum(v[k]*w[k] for k in keys)
    for family, values in totals.items():
        require(analysis['payload_only_break_even'][family] == {
            x+'_vs_'+y: str(Q(values[y]['binary_cell_slots'], values[x]['ternary_cell_slots'])) for x, y in PAIRS[:2]}, "finite crossover")
        for w in analysis['profiles'].values():
            for x, y in PAIRS:
                intercept = cost(values[x], w, Q(0))-cost(values[y], w, Q(0))
                slope = cost(values[x], w, Q(1))-cost(values[y], w, Q(1))-intercept
                if slope and (root := -intercept/slope) > 0:
                    grid |= {root*Q(99, 100), root, root*Q(101, 100)}
    require(analysis['r_grid'] == [str(x) for x in sorted(grid)], "complete two-sided sweep")
    points = {(x['family'], x['profile'], x['r']): x for x in analysis['points']}
    require(len(points) == len(analysis['points']) == 4*7*len(grid), "full sweep coverage")
    def comparison(a, b):
        return ('loss' if a > b else 'win') if a != b else 'tie'
    for family, values in totals.items():
        for profile, w in analysis['profiles'].items():
            for r in grid:
                point = points[(family, profile, str(r))]
                c = {a: cost(v, w, r) for a, v in values.items()}
                require(point['accounting_U'] == {a: str(v) for a, v in c.items()}, "conditional accounting")
                require(point['comparisons'] == {x+'_vs_'+y: comparison(c[x], c[y]) for x, y in PAIRS}, "all contrasts")
                require(Q(point['interaction']) == (c['AT']/c['FT'])/(c['AB']/c['FB']), "interaction")
                require(point['AT_vs_binary_envelope'] == comparison(c['AT'], min(c['AB'], c['FB'])), "binary envelope")
    return {'verified_operations': len(seen), 'verified_arm_evaluations': 4*len(seen),
            'verified_disabled_equalities': 2*len(seen), 'verified_sweep_points': len(points)}


def verify_packet(directory):
    directory = Path(directory)
    manifest = json.loads((directory/'manifest.json').read_text())
    require(set(manifest['files']) == {'ledger.json', 'controls.json', 'analysis.json'}, "manifest scope")
    documents = {}
    for name, info in manifest['files'].items():
        data = (directory/name).read_bytes()
        require(len(data) == info['bytes'] and hashlib.sha256(data).hexdigest() == info['sha256'], "digest "+name)
        value = json.loads(data)
        reencoded = (json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False)+'\n').encode('ascii')
        require(data == reencoded, "canonical data "+name)
        documents[name] = value
    producer = Path(__file__).with_name('h04_radix_adaptation.py')
    require(hashlib.sha256(producer.read_bytes()).hexdigest() == manifest['producer_sha256'], "producer digest")
    return verify_data(documents['ledger.json'], documents['analysis.json'], documents['controls.json'])


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--packet', required=True)
    print(json.dumps(verify_packet(p.parse_args().packet), sort_keys=True))
