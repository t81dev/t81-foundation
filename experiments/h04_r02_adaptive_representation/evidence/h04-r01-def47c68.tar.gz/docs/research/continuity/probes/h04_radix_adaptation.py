#!/usr/bin/env python3
"""H04-R01: exact digit arithmetic, explicit accounting, conditional cost ledger."""
import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import random

REFERENCE = "860558b4ad1cf4160af30860b00b15c46165acd5"
MODES = (8, 16, 32, 64)
ARMS = ("FB", "FT", "AB", "AT")
PAIRS = (("FT", "FB"), ("AT", "AB"), ("AB", "FB"), ("AT", "FT"))
WEIGHTS = ("metadata_bits", "selector_invocations", "transitions",
           "conversion_binary_symbols", "conversion_ternary_symbols")


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":"),
                       ensure_ascii=True, allow_nan=False) + "\n").encode("ascii")


def bounds(bits):
    return -(1 << (bits-1)), (1 << (bits-1))-1


def fits(value, bits):
    low, high = bounds(bits)
    return low <= value <= high


def trits(bits):
    k, capacity = 0, 1
    while capacity < (1 << bits)+1:
        k, capacity = k+1, capacity*3
    return k


def value_symbols(value, radix):
    if radix == 2:
        return max(1, value.bit_length()+1 if value >= 0 else (~value).bit_length()+1)
    k = 1
    while (3**k-1)//2 < abs(value):
        k += 1
    return k


def encode(value, width, radix):
    if radix == 2:
        if not fits(value, width):
            raise OverflowError("binary encoding outside domain")
        residue = value if value >= 0 else (1 << width)+value
        return [(residue >> i) & 1 for i in range(width)]
    if abs(value) > (3**width-1)//2:
        raise OverflowError("ternary encoding outside capacity")
    digits = []
    for _ in range(width):
        value, digit = divmod(value, 3)
        if digit == 2:
            digit, value = -1, value+1
        digits.append(digit)
    if value:
        raise OverflowError("unconsumed ternary value")
    return digits


def decode(digits, radix):
    value = sum(d * radix**i for i, d in enumerate(digits))
    return value - (digits[-1] << len(digits)) if radix == 2 else value


def add_digits(left, right, radix):
    result, carry = [], 0
    if radix == 2:
        for x, y in zip(left[:-1], right[:-1]):
            total = x+y+carry
            result.append(total & 1)
            carry = total >> 1
        top = carry-left[-1]-right[-1]
        return result + [top & 1, int(top < 0)]
    for x, y in zip(left, right):
        total = x+y+carry
        digit = (total+1) % 3-1
        result.append(digit)
        carry = (total-digit)//3
    return result+[carry]


def choose(values, start=0):
    comparisons = 0
    for bits in MODES[start:]:
        low, high = bounds(bits)
        valid = True
        for value in values:
            lower, upper = low <= value, value <= high
            comparisons += 2
            valid = valid and lower and upper
        if valid:
            return bits, comparisons
    raise OverflowError("operation outside D_64")


def evaluate(a, b, previous, arm, trace_id, disabled=False, labels=None):
    if not fits(a, 64) or not fits(b, 64):
        raise OverflowError("input outside D_64")
    radix = 2 if arm.endswith("B") else 3
    adaptive = arm.startswith("A") and not disabled
    labels = labels or {bits: "mode_"+str(bits) for bits in MODES}
    selected, comparisons = choose((a, b)) if adaptive else (64, 0)
    calls = int(adaptive)
    n = selected if radix == 2 else trits(selected)
    left, right = encode(a, n, radix), encode(b, n, radix)
    wide = add_digits(left, right, radix)
    actual = decode(wide, radix)
    if not fits(actual, 64):
        raise OverflowError("result outside D_64; no wrap")
    output = selected
    if not fits(actual, selected):
        if not adaptive:
            raise OverflowError("fixed result outside D_64")
        output, more = choose((a, b, actual), MODES.index(selected))
        comparisons += more
        calls += 1
    m = output if radix == 2 else trits(output)
    encoded = encode(actual, m, radix)
    final = decode(encoded, radix)
    modes = (previous, selected, output)
    edges = [[x, y] for x, y in zip(modes, modes[1:]) if x != y]
    payload = 2*n+m
    intrinsic = [value_symbols(v, radix) for v in (a, b, final)]
    tags = 4 if adaptive else 0
    all_pattern_bits = [w if radix == 2 else (3**w-1).bit_length() for w in (n, n, m)]
    logical_bits = [selected, selected, output]
    def aligned(width, quantum):
        return ((width+quantum-1)//quantum)*quantum
    packing = {}
    for quantum in (1, 8, 64):
        packing[str(quantum)] = {
            "all_pattern_payload_bits": sum(aligned(w, quantum) for w in all_pattern_bits),
            "domain_optimal_payload_bits": sum(aligned(w, quantum) for w in logical_bits),
            "metadata_bits": aligned(tags, quantum),
            "all_pattern_padding_bits": sum(aligned(w, quantum)-w for w in all_pattern_bits)}
    visits = 3*n+1+2*m
    vector = dict(binary_cell_slots=payload if radix == 2 else 0,
                  ternary_cell_slots=payload if radix == 3 else 0,
                  metadata_bits=tags, selector_invocations=calls, transitions=len(edges),
                  selector_bound_comparisons=comparisons,
                  conversion_binary_symbols=visits if radix == 2 else 0,
                  conversion_ternary_symbols=visits if radix == 3 else 0,
                  arithmetic_binary_columns=n if radix == 2 else 0,
                  arithmetic_ternary_columns=n if radix == 3 else 0)
    return dict(arm=arm, trace_id=trace_id, radix=radix, adaptive=adaptive,
                previous_mode=previous, input_mode=selected, output_mode=output,
                mode_labels=[labels[w] for w in modes],
                input_digits=[left, right], scratch_digits=wide, result_digits=encoded,
                result=str(final), selector_comparisons=comparisons,
                transition_edges=edges, promotions=sum(x < y for x, y in edges),
                demotions=sum(x > y for x, y in edges),
                conversions={"input_encodes": 2, "scratch_decodes": 1, "result_encodes": 1,
                             "output_decodes": 1, "operations": 5, "symbol_visits": visits,
                             "mode_resize_subtype": int(output != selected)},
                storage={"value_symbols": intrinsic, "domain_symbols": [n, n, m],
                         "domain_bits": logical_bits,
                         "unused_domain_codewords": [str(radix**w-2**b) for w, b in zip((n, n, m), logical_bits)],
                         "logical_symbols": payload,
                         "allocated_symbols": payload, "allocation_padding_symbols": 0,
                         "unused_value_symbols": payload-sum(intrinsic),
                         "utilization": str(F(sum(intrinsic), payload)),
                         "mode_metadata_bits": tags, "scratch_symbols": n+1,
                         "peak_live_symbols": 3*n+1+m, "external_handles": 3,
                         "per_value_domain_bit_lower_bounds": logical_bits},
                host_packing=packing, count_vector=vector)


def traces():
    families = {}
    for family, seed in zip(("constant-small", "constant-large", "phased", "alternating"),
                            (8101, 8102, 8103, 8104)):
        rng = random.Random(seed)
        lo, hi = bounds(64)
        small = [(-128, 0), (127, 0), (0, 0), (1, -2), (63, 64), (-64, -64), (-1, 1), (-1, 0)]
        large = [(lo, 0), (hi, 0), (lo, hi), (hi, -hi), (lo+1, -1), (hi-1, 1)]
        def sample(bits):
            low, high = bounds(bits)
            x = rng.randint(low, high)
            return x, rng.randint(max(low, low-x), min(high, high-x))
        def big_sample():
            x = hi-rng.randrange(1 << 20) if rng.randrange(2) else lo+rng.randrange(1 << 20)
            return x, rng.randint(max(lo, lo-x), min(hi, hi-x))
        if family == "constant-small":
            pairs = small+[sample(8) for _ in range(16)]
        elif family == "constant-large":
            pairs = large+[big_sample() for _ in range(18)]
        elif family == "phased":
            pairs = []
            for bits in (8, 16, 32, 64, 32, 16, 8):
                if bits == 64:
                    pairs.extend(large)
                else:
                    low, high = bounds(bits)
                    pairs.extend([(low, 0), sample(bits), (high, 1)])
        else:
            lows = [(127, 1), (-128, 0), (32767, 1), (-32768, 0),
                    (2147483647, 1), (-2147483648, 0), (0, 0), (63, 64),
                    (-64, -64), (-1, 0), (127, 0), (-1, 1)]
            highs = large+[big_sample() for _ in range(6)]
            pairs = [pair for low, high in zip(lows, highs) for pair in (low, high)]
        if len(pairs) != 24:
            raise ValueError("trace length")
        families[family] = []
        for index, (a, b) in enumerate(pairs):
            identity = dict(family=family, seed=seed, index=index, operation="add", a=str(a), b=str(b))
            trace_id = hashlib.sha256(canonical(identity)).hexdigest()
            families[family].append(dict(identity, trace_id=trace_id, expected=str(a+b)))
    return families


def profiles():
    def weights(**kw):
        return dict(dict.fromkeys(WEIGHTS, 0), **kw)
    return {"zero_overhead_limit": weights(), "metadata_only": weights(metadata_bits=1),
            "selection": weights(metadata_bits=1, selector_invocations=1),
            "transition": weights(metadata_bits=1, transitions=1),
            "conversion": weights(metadata_bits=1, conversion_binary_symbols=1, conversion_ternary_symbols=1),
            "ternary_conversion_only": weights(metadata_bits=1, conversion_ternary_symbols=1),
            "all_unit_penalties": weights(**dict.fromkeys(WEIGHTS, 1))}


def affine(vector, weights):
    return (F(vector["binary_cell_slots"] + sum(vector[k]*weights[k] for k in WEIGHTS)),
            F(vector["ternary_cell_slots"]))


def analysis(rows):
    totals = {}
    for row in rows:
        family = totals.setdefault(row["family"], {})
        for arm, value in row["arms"].items():
            acc = family.setdefault(arm, {})
            measures = dict(value["count_vector"], promotions=value["promotions"],
                            demotions=value["demotions"], conversion_operations=5,
                            mode_resizes=value["conversions"]["mode_resize_subtype"])
            for key, number in measures.items():
                acc[key] = acc.get(key, 0)+number
    grid = {F(x) for x in ("1/2", "1", "4/3", "3/2", "64/41", "317/200", "8/5", "2")}
    for family in totals.values():
        for weights in profiles().values():
            costs = {arm: affine(v, weights) for arm, v in family.items()}
            for a, b in PAIRS:
                intercept = costs[a][0]-costs[b][0]
                slope = costs[a][1]-costs[b][1]
                if slope and (root := -intercept/slope) > 0:
                    grid.update((root*F(99, 100), root, root*F(101, 100)))
    grid = sorted(grid)
    results = []
    def verdict(a, b):
        return "win" if a < b else "loss" if a > b else "tie"
    for name, family in totals.items():
        for profile, weights in profiles().items():
            coeff = {arm: affine(v, weights) for arm, v in family.items()}
            for r in grid:
                costs = {arm: c+s*r for arm, (c, s) in coeff.items()}
                results.append(dict(family=name, profile=profile, r=str(r),
                                    accounting_U={a: str(v) for a, v in costs.items()},
                                    comparisons={a+"_vs_"+b: verdict(costs[a], costs[b]) for a, b in PAIRS},
                                    interaction=str(costs["AT"]*costs["FB"]/(costs["FT"]*costs["AB"])),
                                    AT_vs_binary_envelope=verdict(costs["AT"], min(costs["AB"], costs["FB"]))))
    boundaries = {name: {a+"_vs_"+b: str(F(v[b]["binary_cell_slots"], v[a]["ternary_cell_slots"]))
                         for a, b in PAIRS[:2]} for name, v in totals.items()}
    return dict(schema="h04-analysis-v1", profiles=profiles(), r_grid=[str(x) for x in grid],
                accounting_unit="U, hypothetical compatible count weights; no physical cost estimates",
                grid_rule="fixed anchors plus 99/100, 1, 101/100 of every positive contrast crossover",
                family_totals=totals, payload_only_break_even=boundaries, points=results)


def build_packet(labels=None):
    rows, controls = [], []
    for family, operations in traces().items():
        previous, previous_control = dict.fromkeys(ARMS, 64), dict.fromkeys(ARMS, 64)
        for op in operations:
            arms, disabled = {}, {}
            for arm in ARMS:
                a, b = int(op["a"]), int(op["b"])
                arms[arm] = evaluate(a, b, previous[arm], arm, op["trace_id"], labels=labels)
                disabled[arm] = evaluate(a, b, previous_control[arm], arm, op["trace_id"], True, labels)
                for value in (arms[arm], disabled[arm]):
                    if int(value["result"]) != a+b:
                        raise ArithmeticError("candidate disagrees with integer oracle")
                    value["correct"] = True
                previous[arm] = arms[arm]["output_mode"]
                previous_control[arm] = disabled[arm]["output_mode"]
            comparisons = {}
            for fixed, adaptive in (("FB", "AB"), ("FT", "AT")):
                left, right = (dict(disabled[a]) for a in (fixed, adaptive))
                left.pop("arm"); right.pop("arm")
                comparisons[fixed+"_equals_"+adaptive] = left == right
            if not all(comparisons.values()):
                raise ArithmeticError("adaptation-disabled control disagrees")
            controls.append(dict(trace_id=op["trace_id"],
                                 arms={a: disabled[a] for a in ("AB", "AT")}, **comparisons))
            rows.append(dict(op, arms=arms))
    ledger = dict(schema="h04-ledger-v1", reference_commit=REFERENCE,
                  modes=[dict(bits=b, trits=trits(b), low=str(bounds(b)[0]), high=str(bounds(b)[1])) for b in MODES],
                  policy="online operand scan, computed-result promotion; initial D_64; independent operations",
                  rows=rows)
    return {"ledger.json": ledger, "analysis.json": analysis(rows),
            "controls.json": dict(schema="h04-controls-v1", adaptation_disabled=True,
                                  equalities_checked=2*len(controls), rows=controls)}


def write_packet(directory):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    files = {}
    for name, value in build_packet().items():
        data = canonical(value)
        (directory/name).write_bytes(data)
        files[name] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    manifest = dict(schema="h04-manifest-v1", reference_commit=REFERENCE,
                    producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    encoding="h04-json-v1", files=files, scope="three data files only; manifest excludes itself")
    (directory/"manifest.json").write_bytes(canonical(manifest))
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    print(json.dumps(write_packet(args.output_dir), indent=2))
