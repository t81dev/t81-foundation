# H04-R01 reproduction and verification record

Starting reference: `860558b4ad1cf4160af30860b00b15c46165acd5`.
Environment personally executed: Python 3.14.3, macOS Darwin ARM64. Standard library only. No CPU performance or cross-platform measurements are claimed.

From the research repository root:

```sh
python3 docs/research/continuity/probes/h04_radix_adaptation.py --output-dir /tmp/h04-run-a
python3 docs/research/continuity/probes/verify_h04_radix_adaptation.py --packet /tmp/h04-run-a
python3 -m unittest discover -s docs/research/continuity/probes -p 'test_h04_radix_adaptation.py' -v
python3 docs/research/continuity/probes/h04_radix_adaptation.py --output-dir /tmp/h04-run-b
cmp /tmp/h04-run-a/ledger.json /tmp/h04-run-b/ledger.json
cmp /tmp/h04-run-a/analysis.json /tmp/h04-run-b/analysis.json
cmp /tmp/h04-run-a/controls.json /tmp/h04-run-b/controls.json
cmp /tmp/h04-run-a/manifest.json /tmp/h04-run-b/manifest.json
```

The generation/verifier commands were initially executed using /private/tmp/t81-h04-initial and /private/tmp/t81-h04-reviewed, then against docs/research/continuity/evidence/h04-r01-v1. The test suite also runs the producer twice in fresh subprocesses and requires identical bytes for all four files. Recorded normal-suite command/output is verification/local-tests.txt, with 19 successful tests. Independent verification reports 96 operations, 384 main arm evaluations, 192 disabled equalities and 1,596 sweep points. Initial test-expectation failure and two expected mutant failures are preserved, not counted as candidate successes.

The producer's manifest authenticates no author or signature; it checks data bytes and producer source. Independent verification checks semantic/accounting content rather than trusting self-reported correct=true. A modified payload with a recomputed digest is still rejected for semantic or accounting discrepancies. Tests include both an arithmetic mutation and an accounting mutation in copied source, run against the original unmodified verification test.

## Clean-checkout record

Executed against implementation/data commit `6875b46d6a8a0e57dd7a21b2322c54709fca369e` in a separate clean Git checkout. It was clean before and after generation/tests; only the Git object database was shared, not working files, virtual environments, models or build outputs.

```sh
git clone --shared --branch research/h04-r01-trace-ledger /Users/t81dev/Code/t81-foundation /private/tmp/t81-h04-clean-checkout
cd /private/tmp/t81-h04-clean-checkout
python3 docs/research/continuity/probes/h04_radix_adaptation.py --output-dir /private/tmp/t81-h04-clean-a
python3 docs/research/continuity/probes/verify_h04_radix_adaptation.py --packet /private/tmp/t81-h04-clean-a
python3 docs/research/continuity/probes/h04_radix_adaptation.py --output-dir /private/tmp/t81-h04-clean-b
python3 docs/research/continuity/probes/verify_h04_radix_adaptation.py --packet /private/tmp/t81-h04-clean-b
python3 -m unittest discover -s docs/research/continuity/probes -p 'test_h04_radix_adaptation.py' -v
```

All commands returned zero. Both fresh outputs and the checked-in reference match byte-for-byte for ledger.json, analysis.json, controls.json and manifest.json; normal tests pass 19/19. Full executable paths, host/Python version, source commit, commands, return codes and hashes are recorded in verification/clean-checkout.json. The clone tests are preserved in verification/clean-checkout-tests.txt. This demonstrates clean-checkout reproduction on this one host only. Follow-up commits append documentation/evidence; the probe, verifier, tests and canonical data are unchanged from the tested implementation commit.

A separate saved-file experiment altered the first AT transition count and recomputed the ledger size/hash in its manifest. The CLI verifier exited 1 at the typed count-vector check, not a digest mismatch. See verification/resigned-accounting-mutant.json and its stderr log. This gives an actual file-based semantic rejection in addition to in-memory mutation tests.

## Historical preservation

HYPOTHESIS_REGISTER_v1.json and the original charter/specification are unchanged. The old manifest was checked against its pinned Git objects, not misleadingly applied to appended handoff/README files. The new register and current packet manifest are separately versioned. The user task is preserved byte-for-byte inside TASK_v1.txt.gz, with hashes in task-origin.json.

The maintenance-status snapshot is read-only and outside canonical experiment data. It reports external merges of #565/#566; this task made no PR or merge calls and does not infer successful CI or Protocol 001 readiness from that state.
