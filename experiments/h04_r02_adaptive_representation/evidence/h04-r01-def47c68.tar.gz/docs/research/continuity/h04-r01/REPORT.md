# H04-R01 v1 — findings and limits

Reference/source review: `860558b4ad1cf4160af30860b00b15c46165acd5`. The pre-implementation gate is in [SPECIFICATION.md](SPECIFICATION.md); the exact saved packet is in [evidence/h04-r01-v1](../evidence/h04-r01-v1/). This is an executed mathematical model, not CPU/device measurement or a test of Hanoi's historical tier controller.

## Quantitative findings

All **96 operations × four arms = 384 evaluations** agree with arbitrary-precision integer addition. Independent file verification also checks **192 adaptation-disabled equalities**, **57 exact rational r points**, **seven declared overhead profiles**, and all **1,596 family/profile/ratio points** (6,384 requested pairwise contrasts, plus interactions and binary-envelope comparisons). Binary/ternary domain widths are [8,16,32,64] / [6,11,21,41].

Retained payload counts are symbol-slots summed over 24 operations per family. FB=4,608 binary slots and FT=2,952 ternary slots in every family. Both adaptive arms carry 96 binary metadata bits per family. They make identical mode decisions and acquire identical selection information.

| Family | AB payload bits | AT payload trits | Payload-only AT/AB crossover r | Selector calls | Promotions / demotions |
| --- | ---: | ---: | --- | ---: | --- |
| constant-small | 576 | 432 | 4/3 | 24 | 0 / 1 |
| constant-large | 4608 | 2952 | 64/41 | 24 | 0 / 0 |
| phased | 2272 | 1492 | 568/373 | 30 | 6 / 4 |
| alternating | 2840 | 1847 | 2840/1847 | 27 | 14 / 12 |

FT/FB's payload-only crossover is 64/41 everywhere. For each positive threshold t, ternary's corresponding storage comparison wins at r<t, ties at r=t, and loses at r>t. These are conditional cell-cost statements, not observed device advantages.

Metadata/selector/transition costs cancel in AT versus AB when their coefficients are identical, because the two arms have equal tags, calls and transitions. They do not cancel in adaptive-versus-fixed comparisons. Conversion visits differ by symbol alphabet and width; their coefficients are unknown. In a compatible abstract unit U, AT beats AB precisely when:

`r * P_AT + (O_AT - O_AB) < P_AB`.

The report provides the exact count vector rather than asserting physical values for O. In the explicit adverse `ternary_conversion_only` profile, AT loses against AB at **every positive grid point**, in all four families. Equal unit conversion coefficients produce more favorable regions; those coefficients are equally hypothetical. Both outcomes remain in analysis.json. The grid includes points below, at and above every positive finite crossover of all four declared contrasts/profile/family combinations, without clipping unfavorable regions.

## What adaptation does and does not establish

With metadata costed and other event coefficients left unpriced, constant-large AB costs 4,704 U versus FB's 4,608 U; AT costs `2952*r+96` versus FT's `2952*r`. Thus both adaptive arms lose to their fixed counterparts for every r>0 in that profile. The zero-overhead limit ties, not an adaptive win. Constant-small/phased/alternating gain over the globally fixed D64 policy; this demonstrates a generic precision-selection effect, not ternary-specific computation.

AT versus the strongest of the **two tested** binary arms is tighter than AT/AB alone for constant-large: r must be below 188/123 with metadata included. The other three families retain the AT/AB thresholds above in the metadata-only profile. This envelope is not claimed to be every possible optimized binary policy.

At r=3/2 with metadata included, AT loses to AB on constant-small but wins on phased and alternating; it beats AB on constant-large while still losing to FT. Conditional wins survive adaptive binary in some modeled regions; no unconditional advantage follows.

Interaction alone can mislead: constant-large at r=2 has interaction 2000/2009 < 1, while AT loses to both AB and FT. A test explicitly retains this counterexample. It is not interpreted as evidence for a radix-specific advantage.

## Packing and capacity controls

At 127+1, both adaptive arms start in D8 and promote to D16. Ternary's result needs only six trits as a mathematical value but its selected D16 mode needs eleven. The spare native code capacity cannot silently enlarge ternary's logical domain. At the largest boundary, 2^63-1+1 is rejected by every arm, even if a trit buffer could encode it.

Binary primary payloads are bit packed, not byte padded. Secondary host controls apply the same q=1,8,64 alignment to both arms. Optimal recoding of the shared D_b domains uses exactly b binary bits per independently addressable value for both representations. Therefore **no binary-host storage advantage is established** by native-trit counts. Packing the entire trit alphabet instead can cost more: a D64 ternary slot has 41 trits, needs 66 bits to encode all trit patterns, and rounds to 128 bits at q=64; the matched binary domain needs 64 bits. This is a consequence of the declared encoding/access contract, not a universal best ternary codec.

Per-value domain lower bounds are codebook bounds, not empirical entropy estimates for repeated known traces. Block compression, recomputing outputs, constant-family specialization, output-only shrinking, a different tag codec and optimized mode boundaries may change results. They are not secretly granted to one arm.

## Verification, observed failures and reproducibility

The producer uses digit adders, while a separate verifier imports no producer helpers and checks saved encodings, results, counts, modes, packing, profiles and the whole sweep. Tests include all 256 binary 8-bit encodings, 1,092 balanced encodings through six trits, all 65,536 8-bit operand pairs for both adders, 500 seeded 64-bit pairs, signed endpoints, overflow rejection, disabled adaptation, mode relabeling, hand-calculated finite thresholds, accounting mutations and repeated subprocess byte equality. This is an independent code/oracle path, not an independent laboratory or author.

Final local result: **19 tests pass, zero failures**, on Python 3.14.3 / macOS ARM64. Two deliberately corrupted temporary source copies make the original verification test exit 1: arithmetic corruption is rejected by the overflow guard, and transition-accounting corruption by independent count verification. Mutation logs and return codes are preserved.

One earlier normal-suite run had 18 passes and one test-expectation failure: it expected the literal `ArithmeticError` diagnostic, but the arithmetic mutant was rejected earlier with `OverflowError`. The expectation was corrected to the observed explicit guard rejection; no arithmetic/authorization/overflow control was relaxed. The original failed output is retained in verification/initial-mutation-expectation-failure.txt.

Clean-checkout validation was actually executed at implementation/data commit `6875b46d6a8a0e57dd7a21b2322c54709fca369e`; see [VERIFICATION.md](VERIFICATION.md). Both fresh outputs match each other and the checked-in data bytes, and all 19 tests pass in that checkout. This is one-host reproduction, not an untested cross-platform guarantee. Generated files contain no timestamp or absolute workspace path; manifests exclude themselves. Historical charter/register/evidence remain preserved; the old packet manifest still describes reference commit 860558b4, while the new versioned packet manifest describes this revision.

## H04 disposition and next experiment

H04-R01 gains **conditional modeled storage evidence**, with negative evidence against any claim that adaptation always helps. The favorable regions depend on imposed cell and conversion coefficients. Original Hanoi tier optimization and any physical/computational advantage remain **inconclusive**; those semantics and hardware costs were not tested. This result is not evidence of a new complexity class, accelerated CPU kernel or measured energy reduction.

Next single falsifiable experiment: optimize the four capacity boundaries symmetrically for binary and ternary under the same metadata budget and the same traces, while retaining the current policy as a control. Test whether the AT-versus-AB conditional window persists or is a coarse-mode-layout artifact. Define those new domains before implementation. Do not modify a VM, scheduler, frozen ISA or Protocol 001.
