# Continuity register changelog

- **2026-10-25 / 1.0.0:** Preserve user charter 1.0 unchanged. Add pinned six-repository source inventory and eight-entry H01–H08 register. Recover earlier Foundation legacy objects, a corroborated language extraction and a documented VM adaptation boundary. Reproduce isolated arithmetic counterexamples and exact H01 finite-capacity costs. Select H04-R01 with fixed/adaptive binary and ternary controls. Append session handoff. Preserve prior research/CI reports and their failed results; do not reinterpret missing artifacts as verified evidence.

Future entries must identify revised hypotheses, old and new falsifiers, changed source pins, evidence provenance and reasons for revision. Do not replace an earlier failed claim with a success story without recording the change.

- **2026-10-25 / 1.1.0:** Implement H04-R01 with explicit online operand selection/computed-result promotion, 96 shared operations, four arms, bit-packing controls, conditional full rational sweep, separate verification and deliberate defect checks. Preserve the initial test-expectation failure. H04 gains conditional modeled evidence and negative controls; original Hanoi/physical claims remain open. No production or Protocol 001 changes.

  Clean checkout at implementation commit 6875b46d reproduced all canonical bytes and 19 tests. Appended actual verification and a read-only maintenance snapshot; external PR merges are observed, not actions of this research task.
