#!/usr/bin/env python3
"""Capture first, then compare fresh unchanged-hosted-VM observations."""
import hashlib
import json
import os
import subprocess
from pathlib import Path
from oracle import normalized

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    freeze = json.loads((ROOT / "freeze-manifest.json").read_text())
    for name, expected in freeze["files"].items():
        if sha(ROOT / name) != expected["sha256"]:
            raise RuntimeError("frozen input changed: " + name)
    artifact = ROOT / "program.raw13"
    digest = sha(artifact)
    env = dict(os.environ)
    env.pop("T81_CANONFS_ROOT", None)
    commands, all_rows = [], []
    for i in range(1, 4):
        command = [str(ROOT / "hosted_observer"), str(artifact)]
        process = subprocess.run(command, env=env, text=True, capture_output=True, timeout=30)
        (ROOT / f"evidence/hosted-{i}.raw.jsonl").write_text(process.stdout)
        (ROOT / f"evidence/hosted-{i}.stderr.txt").write_text(process.stderr)
        commands.append(dict(command=command, cwd=str(Path.cwd()),
                             environment_override={"T81_CANONFS_ROOT": None},
                             exit_code=process.returncode, stdout_file=f"evidence/hosted-{i}.raw.jsonl",
                             stderr_file=f"evidence/hosted-{i}.stderr.txt"))
        if process.returncode:
            (ROOT / "evidence/hosted-commands.json").write_text(json.dumps(commands, indent=2)+"\n")
            raise RuntimeError(f"hosted run {i}: exit {process.returncode}; raw output retained")
        all_rows.append([json.loads(line) for line in process.stdout.splitlines()])
    (ROOT / "evidence/hosted-commands.json").write_text(json.dumps(commands, indent=2)+"\n")
    # Oracle expected values are read only after all three raw runs are retained.
    oracle = json.loads((ROOT / "oracle-normalized.json").read_text())
    listing = json.loads((ROOT / "instruction-listing.json").read_text())
    expected_records = [[r[k] for k in ("opcode", "a", "b", "c", "literal_kind")] for r in listing]
    differences, checks = [], []

    def diff(a, b, path=""):
        if type(a) is not type(b):
            return [dict(path=path, oracle=a, hosted=b)]
        if isinstance(a, dict):
            result = []
            for key in sorted(set(a) | set(b)):
                if key not in a or key not in b:
                    result.append(dict(path=path+"/"+key, oracle=a.get(key), hosted=b.get(key)))
                else:
                    result.extend(diff(a[key], b[key], path+"/"+key))
            return result
        if isinstance(a, list):
            if len(a) != len(b):
                return [dict(path=path+"/length", oracle=len(a), hosted=len(b))]
            return [d for i,(x,y) in enumerate(zip(a,b)) for d in diff(x,y,path+f"/{i}")]
        return [] if a == b else [dict(path=path, oracle=a, hosted=b)]

    for run, rows in enumerate(all_rows, 1):
        converted = [normalized(row, digest) for row in rows]
        (ROOT / f"evidence/hosted-{run}.normalized.json").write_text(json.dumps(converted, indent=2)+"\n")
        found = diff(oracle, converted)
        for d in found:
            d["run"] = run
            d["classification"] = "unresolved_discrepancy"
        differences.extend(found)
        meta = rows[0]
        controls = dict(
            bytes_length=meta["input_bytes"] == len(artifact.read_bytes()) == 351,
            instruction_records=meta["instruction_records"] == 27,
            existing_decoder_records=meta["decoded_records"] == expected_records,
            existing_encoder_roundtrip=meta["existing_encoder_roundtrip"] is True,
            pools_metadata_empty=meta["all_pools_metadata_empty"] is True,
            explicit_allow_all=meta["admission"] == "explicit_allow_all",
            no_canonfs_root=meta["canonfs_root"] is None,
            fresh_initial_plus_steps=len(rows) == 25,
            instruction_trace=all(row["trace_last"] == dict(pc=row["pc_before"],
                                  opcode=row["instruction"]["opcode"], trap=None) for row in rows[1:]),
            formula_conditions=all(all(row["diagnostics"][key] == 0 for key in
                ("tier", "call_depth", "stack_frames", "contradiction_events", "gc_cycles"))
                and not row["diagnostics"]["policy_loaded"] for row in rows),
            final_halt=rows[-1]["status"] == "halted" and rows[-1]["state"]["halted"] is True,
            raw_stderr_empty=(ROOT / f"evidence/hosted-{run}.stderr.txt").stat().st_size == 0,
        )
        checks.append(dict(run=run, observation_count=len(rows), controls=controls,
                           differing_fields=len(found), raw_sha256=sha(ROOT/f"evidence/hosted-{run}.raw.jsonl")))
    result = dict(program_sha256=digest, oracle_frozen_before_host=True,
                  all_equal=not differences and all(all(r["controls"].values()) for r in checks),
                  runs=checks, differences=differences,
                  classifications=["oracle_error", "artifact_construction_error", "unsupported_observation",
                                   "hosted_implementation_defect", "unresolved_discrepancy"],
                  classification_note="No difference is assigned a defect cause automatically; investigate before attribution.")
    (ROOT / "hosted-comparison.json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result, indent=2))
    if not result["all_equal"]:
        raise RuntimeError("hosted/oracle disagreement; frozen oracle and raw records preserved")


if __name__ == "__main__":
    main()
