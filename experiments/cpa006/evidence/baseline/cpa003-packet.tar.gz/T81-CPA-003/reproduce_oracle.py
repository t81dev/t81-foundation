#!/usr/bin/env python3
"""Re-derive in a fresh directory without changing any frozen packet file."""
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

root = Path(__file__).resolve().parent
out = Path(tempfile.mkdtemp(prefix="t81-cpa-003-oracle-replay-"))
(out / "original").mkdir()
shutil.copyfile(root / "oracle.py", out / "oracle.py")
shutil.copyfile(root / "original/T81-CPA-001-experiment-proposal.json",
                out / "original/T81-CPA-001-experiment-proposal.json")
p = subprocess.run([sys.executable, "-B", str(out / "oracle.py")], capture_output=True, text=True)
if p.returncode:
    raise RuntimeError((p.returncode, p.stdout, p.stderr))
manifest = json.loads((root / "freeze-manifest.json").read_text())
checks = []
for name, expected in manifest["files"].items():
    actual = hashlib.sha256((out / name).read_bytes()).hexdigest()
    checks.append(dict(path=name, expected=expected["sha256"], actual=actual,
                       matches=actual == expected["sha256"]))
result = dict(output_directory=str(out), checks=checks, all_equal=all(x["matches"] for x in checks))
print(json.dumps(result, indent=2))
if not result["all_equal"]:
    raise RuntimeError("independent regeneration differs; frozen input remains untouched")
