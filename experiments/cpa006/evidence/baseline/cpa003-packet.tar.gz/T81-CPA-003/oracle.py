#!/usr/bin/env python3
"""Host-side mathematical oracle for the fixed CPA-001 proposal, not a VM backend.

Does not read hosted observations or the proposal's expected numeric results.
Only the proposed instruction listing is imported; the semantic model and byte
reader are separate from the C++ decoder/interpreter under assessment.
"""
import copy
import hashlib
import json
import re
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OPCODES = {
    "Halt": 1, "LoadImm": 2, "Load": 3, "Store": 4,
    "Add": 5, "Mul": 7, "Div": 8, "Mod": 9,
    "JumpIfZero": 11, "Cmp": 15, "TNot": 18,
    "TAnd": 19, "TOr": 20, "TXor": 21,
    "JumpIfNotZero": 25, "Trap": 28, "JumpIfNegative": 60,
}
MASK64 = 2**64 - 1
OFFSET = 1469598103934665603  # Exact runtime constant; NOT standard FNV's offset.
PRIME = 1099511628211


def require(condition, detail):
    if not condition:
        raise RuntimeError(detail)


def write_json(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def signature(words):
    """Hash u64 words as eight LE octets each, with u64 modular arithmetic."""
    h = OFFSET
    for word in words:
        for octet in (word & MASK64).to_bytes(8, "little"):
            h = ((h ^ octet) * PRIME) % (2**64)
    positive = h & (2**63 - 1)
    return positive if positive else 1


def flags(value):
    return dict(zero=value == 0, negative=value < 0, positive=value > 0)


def decode_independently(blob):
    require(len(blob) % 13 == 0, "partial instruction")
    inverse = {value: name for name, value in OPCODES.items()}
    records = []
    for off in range(0, len(blob), 13):
        opcode = blob[off]
        require(opcode in inverse, "outside fixed oracle subset")
        operands = [int.from_bytes(blob[off + pos:off + pos + 4],
                                   "little", signed=True) for pos in (1, 5, 9)]
        records.append(dict(pc=off // 13, name=inverse[opcode], opcode=opcode,
                            a=operands[0], b=operands[1], c=operands[2], literal_kind=0))
    return records


def normalized(record, digest):
    state = record["state"]
    return {
        "schema": "t81.cpa003.observation.v1", "program_sha256": digest,
        "sequence": record["sequence"], "pc_before": record["pc_before"],
        "instruction": record["instruction"], "status": record["status"],
        "trap": record["trap"],
        "state": {
            "pc": state["pc"], "sp": state["sp"], "halted": state["halted"],
            "flags": state["flags"],
            "register_values": [str(v) for v in state["register_values"]],
            "register_tags": state["register_tags"],
            "memory": {
                "word_count": len(state["memory_values"]),
                "default_value": "0", "default_tag": 0,
                "overrides": [dict(address=i, value=str(v), tag=t)
                              for i, (v, t) in enumerate(zip(state["memory_values"], state["memory_tags"]))
                              if v != 0 or t != 0],
            },
        },
    }


def main():
    proposal = json.loads((ROOT / "original/T81-CPA-001-experiment-proposal.json").read_text())
    parsed = re.findall(r"(?<!\d)(\d+) ([A-Za-z]\w*)\((-?\d+),(-?\d+),(-?\d+)\)", proposal["method"])
    require([int(p[0]) for p in parsed] == list(range(27)), "proposal listing is not exact 0..26")
    records = [dict(pc=int(pc), name=name, opcode=OPCODES[name], a=int(a), b=int(b),
                    c=int(c), literal_kind=0) for pc, name, a, b, c in parsed]
    blob = b"".join(struct.pack("<Biii", r["opcode"], r["a"], r["b"], r["c"]) for r in records)
    require(len(blob) == 351, "artifact size")
    require(decode_independently(blob) == records, "independent signed-operand roundtrip")
    (ROOT / "program.raw13").write_bytes(blob)
    (ROOT / "program.hex").write_text(blob.hex() + "\n")
    digest = hashlib.sha256(blob).hexdigest()
    (ROOT / "program.sha256").write_text(digest + "  program.raw13\n")
    for r in records:
        r["record_hex"] = blob[13*r["pc"]:13*(r["pc"]+1)].hex()
    write_json("instruction-listing.json", records)

    n = len(records)
    lineage_words = [n]
    for r in records:
        lineage_words.extend([r["opcode"], r["a"], r["b"], r["c"], 0])
    lineage = signature(lineage_words)
    state = dict(pc=0, sp=n+256, halted=False, flags=dict(zero=False, negative=False, positive=False),
                 register_values=[0]*81, register_tags=[0]*81,
                 memory_values=[0]*(n+1536), memory_tags=[0]*(n+1536))

    def sync(tick):
        # This program has no recursion, contradiction, policy or tier promotion:
        # branch entropy is zero (all three conditional branches are taken),
        # shape/rank/symbolic use is zero, and it runs below GC/JIT thresholds.
        state["register_values"][0] = 0
        state["register_values"][75:81] = [tick, lineage, signature([tick, 0, 0, 0, state["pc"], 0]), 0, 0,
                                          0 if state["halted"] else 1]

    sync(0)
    initial = dict(sequence=0, pc_before=None, instruction=None, status="running", trap=None,
                   state=copy.deepcopy(state), inputs=[], operation="fresh load: empty pools/metadata; allow-all",
                   writes=[], system_writes=[], memory_writes=[])
    trace = [initial]
    while not state["halted"]:
        require(len(trace) <= 64, "instruction limit")
        pc = state["pc"]
        require(0 <= pc < n, "unexpected control exit")
        insn = records[pc]
        name, a, b, c = (insn[k] for k in ("name", "a", "b", "c"))
        before = copy.deepcopy(state)
        rv = state["register_values"]
        inputs, writes, memory_writes = [], [], []

        def read(index):
            require(0 <= index <= 80, "register domain")
            inputs.append(dict(register=index, value=rv[index], tag=state["register_tags"][index]))
            require(state["register_tags"][index] == 0, "not Int")
            return rv[index]

        def put(index, value):
            require(index in range(1, 75), "unexpected protected/extended register write")
            require(-(2**63) <= value < 2**63, "outside admitted Int domain")
            rv[index] = value
            state["register_tags"][index] = 0
            state["flags"] = flags(value)
            writes.append(dict(register=index, value=value, tag=0))

        state["pc"] += 1
        trap = None
        if name == "LoadImm":
            put(a, b)
            operation = f"R{a} := {b}"
        elif name in ("TNot", "TAnd", "TOr", "TXor"):
            x = read(b)
            require(x in (-1, 0, 1), "not a canonical scalar trit")
            if name == "TNot":
                value = -x
                operation = f"negate trit {x} -> {value}"
            else:
                y = read(c)
                require(y in (-1, 0, 1), "not a canonical scalar trit")
                value = {"TAnd": min(x,y), "TOr": max(x,y), "TXor": (x-y+1)%3-1}[name]
                operation = f"{name}({x},{y}) -> {value}"
            put(a, value)
        elif name in ("Add", "Mul", "Div", "Mod"):
            x, y = read(b), read(c)
            if name == "Add": value = x+y
            elif name == "Mul": value = x*y
            else:
                require(y != 0, "unanticipated zero divisor in fixed artifact")
                q = (abs(x)//abs(y)) * (-1 if (x<0) != (y<0) else 1)
                value = q if name == "Div" else x-q*y
            operation = f"{name}({x},{y}) -> {value}"
            put(a, value)
        elif name == "Store":
            value = read(b)
            require(n <= a < n+1536, "memory permission/domain")
            state["memory_values"][a] = value
            state["memory_tags"][a] = 0
            memory_writes.append(dict(address=a, value=value, tag=0))
            operation = f"MEM[{a}] := R{b} = {value}; flags preserved"
        elif name == "Load":
            require(n <= b < n+1536, "memory permission/domain")
            value, tag = state["memory_values"][b], state["memory_tags"][b]
            inputs.append(dict(address=b, value=value, tag=tag))
            require(tag == 0, "non-Int memory")
            put(a, value)
            operation = f"R{a} := MEM[{b}] = {value}"
        elif name == "Cmp":
            x, y = read(a), read(b)
            state["flags"] = flags((x>y)-(x<y))
            operation = f"compare {x} with {y}; no general register write"
        elif name in ("JumpIfZero", "JumpIfNotZero", "JumpIfNegative"):
            if name == "JumpIfNegative":
                take = state["flags"]["negative"]
                inputs.append(dict(flag="negative", value=take))
            else:
                value = read(b)
                take = value == 0 if name == "JumpIfZero" else value != 0
            if take:
                require(0 <= a <= n, "code target")
                state["pc"] = a
            operation = f"{name}: taken={take}; flags preserved"
        elif name == "Halt":
            state["halted"] = True
            operation = "set global halted; flags and SP preserved"
        elif name == "Trap":
            trap = "TrapInstruction"
            operation = "explicit trap (not expected on admitted path)"
        else:
            raise RuntimeError("outside fixed model")
        tick = len(trace)
        sync(tick)
        row = dict(sequence=tick, pc_before=pc,
                   instruction={k: insn[k] for k in ("opcode", "name", "a", "b", "c")},
                   status="trap" if trap else ("halted" if state["halted"] else "running"), trap=trap,
                   inputs=inputs, operation=operation, writes=writes, memory_writes=memory_writes,
                   flags_before=before["flags"], flags_after=state["flags"],
                   system_writes=[dict(register=i, before=before["register_values"][i], after=rv[i], tag=0)
                                  for i in range(75,81) if before["register_values"][i] != rv[i]],
                   state=copy.deepcopy(state))
        trace.append(row)
        require(trap is None, "fixed positive artifact unexpectedly traps")

    write_json("oracle-trace.json", trace)
    write_json("oracle-normalized.json", [normalized(row, digest) for row in trace])
    reached = {row["pc_before"] for row in trace[1:]}
    write_json("oracle-summary.json", dict(
        artifact_length=len(blob), program_sha256=digest, executed_instructions=len(trace)-1,
        final_pc=state["pc"], final_sp=state["sp"], flags=state["flags"],
        nonzero_general_registers={str(i):v for i,v in enumerate(rv[:75]) if v},
        system_registers={str(i):rv[i] for i in range(75,81)},
        memory_overrides=normalized(trace[-1], digest)["state"]["memory"]["overrides"],
        executed_pcs=[row["pc_before"] for row in trace[1:]],
        unreachable_pcs=sorted(set(range(n))-reached), all_tags="Int (0)"))
    print(json.dumps(json.loads((ROOT / "oracle-summary.json").read_text()), indent=2))


if __name__ == "__main__":
    main()
