#!/usr/bin/env python3
"""Validate actual schemas offline; no experiment or governance activation."""
import hashlib
import importlib.metadata
import json
import sys
from pathlib import Path
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parent
version = importlib.metadata.version("jsonschema")
if version != "4.23.0":
    raise RuntimeError("use declared jsonschema==4.23.0, observed " + version)
proposal_path = ROOT / "original/experiment-proposal.schema.json"
proposal_schema = json.loads(proposal_path.read_text())
record_path = ROOT / "normalized-record.schema.json"
record_schema = json.loads(record_path.read_text())
Draft202012Validator.check_schema(proposal_schema)
Draft202012Validator.check_schema(record_schema)
results = []
for name in ["original/T81-CPA-001-experiment-proposal.json", "proposal.json"]:
    errors = sorted(Draft202012Validator(proposal_schema).iter_errors(json.loads((ROOT/name).read_text())), key=lambda e:str(e.path))
    results.append(dict(path=name, valid=not errors, errors=[str(e) for e in errors]))
for name in ["oracle-normalized.json"] + [f"evidence/hosted-{i}.normalized.json" for i in range(1,4)]:
    rows = json.loads((ROOT/name).read_text())
    errors = [dict(sequence=row["sequence"], error=str(e)) for row in rows
              for e in Draft202012Validator(record_schema).iter_errors(row)]
    results.append(dict(path=name, records=len(rows), valid=not errors, errors=errors))
for run in range(1,4):
    name = f"evidence/hosted-{run}.raw.jsonl"
    rows = [json.loads(line) for line in (ROOT/name).read_text().splitlines()]
    errors = []
    for row in rows:
        s = row["state"]
        for key, count in [("register_values",81), ("register_tags",81),
                           ("memory_values",1563), ("memory_tags",1563)]:
            if len(s[key]) != count:
                errors.append(f"step {row['sequence']}: {key} length")
        for key in ("register_values", "memory_values"):
            if not all(type(v) is int and -(2**63) <= v < 2**63 for v in s[key]):
                errors.append(f"step {row['sequence']}: {key} signed-int64 domain")
        for key in ("register_tags", "memory_tags"):
            if not all(type(v) is int and v == 0 for v in s[key]):
                errors.append(f"step {row['sequence']}: {key} Int domain")
        if not all(type(v) is bool for v in s["flags"].values()):
            errors.append(f"step {row['sequence']}: flags not Boolean")
    results.append(dict(path=name, records=len(rows), valid=not errors, errors=errors,
                        check="full raw array lengths/domains checked before accepting sparse projection; no zip truncation masking"))
result = dict(python=sys.version, interpreter=sys.executable, jsonschema_version=version,
    proposal_schema_sha256=hashlib.sha256(proposal_path.read_bytes()).hexdigest(),
    observation_schema_sha256=hashlib.sha256(record_path.read_bytes()).hexdigest(),
    validation="Draft202012Validator.check_schema plus iter_errors against actual JSON documents",
    results=results, all_valid=all(r["valid"] for r in results),
    limitation="Schema validation establishes shape only, not correctness, authentic authorization, independent review or experimental acceptance.")
(ROOT / "proposal-validation.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps(result, indent=2))
if not result["all_valid"]:
    raise RuntimeError("actual JSON Schema validation failed")
