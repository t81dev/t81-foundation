# T81-CPA-001 — Executed validation

Baseline: `803075e9f7e36ed4b5318a8d2ddaacf62ae0a7e4`, extracted using `git archive` to `/tmp/t81-cpa-803075e-fbzvi39l`. No repository files changed. This file is an observation/command record assembled by the executing agent, not a verbatim full build transcript or independent review.

Environment: Darwin 25.5.0 ARM64; Homebrew clang 22.1.1; CMake 4.3.0; Python 3.14.3.

## Build checks

Executed in the clean archive directory:

```sh
cmake -S . -B /tmp/t81-cpa-build -G Ninja -DCMAKE_BUILD_TYPE=Debug -DCMAKE_C_COMPILER=/opt/homebrew/opt/llvm/bin/clang -DCMAKE_CXX_COMPILER=/opt/homebrew/opt/llvm/bin/clang++ -DT81_BUILD_TESTS=OFF -DT81_BUILD_TUI=OFF -DT81_BUILD_EXAMPLES=OFF -DT81_BUILD_BENCHMARKS=OFF -DT81_BUILD_FUZZ_TESTS=OFF -DT81_ENABLE_TERNARYOS=ON -DT81_ENABLE_DPE=OFF
cmake --build /tmp/t81-cpa-build --target t81_vm -j 4
cmake --build /tmp/t81-cpa-build --target t81_ternaryos_qemu_slice6_efi -j 4
```

All three returned exit 0. Hosted VM build completed 65 actions. EFI build completed 66 actions, including hosted snapshot generation and the separate freestanding link. The two target builds overlapped in the same build directory and shared some dependency outputs; they are not independent clean-build replications. A reproduction should run these commands sequentially. No claim of reproducible build-byte identity is made.

CMake global flags include O3/NDEBUG even for the configured Debug build. T81_STRICT_DETERMINISTIC_FLOAT defaults ON and supplies T81_DETERMINISTIC. Unit-test sources below were separately compiled with UNDEBUG where assertions are intended to execute.

## Existing standalone tests

```sh
/opt/homebrew/opt/llvm/bin/clang++ -std=c++23 -O0 -UNDEBUG -Iinclude tests/cpp/tisc_encoding_test.cpp isa/encoding.cpp -o /tmp/t81-cpa-encoding-test
/tmp/t81-cpa-encoding-test
/opt/homebrew/opt/llvm/bin/clang++ -std=c++23 -O0 -UNDEBUG -Iinclude tests/cpp/ternary_arith_test.cpp -o /tmp/t81-cpa-ternary-arith-test
/tmp/t81-cpa-ternary-arith-test
```

Each compile and execution returned exit 0. Encoding test emitted no output. Arithmetic test emitted `ternary_arith ok`.

```sh
/opt/homebrew/opt/llvm/bin/clang++ -std=c++23 -O0 -UNDEBUG -Iinclude tests/cpp/tisc_opcode_matrix_test.cpp isa/encoding.cpp -o /tmp/t81-cpa-opcode-matrix-test
/tmp/t81-cpa-opcode-matrix-test
```

Compile exit 0; execution exit 134, with:

```text
Assertion failed: (decoded.has_value()), function test_full_opcode_roundtrip_encoding, file tisc_opcode_matrix_test.cpp, line 64.
```

The numerical kAllOpcodes interval includes undefined values 221–223; the decoder rejects unknown opcode names. This is the source-based explanation of the observed failure. No correction was made.

```sh
/opt/homebrew/opt/llvm/bin/clang++ -std=c++23 -O0 -DNDEBUG -Iinclude tests/cpp/tisc_opcode_matrix_test.cpp isa/encoding.cpp -o /tmp/t81-cpa-opcode-matrix-ndebug-test
/tmp/t81-cpa-opcode-matrix-ndebug-test
```

Compile and execution exit 0; output `tisc opcode matrix tests passed!`. The test's assert expressions are disabled in this variant. This comparison establishes the difference for these exact two builds, not the provenance or condition of an earlier audit binary.

```sh
python3 -B scripts/ci/check_tisc_freeze_integrity.py
```

Exit 0:

```text
SUCCESS: TISC v1.1.0 Freeze Integrity Verified.
- Count: 209 opcodes
- Bitwise Ops: Verified
- Reserved Range: Clean
```

This script checks the Markdown registry and does not validate header/registry equivalence. Its passing message is not resolution of the failed C++ matrix or the conflicting capability document.

## Existing hosted execution tests

```sh
/opt/homebrew/opt/llvm/bin/clang++ -std=c++23 -O0 -UNDEBUG -DT81_DETERMINISTIC -Iinclude -c tests/cpp/tisc_semantic_equivalence_test.cpp -o /tmp/t81-cpa-semantic-equivalence.o
/opt/homebrew/opt/llvm/bin/clang++ /tmp/t81-cpa-semantic-equivalence.o -L/tmp/t81-cpa-build -L/opt/homebrew/opt/llvm/lib/c++ -Wl,-rpath,/opt/homebrew/opt/llvm/lib/c++ -lt81_vm -lt81_isa -lt81_axion -lt81_ffi -lt81_experimental -lt81_core -o /tmp/t81-cpa-semantic-equivalence-test
env -u T81_CANONFS_ROOT /tmp/t81-cpa-semantic-equivalence-test
/opt/homebrew/opt/llvm/bin/clang++ -std=c++23 -O0 -UNDEBUG -DT81_DETERMINISTIC -Iinclude -c tests/cpp/vm_load_store_test.cpp -o /tmp/t81-cpa-load-store.o
/opt/homebrew/opt/llvm/bin/clang++ /tmp/t81-cpa-load-store.o -L/tmp/t81-cpa-build -L/opt/homebrew/opt/llvm/lib/c++ -Wl,-rpath,/opt/homebrew/opt/llvm/lib/c++ -lt81_vm -lt81_isa -lt81_axion -lt81_ffi -lt81_experimental -lt81_core -o /tmp/t81-cpa-load-store-test
env -u T81_CANONFS_ROOT /tmp/t81-cpa-load-store-test
```

All compiles, links and executions returned exit 0. Executions emitted no output. Test sources were unchanged. The semantic test exercises Add=42, divide-by-zero trapping, a conditional jump, and Option/Result semantics. The memory test exercises Store/Load and BoundsFault. These are hosted results only.

## EFI artifact inspection

```sh
/opt/homebrew/opt/llvm/bin/llvm-readobj --file-headers --coff-imports /tmp/t81-cpa-build/ternaryos/qemu_slice6/BOOTAA64.EFI
shasum -a 256 /tmp/t81-cpa-build/ternaryos/qemu_slice6/BOOTAA64.EFI
```

Both exit 0. Artifact: COFF-ARM64 / aarch64, 64-bit, EFI_APPLICATION, image size 212,992 bytes, no import table entries (`ImportTableRVA=0`, `ImportTableSize=0`). This supports freestanding link completion; it does not show boot success or TISC execution. PE stack/heap reserve fields do not establish an implemented guest allocator.

Observed EFI SHA-256: `509a1d4062838938dfeb31170dec76bab3518be60876bfe64309a8051b99361e`.

No QEMU guest, VirtualBox guest or physical-device execution was performed. Existing guest boot evidence remains source-reported evidence.

## Commons discovery limitation

The following loop was executed from the original repository, because Commons requires local historical Git objects; -B suppresses Python cache writes:

```python
import subprocess, json
for op, args in [
    ('list_research_tracks', {}),
    ('list_hypotheses', {}),
    ('get_hypothesis', {'hypothesis_id': 'H07'}),
    ('list_open_research_questions', {}),
    ('get_reproduction_instructions', {'hypothesis_id': 'H07'}),
    ('get_evidence', {'evidence_id': 'register'}),
]:
    subprocess.run(['python3', '-B', 'tools/research_commons/commons.py', '--request',
        json.dumps({'protocol': 't81.research-commons.v1', 'operation': op, 'arguments': args})])
```

Each child exited 1 before returning a discovery envelope, with `ModuleNotFoundError: No module named 'jsonschema'`. No automatic installation, history fetch, or accepted-record edit was performed. The schema declares jsonschema==4.23.0 in its documented requirements. Direct source/manifest inspection substituted for unavailable discovery, not for successful CLI verification.

The separate proposal JSON was checked for required and extra top-level keys: all required keys present, no extra keys. This is not JSON Schema validation; no schema-conformance claim is made.

## Source identity hashes

```text
d9fd81f87e9b6b47c55c8ddf5e7bdeef95e0ce48a965b1973e23526c32f2a391  isa/encoding.cpp
797d3fe424136cb9109811b1bc47de4b453791d12bc0f860c7dcc96947de6aec  isa/binary_io.cpp
f9459c3b93c583f36addf19df1a5f5930a298eee5e3916abb8139f3eeb46e35a  include/t81/isa/opcodes.hpp
2ed93572891bc9e32f7525270c7ff6a88edb3d5f22529e3f19195f71cb1ff998  vm/vm.cpp
b9b740d869b1f949b1f299d9b536d623264d5e3fc9bc96a0611f93a5cb7beee6  ternaryos/CMakeLists.txt
05f1812488bbf0ea19cdf50e609b93617db122196c3b9bd9f9462f92e3ce78f3  tests/cpp/tisc_opcode_matrix_test.cpp
```

The original working-tree `git status --short` was unchanged at the final check. No commit, PR, merge, RFC change, interpreter repair or new experiment execution occurred.
