#!/usr/bin/env python3
"""Verify packet identities only; this does not certify scientific conclusions."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / "packet-manifest.json").read_text())
checked = 0
for name, expected in manifest["files"].items():
    path = root / name
    if not path.is_file():
        raise RuntimeError("missing packet file: " + name)
    data = path.read_bytes()
    if len(data) != expected["bytes"] or hashlib.sha256(data).hexdigest() != expected["sha256"]:
        raise RuntimeError("packet file identity differs: " + name)
    checked += 1
freeze = json.loads((root / "freeze-manifest.json").read_text())
for name, expected in freeze["files"].items():
    if hashlib.sha256((root/name).read_bytes()).hexdigest() != expected["sha256"]:
        raise RuntimeError("pre-host freeze identity differs: " + name)
print(json.dumps(dict(packet_files=checked, pre_host_frozen_files=len(freeze["files"]),
                     all_hashes_match=True, limitation="content identity only")))
