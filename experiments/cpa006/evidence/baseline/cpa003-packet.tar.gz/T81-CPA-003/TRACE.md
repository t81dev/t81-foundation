# CPA-003 complete instruction-level oracle trace

Scope: pinned hosted raw13 implementation profile. Conflicting normative memory
and branch operand descriptions remain unresolved; see discrepancy-register.json.
This trace is not a declaration that every source/specification description agrees.

Derived by `oracle.py` before hosted execution. All general registers initially zero/Int; all 1,563 memory words initially zero/Int. PC=0, SP=283, flags=(false,false,false), global halted=false. Every stored/loaded/written payload here has tag Int=0. The complete before/after values and tags are in `oracle-trace.json`; normalized equivalent states are in `oracle-normalized.json`.

Flag tuples below are **(zero, negative, positive)**. SP stays 283 through every row. A “write” is reported even if the value already matched (for example R41=0). System-register changes are detailed in the next table; R0=0, R76=2110228405636142087, R78=0 and R79=0 throughout.

| Step | PC | Opcode (A,B,C) | Relevant inputs | Operation | General register writes | Memory writes | Flags before→after | Next PC | Status |
|---:|---:|---|---|---|---|---|---|---:|---|
| 1 | 0 | LoadImm (40,-1,0) | — | R40 := -1 | R40=-1:Int | — | FFF→FTF | 1 | running / trap=None |
| 2 | 1 | LoadImm (41,0,0) | — | R41 := 0 | R41=0:Int | — | FTF→TFF | 2 | running / trap=None |
| 3 | 2 | LoadImm (42,1,0) | — | R42 := 1 | R42=1:Int | — | TFF→FFT | 3 | running / trap=None |
| 4 | 3 | TNot (43,40,0) | R40=-1:Int | negate trit -1 -> 1 | R43=1:Int | — | FFT→FFT | 4 | running / trap=None |
| 5 | 4 | TAnd (44,40,42) | R40=-1:Int, R42=1:Int | TAnd(-1,1) -> -1 | R44=-1:Int | — | FFT→FTF | 5 | running / trap=None |
| 6 | 5 | TOr (45,41,42) | R41=0:Int, R42=1:Int | TOr(0,1) -> 1 | R45=1:Int | — | FTF→FFT | 6 | running / trap=None |
| 7 | 6 | TXor (46,42,40) | R42=1:Int, R40=-1:Int | TXor(1,-1) -> -1 | R46=-1:Int | — | FFT→FTF | 7 | running / trap=None |
| 8 | 7 | LoadImm (47,81,0) | — | R47 := 81 | R47=81:Int | — | FTF→FFT | 8 | running / trap=None |
| 9 | 8 | LoadImm (48,2,0) | — | R48 := 2 | R48=2:Int | — | FFT→FFT | 9 | running / trap=None |
| 10 | 9 | Mul (49,47,48) | R47=81:Int, R48=2:Int | Mul(81,2) -> 162 | R49=162:Int | — | FFT→FFT | 10 | running / trap=None |
| 11 | 10 | Add (50,49,44) | R49=162:Int, R44=-1:Int | Add(162,-1) -> 161 | R50=161:Int | — | FFT→FFT | 11 | running / trap=None |
| 12 | 11 | Store (81,50,0) | R50=161:Int | MEM[81] := R50 = 161; flags preserved | — | MEM[81]=161:Int | FFT→FFT | 12 | running / trap=None |
| 13 | 12 | Load (51,81,0) | MEM[81]=161:Int | R51 := MEM[81] = 161 | R51=161:Int | — | FFT→FFT | 13 | running / trap=None |
| 14 | 13 | LoadImm (52,-7,0) | — | R52 := -7 | R52=-7:Int | — | FFT→FTF | 14 | running / trap=None |
| 15 | 14 | Div (53,52,48) | R52=-7:Int, R48=2:Int | Div(-7,2) -> -3 | R53=-3:Int | — | FTF→FTF | 15 | running / trap=None |
| 16 | 15 | Mod (54,52,48) | R52=-7:Int, R48=2:Int | Mod(-7,2) -> -1 | R54=-1:Int | — | FTF→FTF | 16 | running / trap=None |
| 17 | 16 | Cmp (51,50,0) | R51=161:Int, R50=161:Int | compare 161 with 161; no general register write | — | — | FTF→TFF | 17 | running / trap=None |
| 18 | 17 | JumpIfZero (19,41,0) | R41=0:Int | JumpIfZero: taken=True; flags preserved | — | — | TFF→TFF | 19 | running / trap=None |
| 19 | 19 | JumpIfNotZero (21,42,0) | R42=1:Int | JumpIfNotZero: taken=True; flags preserved | — | — | TFF→TFF | 21 | running / trap=None |
| 20 | 21 | Cmp (44,42,0) | R44=-1:Int, R42=1:Int | compare -1 with 1; no general register write | — | — | TFF→FTF | 22 | running / trap=None |
| 21 | 22 | JumpIfNegative (24,0,0) | negative=true | JumpIfNegative: taken=True; flags preserved | — | — | FTF→FTF | 24 | running / trap=None |
| 22 | 24 | Store (82,46,0) | R46=-1:Int | MEM[82] := R46 = -1; flags preserved | — | MEM[82]=-1:Int | FTF→FTF | 25 | running / trap=None |
| 23 | 25 | Store (83,53,0) | R53=-3:Int | MEM[83] := R53 = -3; flags preserved | — | MEM[83]=-3:Int | FTF→FTF | 26 | running / trap=None |
| 24 | 26 | Halt (0,0,0) | — | set global halted; flags and SP preserved | — | — | FTF→FTF | 27 | halted / trap=None |

## System-register observations

All tags remain Int. R75 is the executed tick, R77 uses the post-instruction PC; R80 is based on global halted. No recursion, contradiction, policy-loaded state or tier promotion occurs. The initial state is not assigned sign-derived flags; it starts FFF by construction.

| Boundary | Next PC | R75 | R76 | R77 | R78 | R79 | R80 |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | 0 | 0 | 2110228405636142087 | 1165810651130105283 | 0 | 0 | 1 |
| 1 | 1 | 1 | 2110228405636142087 | 1599399955190492483 | 0 | 0 | 1 |
| 2 | 2 | 2 | 2110228405636142087 | 2032989259250879683 | 0 | 0 | 1 |
| 3 | 3 | 3 | 2110228405636142087 | 2466578563311266883 | 0 | 0 | 1 |
| 4 | 4 | 4 | 2110228405636142087 | 8654825471743332291 | 0 | 0 | 1 |
| 5 | 5 | 5 | 2110228405636142087 | 9088414775803719491 | 0 | 0 | 1 |
| 6 | 6 | 6 | 2110228405636142087 | 298632043009330883 | 0 | 0 | 1 |
| 7 | 7 | 7 | 2110228405636142087 | 732221347069718083 | 0 | 0 | 1 |
| 8 | 8 | 8 | 2110228405636142087 | 6920468255501783491 | 0 | 0 | 1 |
| 9 | 9 | 9 | 2110228405636142087 | 7354057559562170691 | 0 | 0 | 1 |
| 10 | 10 | 10 | 2110228405636142087 | 7787646863622557891 | 0 | 0 | 1 |
| 11 | 11 | 11 | 2110228405636142087 | 8221236167682945091 | 0 | 0 | 1 |
| 12 | 12 | 12 | 2110228405636142087 | 5186111039260234691 | 0 | 0 | 1 |
| 13 | 13 | 13 | 2110228405636142087 | 5619700343320621891 | 0 | 0 | 1 |
| 14 | 14 | 14 | 2110228405636142087 | 6053289647381009091 | 0 | 0 | 1 |
| 15 | 15 | 15 | 2110228405636142087 | 6486878951441396291 | 0 | 0 | 1 |
| 16 | 16 | 16 | 2110228405636142087 | 3451753823018685891 | 0 | 0 | 1 |
| 17 | 17 | 17 | 2110228405636142087 | 3885343127079073091 | 0 | 0 | 1 |
| 18 | 19 | 18 | 2110228405636142087 | 7850293539893558402 | 0 | 0 | 1 |
| 19 | 21 | 19 | 2110228405636142087 | 6913171554546427077 | 0 | 0 | 1 |
| 20 | 22 | 20 | 2110228405636142087 | 8780118824285333313 | 0 | 0 | 1 |
| 21 | 24 | 21 | 2110228405636142087 | 199501861961548302 | 0 | 0 | 1 |
| 22 | 25 | 22 | 2110228405636142087 | 7695813383530131724 | 0 | 0 | 1 |
| 23 | 26 | 23 | 2110228405636142087 | 1066680470082322702 | 0 | 0 | 1 |
| 24 | 27 | 24 | 2110228405636142087 | 1353750679943106816 | 0 | 0 | 0 |

## All 27 frozen records

These are opcode/A/B/C tuples, not assembler text with ambiguous STORE syntax. Bytes are one opcode octet plus three signed little-endian i32 operands. PCs 18,20,23 are present in the binary and in lineage hashing but are never executed on this path. No execution observation for those three trap sites is fabricated.

| PC | Executed step | Name | Opcode byte | A | B | C | Exact 13-byte record (hex) |
|---:|---:|---|---|---:|---:|---:|---|
| 0 | 1 | LoadImm | 0x02 | 40 | -1 | 0 | `0228000000ffffffff00000000` |
| 1 | 2 | LoadImm | 0x02 | 41 | 0 | 0 | `02290000000000000000000000` |
| 2 | 3 | LoadImm | 0x02 | 42 | 1 | 0 | `022a0000000100000000000000` |
| 3 | 4 | TNot | 0x12 | 43 | 40 | 0 | `122b0000002800000000000000` |
| 4 | 5 | TAnd | 0x13 | 44 | 40 | 42 | `132c000000280000002a000000` |
| 5 | 6 | TOr | 0x14 | 45 | 41 | 42 | `142d000000290000002a000000` |
| 6 | 7 | TXor | 0x15 | 46 | 42 | 40 | `152e0000002a00000028000000` |
| 7 | 8 | LoadImm | 0x02 | 47 | 81 | 0 | `022f0000005100000000000000` |
| 8 | 9 | LoadImm | 0x02 | 48 | 2 | 0 | `02300000000200000000000000` |
| 9 | 10 | Mul | 0x07 | 49 | 47 | 48 | `07310000002f00000030000000` |
| 10 | 11 | Add | 0x05 | 50 | 49 | 44 | `0532000000310000002c000000` |
| 11 | 12 | Store | 0x04 | 81 | 50 | 0 | `04510000003200000000000000` |
| 12 | 13 | Load | 0x03 | 51 | 81 | 0 | `03330000005100000000000000` |
| 13 | 14 | LoadImm | 0x02 | 52 | -7 | 0 | `0234000000f9ffffff00000000` |
| 14 | 15 | Div | 0x08 | 53 | 52 | 48 | `08350000003400000030000000` |
| 15 | 16 | Mod | 0x09 | 54 | 52 | 48 | `09360000003400000030000000` |
| 16 | 17 | Cmp | 0x0f | 51 | 50 | 0 | `0f330000003200000000000000` |
| 17 | 18 | JumpIfZero | 0x0b | 19 | 41 | 0 | `0b130000002900000000000000` |
| 18 | not executed | Trap | 0x1c | 0 | 0 | 0 | `1c000000000000000000000000` |
| 19 | 19 | JumpIfNotZero | 0x19 | 21 | 42 | 0 | `19150000002a00000000000000` |
| 20 | not executed | Trap | 0x1c | 0 | 0 | 0 | `1c000000000000000000000000` |
| 21 | 20 | Cmp | 0x0f | 44 | 42 | 0 | `0f2c0000002a00000000000000` |
| 22 | 21 | JumpIfNegative | 0x3c | 24 | 0 | 0 | `3c180000000000000000000000` |
| 23 | not executed | Trap | 0x1c | 0 | 0 | 0 | `1c000000000000000000000000` |
| 24 | 22 | Store | 0x04 | 82 | 46 | 0 | `04520000002e00000000000000` |
| 25 | 23 | Store | 0x04 | 83 | 53 | 0 | `04530000003500000000000000` |
| 26 | 24 | Halt | 0x01 | 0 | 0 | 0 | `01000000000000000000000000` |

## Signed arithmetic and branch derivation

For -7/2, the absolute-value quotient is floor(7/2)=3, sign is negative, so q=-3. Remainder is -7-(-3×2)=-1; Python floor division/remainder conventions are deliberately not used directly for signed TISC division.

TXor(+1,-1) uses balanced difference: +1-(-1)=2 ≡ -1 (mod 3). It is neither binary XOR nor a commutative operation in general. The other trit results follow negation/min/max over {-1,0,+1}.

PC17 tests R41=0 and jumps to19. PC19 tests R42=1, independently of zero=true from the earlier comparison, and jumps to21. PC22 tests negative=true after comparing -1 with +1 and jumps to24. The positive path therefore visits 0..17,19,21,22,24,25,26: 24 instructions. Halt increments PC26→27 before global halt is set. The stack region is [27,283), so SP initializes to283 and remains unchanged because there are no stack instructions.

## Coverage limits

Only the listed canonical single-trit inputs are covered; this is not an exhaustive ternary truth table. JZ uses a zero register while the zero flag is also true, so this particular JZ cannot distinguish register-based versus flag-based implementations; the JNZ at PC19 does distinguish them. None of the Trap sentinels or division-by-zero, bounds, invalid operand, policy-denial or timeout paths execute in the positive run.
