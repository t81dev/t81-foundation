import pathlib,subprocess,json,hashlib,sys,os
root=pathlib.Path('/private/tmp/t81-cpa005'); out=root/'experiments/cpa005/evidence/isolation';out.mkdir(parents=True,exist_ok=True)
cc='/opt/homebrew/opt/llvm/bin/clang'; llvm='/opt/homebrew/opt/llvm/bin/'; commands=[]
def run(cmd,name,cwd=root,expect=0):
 p=subprocess.run(list(map(str,cmd)),cwd=cwd,capture_output=True)
 (out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr)
 commands.append(dict(command=list(map(str,cmd)),cwd=str(cwd),exit_code=p.returncode,expected=expect,stdout=name+'.stdout',stderr=name+'.stderr'))
 (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 if p.returncode!=expect:raise RuntimeError(name)
 return p.stdout
baseline=pathlib.Path('/private/tmp/t81-cpa005-main');baseline.mkdir(exist_ok=True)
archive=run(['git','archive','ea6d031a8117341fe03013cc9d5473de1b07727d'],'main-archive')
p=subprocess.run(['tar','-xf','-','-C',str(baseline)],input=archive,capture_output=True); assert p.returncode==0
# Remove bulky archive from retained stdout, preserving its hash and exact command.
(out/'main-archive.sha256').write_text(hashlib.sha256(archive).hexdigest()+'\n');(out/'main-archive.stdout').unlink()
for name,src in [('main',baseline),('integrated',root)]:
 build=pathlib.Path('/private/tmp/cpa005-build-off-'+name)
 run(['cmake','-S',src,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_C_COMPILER='+cc,'-DCMAKE_CXX_COMPILER='+cc+'++','-DT81_BUILD_TESTS=OFF','-DT81_BUILD_TUI=OFF','-DT81_BUILD_EXAMPLES=OFF','-DT81_BUILD_BENCHMARKS=OFF','-DT81_BUILD_FUZZ_TESTS=OFF','-DT81_ENABLE_TERNARYOS=ON','-DT81_ENABLE_DPE=OFF'],name+'-configure')
 run(['cmake','--build',build,'--target','t81_ternaryos_qemu_slice6_efi','-j','4'],name+'-build')
 run(['ninja','-C',build,'-t','commands','t81_ternaryos_qemu_slice6_efi'],name+'-link-commands')
 run([llvm+'llvm-objdump','-d',build/'ternaryos/qemu_slice6/BOOTAA64_bare.obj'],name+'-bare-disassembly')
 run([llvm+'llvm-readobj','--coff-imports',build/'ternaryos/qemu_slice6/BOOTAA64.EFI'],name+'-imports')
 require=lambda ok,msg: None if ok else sys.exit(msg)
 if name=='integrated':
  require('T81_BUILD_CPA004_EXPERIMENT:BOOL=OFF' in (build/'CMakeCache.txt').read_text(),'default not OFF')
  require(not (build/'ternaryos/qemu_slice6/BOOTAA64_cpa004.obj').exists(),'evaluator object leaked')
  require(not (build/'ternaryos/generated/cpa004_program.hpp').exists(),'input leaked')
  require(b'cpa004_evaluator.cpp' not in (out/(name+'-link-commands.stdout')).read_bytes(),'evaluator linked')
# Compare disassembly excluding the filename header; EFI text/data without timestamps.
a=(out/'main-bare-disassembly.stdout').read_text().splitlines()[3:];b=(out/'integrated-bare-disassembly.stdout').read_text().splitlines()[3:]
require(a==b,'default-off entry changed')
for name in ('main','integrated'):
 run([llvm+'llvm-objcopy','--dump-section','.text='+str(out/(name+'-efi.text')),'--dump-section','.rdata='+str(out/(name+'-efi.rdata')),'/private/tmp/cpa005-build-off-'+name+'/ternaryos/qemu_slice6/BOOTAA64.EFI'],name+'-sections')
require((out/'main-efi.text').read_bytes()==(out/'integrated-efi.text').read_bytes(),'EFI code changed')
require((out/'main-efi.rdata').read_bytes()==(out/'integrated-efi.rdata').read_bytes(),'EFI rodata changed')
(out/'result.json').write_text(json.dumps(dict(default_off=True,bare_disassembly_identical=True,efi_text_identical=True,efi_rodata_identical=True,no_evaluator_object=True,no_generated_program=True,no_evaluator_link_command=True),indent=2)+'\n')
print('PASS default-off isolation')
