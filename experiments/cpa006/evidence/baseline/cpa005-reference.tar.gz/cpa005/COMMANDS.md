# CPA-005 reproduction commands

Run from the isolated candidate `/private/tmp/t81-cpa005`. The original shared
checkout was dirty and was not used to supply compiled inputs. Host paths below
are the actual paths; relocate them consistently on another machine. Python
requires `jsonschema==4.23.0` (the existing external venv was reused only for
Python tooling, never for VM/EFI binaries).

```sh
# Fetch requested source snapshots into a separate shared clone.
git clone --shared --no-checkout /Users/t81dev/Code/t81-foundation /private/tmp/t81-cpa005
cd /private/tmp/t81-cpa005
git fetch https://github.com/t81dev/t81-foundation.git main refs/pull/709/head refs/pull/707/head
git checkout -b audit/cpa005-integration ea6d031a8117341fe03013cc9d5473de1b07727d
git merge --no-commit --no-ff b803bf916a1b1e44129f3a07abf96fa6103c51fc
git write-tree
# Result: 70734fd5bcfe06978cea13b4d2d595d4dda71a12; no merge commit.
git clone --shared --no-checkout /private/tmp/t81-cpa005 /private/tmp/t81-cpa005-frozen
git -C /private/tmp/t81-cpa005-frozen checkout --detach b803bf916a1b1e44129f3a07abf96fa6103c51fc

python3 experiments/cpa005/build_replay.py frozen /private/tmp/t81-cpa005-frozen
python3 experiments/cpa005/build_replay.py integrated /private/tmp/t81-cpa005
python3 experiments/cpa005/isolation.py
python3 experiments/cpa005/adversarial.py
/private/tmp/t81-h04-enforcement-venv/bin/python -B experiments/cpa005/verify.py
/private/tmp/t81-h04-enforcement-venv/bin/python -B experiments/cpa004/verify_evidence.py
git diff --check
```

`build_replay.py` was initially executed from an identical scratch copy at
`/private/tmp/cpa005-build.py`; the isolation and adversarial scripts likewise
ran from scratch copies. All exact subprocess argument arrays, working
directories, return codes, stdout and stderr are retained in each evidence
subdirectory. The build directories must be absent for a fresh replay. The
QEMU subdirectories must be absent because each run creates a new ESP and
variables image; archive old observations before repeating. Resource scope:
local builds with four jobs per build; three processes and three TCG guests per
source snapshot, each with a 30-second execution deadline, 512 MiB guest RAM,
and the unchanged 64-instruction evaluator bound. No benchmark was run.

The original CPA-003 packet was found at `/private/tmp/T81-CPA-003`. Its 57-file
manifest and eight frozen artifacts were checked with `verify_packet.py` and
`reproduce_oracle.py`. `evidence/cpa003-packet.tar.gz` retains the manifest-listed
files plus its verifier; extract outside the repo and run those scripts to
repeat the content/oracle checks. The archive omits unlisted debugger outputs.

The default-off control source is `git archive ea6d031a...` extracted to
`/private/tmp/t81-cpa005-main`. `isolation.py` builds its EFI and the candidate's
EFI without specifying the experimental option, inspects actual link commands,
and compares entry disassembly and the EFI `.text`/`.rdata` sections. Native
admission checks run directly; these are not claimed as CTest execution with
`T81_BUILD_TESTS=OFF`.

`evidence/integration.patch` is the exact CPA-004 patch applied to main;
`source-identity.json` pins the resulting Git tree and source blobs. It contains
no CPA-005 report files, so adding this report does not change the tested source
identity. Neither original PR was edited or merged. Retained historical
CPA-004 evidence, frozen fixtures and specifications were left unchanged.
