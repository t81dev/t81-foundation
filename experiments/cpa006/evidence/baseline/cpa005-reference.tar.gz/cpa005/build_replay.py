import sys, subprocess, json, pathlib, time, os
label=sys.argv[1]; src=pathlib.Path(sys.argv[2]); build=pathlib.Path('/private/tmp/cpa005-build-'+label)
out=pathlib.Path('/private/tmp/t81-cpa005/experiments/cpa005/evidence')/label; out.mkdir(parents=True,exist_ok=True)
commands=[]
def run(args,name,expected=0):
    start=time.time()
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
        p=subprocess.run(list(map(str,args)),cwd=src,stdout=stdout,stderr=stderr)
    commands.append(dict(command=list(map(str,args)),cwd=str(src),exit_code=p.returncode,expected=expected,seconds=time.time()-start,stdout=name+'.stdout',stderr=name+'.stderr'))
    (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(label,name,p.returncode,flush=True)
    if p.returncode!=expected:sys.exit(1)
cc='/opt/homebrew/opt/llvm/bin/clang'; cxx=cc+'++'; py='/private/tmp/t81-h04-enforcement-venv/bin/python'
run(['cmake','-S',src,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_C_COMPILER='+cc,'-DCMAKE_CXX_COMPILER='+cxx,'-DT81_BUILD_TESTS=OFF','-DT81_BUILD_TUI=OFF','-DT81_BUILD_EXAMPLES=OFF','-DT81_BUILD_BENCHMARKS=OFF','-DT81_BUILD_FUZZ_TESTS=OFF','-DT81_ENABLE_TERNARYOS=ON','-DT81_ENABLE_DPE=OFF','-DT81_BUILD_CPA004_EXPERIMENT=ON'],'configure')
run(['cmake','--build',build,'--target','t81_ternaryos_qemu_slice6_efi','t81_cpa004_admission_test','t81_vm','-j','4'],'build')
run([build/'t81_cpa004_admission_test'],'admission-release')
run([cxx,'-std=c++23','-O0','-g','-UNDEBUG','-DT81_DETERMINISTIC','-I'+str(src/'include'),src/'experiments/cpa004/hosted_observer.cpp','-L'+str(build),'-L/opt/homebrew/opt/llvm/lib/c++','-Wl,-rpath,/opt/homebrew/opt/llvm/lib/c++','-lt81_vm','-lt81_isa','-lt81_axion','-lt81_ffi','-lt81_experimental','-lt81_core','-o',build/'hosted_observer'],'observer-build')
run([py,'-B',src/'experiments/cpa004/evidence/acceptance/check.py','--hosted-observer',build/'hosted_observer','--output',out/'hosted'],'hosted-replay')
run([py,'-B',src/'experiments/cpa004/run_qemu.py','--build',build,'--output',out/'qemu','--qemu','/opt/homebrew/bin/qemu-system-aarch64','--firmware-code','/opt/homebrew/share/qemu/edk2-aarch64-code.fd','--firmware-vars','/opt/homebrew/share/qemu/edk2-arm-vars.fd'],'qemu-replay')
