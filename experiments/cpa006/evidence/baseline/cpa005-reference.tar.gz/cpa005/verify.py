#!/usr/bin/env python3
"""CPA-005 separately derived integer oracle and full observation comparison.

This verifier does not import the CPA-004 checker or execution logic. It reads
expected.json only after deriving the entire trace. Requires jsonschema 4.23.0.
"""
import argparse
import copy
import gzip
import hashlib
import json
import tarfile
from pathlib import Path
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parent
PROGRAM = 'b0649777cfa1c9e0fa1febb8bdfb1191c5cd3deea0d313791a4a32d5f207c80b'
CONTRACT = '851650fd5136fe6c8f67b924f7721f73beec54e6078b9e841261bc277170705d'
NAMES = {1:'Halt',2:'LoadImm',3:'Load',4:'Store',5:'Add',7:'Mul',8:'Div',9:'Mod',
         11:'JumpIfZero',15:'Cmp',18:'TNot',19:'TAnd',20:'TOr',21:'TXor',
         25:'JumpIfNotZero',28:'Trap',60:'JumpIfNegative'}

def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def signature(words):
    h = 1469598103934665603
    for word in words:
        for byte in (word % (2**64)).to_bytes(8, 'little'):
            h = ((h ^ byte) * 1099511628211) % (2**64)
    return (h % (2**63)) or 1


def derive(fixture):
    blob = (fixture/'program.raw13').read_bytes()
    require(len(blob) == 351 and sha(blob) == PROGRAM, 'program identity')
    require(sha((fixture/'contract.json').read_bytes()) == CONTRACT, 'contract identity')
    records = [(blob[n], *(int.from_bytes(blob[n+k:n+k+4], 'little', signed=True)
                           for k in (1,5,9))) for n in range(0,351,13)]
    listing = json.loads((fixture/'instruction-listing.json').read_text())
    require(len(records) == len(listing) == 27, '27 instructions')
    for pc, ((op,a,b,c), item) in enumerate(zip(records, listing)):
        require(item == dict(pc=pc, opcode=op, a=a, b=b, c=c, name=NAMES[op],
                             literal_kind=0, record_hex=blob[13*pc:13*(pc+1)].hex()),
                f'listing at {pc}')
    lineage = signature([27] + [v for row in records for v in (*row,0)])
    registers = [0]*81
    memory = [0]*(27+256+768+256+256)  # load_program segment sizes
    condition = dict(zero=False, negative=False, positive=False)
    pc = tick = 0
    halted = False
    trace = []
    def snapshot(before, insn):
        registers[0] = 0
        registers[75:81] = [tick,lineage,signature([tick,0,0,0,pc,0]),0,0,int(not halted)]
        return dict(schema='t81.cpa003.observation.v1',program_sha256=PROGRAM,
                    sequence=tick,pc_before=before,instruction=insn,
                    status='halted' if halted else 'running',trap=None,
                    state=dict(pc=pc,sp=27+256,halted=halted,flags=condition.copy(),
                               register_values=list(map(str,registers)),register_tags=[0]*81,
                               memory=dict(word_count=1563,default_value='0',default_tag=0,
                                  overrides=[dict(address=i,value=str(x),tag=0)
                                             for i,x in enumerate(memory) if x])))
    trace.append(snapshot(None,None))
    while not halted:
        require(tick < 64 and 0 <= pc < 27, 'execution bound')
        before = pc
        op,a,b,c = records[pc]
        pc += 1
        tick += 1
        value = None
        if op == 1: halted = True
        elif op == 2: value = b
        elif op == 3: value = memory[b]
        elif op == 4: memory[a] = registers[b]
        elif op == 5: value = registers[b] + registers[c]
        elif op == 7: value = registers[b] * registers[c]
        elif op in (8,9):
            lhs,rhs = registers[b],registers[c]
            quotient = (abs(lhs)//abs(rhs)) * (-1 if (lhs<0) != (rhs<0) else 1)
            value = quotient if op == 8 else lhs - quotient*rhs
        elif op == 18: value = -registers[b]
        elif op == 19: value = min(registers[b],registers[c])
        elif op == 20: value = max(registers[b],registers[c])
        elif op == 21: value = ((registers[b]-registers[c]+1)%3)-1
        elif op == 15:
            condition = dict(zero=registers[a]==registers[b],negative=registers[a]<registers[b],
                             positive=registers[a]>registers[b])
        elif op in (11,25,60):
            if {11:registers[b]==0,25:registers[b]!=0,60:condition['negative']}[op]: pc=a
        else: raise RuntimeError('sentinel/unsupported instruction executed')
        if value is not None:
            registers[a] = value
            condition = dict(zero=value==0,negative=value<0,positive=value>0)
        trace.append(snapshot(before,dict(opcode=op,name=NAMES[op],a=a,b=b,c=c)))
    require(tick == 24 and pc == 27 and len(trace) == 25, '24 steps and Halt')
    require(not {18,20,23}.intersection(x['pc_before'] for x in trace), 'trap sentinels')
    require(trace == json.loads((fixture/'expected.json').read_text()), 'independent oracle vs frozen')
    return records,trace


def normalize(raw):
    state = raw['state']
    require(len(state['register_values']) == len(state['register_tags']) == 81, 'register shape')
    require(len(state['memory_values']) == len(state['memory_tags']) == 1563, 'memory shape')
    result = {k:copy.deepcopy(raw[k]) for k in ('sequence','pc_before','instruction','status','trap')}
    result.update(schema='t81.cpa003.observation.v1',program_sha256=PROGRAM)
    result['state'] = {k:copy.deepcopy(state[k]) for k in ('pc','sp','halted','flags','register_tags')}
    result['state'].update(register_values=list(map(str,state['register_values'])),
         memory=dict(word_count=1563,default_value='0',default_tag=0,
                     overrides=[dict(address=i,value=str(v),tag=t) for i,(v,t) in
                                enumerate(zip(state['memory_values'],state['memory_tags'])) if v or t]))
    return result


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--evidence',type=Path,default=ROOT/'evidence')
    args=parser.parse_args()
    fixture=ROOT.parent/'cpa004'
    manifest=json.loads((fixture/'evidence/manifest.json').read_text())
    retained=0
    for group in ('source','evidence'):
        for name,pin in manifest[group].items():
            path=ROOT.parents[1]/name if group=='source' else fixture/name
            data=path.read_bytes()
            require(sha(data)==pin['sha256'], 'retained identity '+name)
            if 'bytes' in pin: require(len(data)==pin['bytes'], 'retained length '+name)
            if 'uncompressed_sha256' in pin:
                require(sha(gzip.decompress(data))==pin['uncompressed_sha256'], 'retained gzip '+name)
            retained+=1
    with tarfile.open(args.evidence/'cpa003-packet.tar.gz') as archive:
        def packet(name):
            return archive.extractfile('T81-CPA-003/'+name).read()
        old_manifest=json.loads(packet('packet-manifest.json'))
        frozen_manifest=json.loads(packet('freeze-manifest.json'))
        for name,pin in old_manifest['files'].items():
            require(sha(packet(name))==pin['sha256'] and len(packet(name))==pin['bytes'],
                    'CPA003 packet '+name)
        for name,pin in frozen_manifest['files'].items():
            require(sha(packet(name))==pin['sha256'], 'CPA003 frozen '+name)
    records,trace=derive(fixture)
    validator=Draft202012Validator(json.loads((fixture/'observation.schema.json').read_text()))
    for frame in trace: validator.validate(frame)
    result=[]
    for profile in ('frozen','integrated'):
        for run in range(1,4):
            directory=args.evidence/profile
            raw=[json.loads(x) for x in (directory/f'hosted/hosted-{run}.jsonl').read_bytes().splitlines()]
            require(raw[0]['decoded_records'] == [list(row)+[0] for row in records], 'hosted decoding')
            require(raw[0]['input_bytes']==351 and raw[0]['existing_encoder_roundtrip'], 'hosted input')
            hosted=list(map(normalize,raw))
            guest_bytes=gzip.decompress((directory/f'qemu/boot-{run}/serial.log.gz').read_bytes())
            guest_result=json.loads((directory/f'qemu/boot-{run}/result.json').read_text())
            require(not guest_result['timeout'] and sha(guest_bytes)==guest_result['raw_sha256'],
                    'guest raw hash/outcome')
            lines=guest_bytes.splitlines()
            require([x for x in lines if x.startswith(b'CPA004_EXIT=')]==[b'CPA004_EXIT=0'],
                    'actual guest halt classification')
            require([x for x in lines if x.startswith(b'CPA004_ARTIFACT_HEX=')]==
                    [b'CPA004_ARTIFACT_HEX='+(fixture/'program.raw13').read_bytes().hex().encode()],
                    'actual guest input')
            markers=[b'[axion] bare-metal EL1 kernel entry',b'[axion] ExitBootServices complete;',
                     b'[cpa004] live post-ExitBootServices evaluator',b'CPA004_ARTIFACT_HEX=']
            offsets=[guest_bytes.find(x) for x in markers]
            require(all(x>=0 for x in offsets) and offsets==sorted(offsets), 'guest execution order')
            guest=[json.loads(x.split(b'=',1)[1]) for x in guest_bytes.splitlines()
                   if x.startswith(b'CPA004_OBSERVATION=')]
            for kind,observed in [('hosted',hosted),('guest',guest)]:
                require(observed==trace,f'{profile}/{run}/{kind}: all admitted fields')
                for frame in observed: validator.validate(frame)
                (directory/f'{kind}-{run}.normalized.json').write_text(json.dumps(observed,indent=2)+'\n')
                result.append(dict(profile=profile,run=run,kind=kind,boundaries=25,equal=True))
    changed=copy.deepcopy(trace)
    changed[-1]['state']['register_tags'][80]=1
    require(changed != trace,'deliberate comparison mutation must differ')
    (args.evidence/'derived-oracle.json').write_text(json.dumps(trace,indent=2)+'\n')
    report=dict(disposition='PASS',program_sha256=PROGRAM,contract_sha256=CONTRACT,
                independently_derived_boundaries=25,schema_records=325,comparisons=result,
                retained_manifest_entries=retained,cpa003_packet_files=len(old_manifest['files']),
                cpa003_frozen_files=len(frozen_manifest['files']),
                full_fields='All 81 payloads/tags, all 1563 logical memory payloads/tags, flags, PC, SP, halt, instruction, status, trap, sequence, system registers',
                comparison_mutation_detected=True,
                independence='Fresh execution and new mathematical derivation by Codex; no independent-person scientific replication claim.')
    (args.evidence/'comparisons.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__ == '__main__': main()
