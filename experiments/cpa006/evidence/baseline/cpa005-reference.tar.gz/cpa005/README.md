# T81-CPA-005 acceptance report — November 5, 2026

**PASS — INTEGRATED.** Yes: on the current-main snapshot fetched for this run,
T81 executes the same canonical instruction program with equivalent admitted
computational state transitions under hosted T81VM and freestanding AArch64
Axion OS after successful ExitBootServices. This is a bounded H07 engineering
prerequisite result for one frozen raw13 program, not normative full-ISA
conformance or a comparative architecture advantage.

No implementation corrections were needed. No original branch was rebased,
modified or merged, no merge commit was created, and no production activation
or PR publication was performed. The integration is an isolated, uncommitted
candidate; acceptance here is a proposed evidence disposition, not a human
merge/governance decision. Existing unrelated shared-checkout edits were excluded
from every compiled input.

## Exact identities

| Input | Identity |
| --- | --- |
| Current main as fetched | `ea6d031a8117341fe03013cc9d5473de1b07727d` |
| PR #709 base at inspection | `ea6d031a8117341fe03013cc9d5473de1b07727d` |
| PR #709 head (open draft) | `b803bf916a1b1e44129f3a07abf96fa6103c51fc` |
| CPA-004 tested baseline | `803075e9f7e36ed4b5318a8d2ddaacf62ae0a7e4` |
| CPA-004 implementation | `30664fe923b1f491e0722194cfd13eff74f16ccf` |
| Integrated source Git tree, before CPA-005 reporting files | `70734fd5bcfe06978cea13b4d2d595d4dda71a12` |
| Program SHA-256 (351 bytes; 27 records) | `b0649777cfa1c9e0fa1febb8bdfb1191c5cd3deea0d313791a4a32d5f207c80b` |
| Contract SHA-256 | `851650fd5136fe6c8f67b924f7721f73beec54e6078b9e841261bc277170705d` |
| Frozen expected-state SHA-256 | `03708ee4f5b5d63313b5dd3265e1c32db2deb20b6f794f93bba5dc27ed4e5324` |
| Frozen schema SHA-256 | `cc8adc5796e63b38608ba6691c9690724dbe7add6dafa096d66fb5c7b15a7569` |

[Source identities](evidence/source-identity.json) pin implementation source
hashes and Git blobs. [Integration patch](evidence/integration.patch) reproduces
the candidate from pinned main. The patch contains only PR709's CPA-004 changes;
there are no corrective production edits. All historical evidence and frozen
artifacts remain byte-identical.

The seven [intervening commits](evidence/intervening-commits.txt) cover CanonFS
portable storage/CLI/snapshot/test integration and status timestamps. TISC,
T81VM, boot sources and experimental paths have no intervening source changes.
Root CMake adds one CanonFS Python contract test; it does not change the tested
runtime configuration. The candidate applied without textual conflicts. Fresh
state comparisons, rather than the conflict-free merge operation, establish
semantic compatibility in this scope.

PR #707 remains open and unmerged at
`55223cbd3ee29b5391e151197fe6eee1b8889452`; it is not an ancestor of main or
PR709 and was not imported. Its opcode-matrix repair is a separate test-quality
review gate for broader conformance. The exact CPA-004 execution has no build
or runtime dependency on that repair. No claim that the entire opcode matrix
is already trustworthy on main is made.

## Reproduction evidence

| Check | Fresh observed result |
| --- | --- |
| Frozen PR snapshot | Fresh configure/build, three hosted processes and three QEMU guests: PASS |
| Integrated main + CPA-004 | Fresh configure/build, three hosted processes and three QEMU guests: PASS |
| Instruction decoding | All 27 opcode/A/B/C tuples, literal kind, record hex and names match independent byte decoding and hosted encoder roundtrip |
| Input identity | Exactly 351 bytes; each guest emits the actual identical buffer |
| Execution | Exactly 24 instructions; 25 boundaries including initial state; final PC=27, SP=283, halted=true |
| Trap sentinels | PCs 18, 20 and 23 never executed in any successful trace |
| Common state | All 81 register payloads/tags, 1563 logical memory payloads/tags, flags, PC/SP, halt, system registers, instruction/status/trap and sequence match exactly |
| Fresh schema validation | 325 records: 25 newly derived + 300 hosted/guest records |
| Retained CPA-004 evidence | 71 manifest entries validated; retained 3 hosted + 3 guest traces replayed; frozen identities and 100 expected/guest schema records passed |
| CPA-003 packet | 57 manifest files and eight pre-host frozen artifacts checked; regeneration reproduces all eight frozen hashes |
| Always-active checks | Explicit Debug and Release admission/limit runs pass; ASan/UBSan run passes |
| Deliberate failure | Wrong 25-step expectation exits 1 under `-O3 -DNDEBUG`; stderr records the failed check |
| Default-off isolation | Option omitted gives OFF; no evaluator object/header/link command; bare entry disassembly and complete EFI `.text` and `.rdata` identical to current-main control |

The new [verifier](verify.py) derives all states before reading frozen expected
states; it uses Python unbounded integers, explicit truncation toward zero, and
a modular balanced-difference formula. Initial layout is checked against
`load_program`: 27 code slots + 256 stack slots gives SP 283; total logical
memory is 27+256+768+256+256=1563 zero-initialized words. R0 is zero, tags are
Int, flags initially false, and R75–R80 follow the inspected live system
register formulas. No expected state was rewritten. Final memory has 81=161,
82=-1, 83=-3; all other logical memory words retain zero values and tags.

[Full comparisons](evidence/comparisons.json) enumerate each fresh run.
[Derived oracle](evidence/derived-oracle.json) and all twelve
`evidence/{frozen,integrated}/{hosted,guest}-N.normalized.json` files retain the
full normalized state records. Hosted diagnostics remain in raw observations;
they are outside the frozen common-state projection.

[Exact commands](COMMANDS.md), per-profile `commands.json`, full build stdout
and stderr, and `build-commands.stdout` retain configurations and compiler/link
arguments. Each guest's `result.json` records actual QEMU arguments, ordered
post-ExitBootServices markers, no timeout, exact input, 25 observations and
`CPA004_EXIT=0`. Process termination is not interpreted as computational Halt.

[Environment](evidence/environment.json): macOS ARM64, Clang 22.1.1, CMake 4.3.0,
Ninja 1.13.2, QEMU 10.2.2 TCG cortex-a57, EDK2 firmware, jsonschema 4.23.0.
Libraries and EFI objects were rebuilt from fresh, separate build directories
for each snapshot. The existing Python venv supplied validation tools only.
[Build hashes](evidence/build-artifacts.json) retain exact linked library,
observer, generated header, object and EFI identities. Firmware code SHA-256:
`47765fe344818cbc464b1c14ae658fb4b854f5c2ceffa982411731eb4865594d`;
fresh vars template: `b3b855c5a80310168051164986855692d1bdb06e67619856177965cd87c6774f`.
Generated firmware vars, ESP staging and native test binaries are not packaged;
raw observations, commands and identities are retained.

Fresh frozen EFI SHA-256: `7ede1ab32d3965bcc3f2d29911bd2149f3b727238c850f3f5552b23ba2f24199`.
Fresh integrated EFI SHA-256: `7ab343f3ae3e1ead49666e977c7c6aa7f972ecf5fcbfbb87879977ddd0d42d12`.
EFI byte identity with historical builds is not an acceptance requirement;
PE build metadata may vary. Actual input bytes and all computational states
are independently compared, and default-off code/data section equality is
checked separately.

Raw evidence SHA-256 values (guest hashes are for uncompressed serial bytes):

| Snapshot/run | Hosted raw SHA-256 | QEMU raw SHA-256 |
| --- | --- | --- |
| frozen 1 | `e26c41cd709c87213904e5bfe11d3b6f20fc7124f2350e6714d9806f95cec30a` | `966c169d7f8ff01de68dbf1cc9109fb6662a69264cff970cd8cf1f9c4f5839bc` |
| frozen 2 | `e26c41cd709c87213904e5bfe11d3b6f20fc7124f2350e6714d9806f95cec30a` | `966c169d7f8ff01de68dbf1cc9109fb6662a69264cff970cd8cf1f9c4f5839bc` |
| frozen 3 | `e26c41cd709c87213904e5bfe11d3b6f20fc7124f2350e6714d9806f95cec30a` | `966c169d7f8ff01de68dbf1cc9109fb6662a69264cff970cd8cf1f9c4f5839bc` |
| integrated 1 | `e26c41cd709c87213904e5bfe11d3b6f20fc7124f2350e6714d9806f95cec30a` | `fb56d0820785a8ec9dadea40560b6c19775baeb06c86d003b8b59204b433781c` |
| integrated 2 | `e26c41cd709c87213904e5bfe11d3b6f20fc7124f2350e6714d9806f95cec30a` | `fb56d0820785a8ec9dadea40560b6c19775baeb06c86d003b8b59204b433781c` |
| integrated 3 | `e26c41cd709c87213904e5bfe11d3b6f20fc7124f2350e6714d9806f95cec30a` | `fb56d0820785a8ec9dadea40560b6c19775baeb06c86d003b8b59204b433781c` |

Raw hosted streams are `evidence/<snapshot>/hosted/hosted-N.jsonl`; raw guest
streams are losslessly compressed at `evidence/<snapshot>/qemu/boot-N/serial.log.gz`.
The packet-wide [manifest](manifest.json) pins the packaged files.

## Review, failures and limits

[Adversarial review](REVIEW.md) covers all ten requested review questions.
[Schema-shaped review](review.json) and [reproducibility record](reproducibility.json)
passed Commons contribution validation. They remain `status: proposed`;
schema validity does not establish independent judgment or authorize a merge.

This session actually performed new builds and executions and a new mathematical
derivation. The earlier checker, expected states and implementation were visible
before that derivation. Separate execution logic does not establish
independent-person review; no independent-party scientific replication is claimed.

No new execution timeout or semantic disagreement occurred. The initial
unprivileged remote lookup failed DNS; the explicit isolated fetch succeeded.
Historical CPA-004's three firmware-staging timeouts remain INCONCLUSIVE and
unchanged; they were not recategorized. The deliberate NDEBUG failure is an
expected negative control, with its failing output retained. No remote CI or
full repository test-suite result is claimed; admission checks were run directly,
not via CTest with tests disabled.

Unresolved specification discrepancies are preserved: direct versus
register-indirect memory/branch addressing, register versus FLAGS tests for
JZ/JNZ, TXor sum/difference wording, the 174/209/244 inventories, and conflicting
later assignments. All 17 experiment assignments agree. Matching execution
accepts only the frozen hosted profile, not a normative ISA reconciliation.

Only macOS ARM64 hosting and emulated AArch64 execution were exercised. Linux
and Windows hosts, physical ARM64/native ternary hardware, R81–R242, general
programs, unexecuted trap transitions, dynamic policy equivalence and total
EFI memory use remain unverified. The POSIX supervisor requires an appropriate
environment on Windows. The evaluator uses static single-invocation state; this
is not a reentrancy/concurrency claim. There is no performance, energy,
ternary-superiority, production-readiness or complete-OS conclusion.

The recommended next experiment is a separately authorized, preregistered
second frozen program within the existing opcode subset, exercising untaken
conditional branches and memory boundary cases with an oracle prepared by a
reviewer who has not seen implementation outputs. First resolve or explicitly
approve the experimental memory/branch/TXor profile; retain CPA-003/004/005
unchanged. No new opcode or subsystem is needed. This is a recommendation only;
no second artifact or experiment was executed here.
