import json, os, pathlib, subprocess, sys
root=pathlib.Path('/private/tmp/t81-base01-execution')
label=sys.argv[1]; argv=sys.argv[2:]
rec={'argv':argv,'cwd':os.getcwd(),'env_overrides':{k:v for k,v in os.environ.items() if k.startswith('BASE01_')}}
(root/'logs'/f'{label}.command.json').write_text(json.dumps(rec,indent=2)+'\n')
with (root/'logs'/f'{label}.log').open('w') as out:
 p=subprocess.run(argv,stdout=out,stderr=subprocess.STDOUT)
(root/'logs'/f'{label}.exit').write_text(str(p.returncode)+'\n')
print(f'{label}: exit {p.returncode}')
print('\n'.join((root/'logs'/f'{label}.log').read_text(errors='replace').splitlines()[-35:]))
sys.exit(p.returncode)
