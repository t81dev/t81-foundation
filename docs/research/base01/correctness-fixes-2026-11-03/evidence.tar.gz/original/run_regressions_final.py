import json,os,pathlib,subprocess,sys
root=pathlib.Path('/private/tmp/t81-base01-execution')
a=json.loads((root/'logs/latest-regression-build.command.json').read_text())['argv']; targets=a[a.index('--target')+1:]+['t81_determinism_evidence_test']
results=[]
env=dict(os.environ); env.pop('T81_CANONFS_ROOT',None); env['T81_CANONFS_READ_VERIFY']='1'
for target in targets:
 label='latest-final-'+target
 cwd=root/'test-runs-final'/target; cwd.mkdir(parents=True,exist_ok=False)
 subprocess.run([sys.executable,'-B',str(root/'run.py'),label,str(root/'latest-build'/target)],env=env,cwd=cwd)
 code=int((root/'logs'/(label+'.exit')).read_text())
 results.append(dict(target=target,exit_code=code,status='passed' if code==0 else 'failed'))
(root/'latest-regressions-final.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(dict(run=len(results),passed=sum(x['exit_code']==0 for x in results),failed=sum(x['exit_code']!=0 for x in results))))
sys.exit(any(x['exit_code']!=0 for x in results))
