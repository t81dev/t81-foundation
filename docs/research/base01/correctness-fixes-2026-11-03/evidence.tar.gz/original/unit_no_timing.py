import json, pathlib, sys, unittest
from types import SimpleNamespace
from unittest.mock import patch
class Log:
 def write(self,s): sys.stdout.write(s)
 def flush(self): sys.stdout.flush()
 def writeln(self,s=''): print(s)
suite=unittest.defaultTestLoader.discover(sys.argv[1],pattern='test_*.py')
result=unittest.TextTestResult(Log(),True,2)
result.startTestRun()
with patch.object(unittest.case,'time',SimpleNamespace(perf_counter=lambda:0),create=True): suite.run(result)
result.stopTestRun(); result.printErrors()
summary=dict(run=result.testsRun,passed=result.testsRun-len(result.failures)-len(result.errors)-len(result.skipped),failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped))
print(json.dumps(summary))
pathlib.Path(sys.argv[2]).write_text(json.dumps(summary,indent=2)+'\n')
sys.exit(0 if result.wasSuccessful() and result.testsRun and not result.skipped else 1)
