# Exact recorded commands

Each entry preserves its working directory, argv, BASE01 overrides, combined output and raw return code. Commands are rendered from logs/*.command.json. Build logs include full compiler/link commands. Commands are listed by label, not claimed execution chronology.

## assertion-after-test_deterministic_float_boundaries.cpp-build — return code 0

Working directory: `/private/tmp/t81-base01-execution`

```sh
/usr/bin/c++ -std=c++23 -O3 -DNDEBUG -DT81_DETERMINISTIC -I /private/tmp/t81-base01-correctness-latest/include /private/tmp/t81-base01-execution/mutated-after-test_deterministic_float_boundaries.cpp /private/tmp/t81-base01-execution/latest-build/libt81_core.a -o /private/tmp/t81-base01-execution/assertion-after-test_deterministic_float_boundaries.cpp
```

Output: [logs/assertion-after-test_deterministic_float_boundaries.cpp-build.log](logs/assertion-after-test_deterministic_float_boundaries.cpp-build.log)

## assertion-after-test_deterministic_float_boundaries.cpp — return code -6

Working directory: `/private/tmp/t81-base01-execution`

```sh
/private/tmp/t81-base01-execution/assertion-after-test_deterministic_float_boundaries.cpp
```

Output: [logs/assertion-after-test_deterministic_float_boundaries.cpp.log](logs/assertion-after-test_deterministic_float_boundaries.cpp.log)

## assertion-after-test_map_determinism.cpp-build — return code 0

Working directory: `/private/tmp/t81-base01-execution`

```sh
/usr/bin/c++ -std=c++23 -O3 -DNDEBUG -DT81_DETERMINISTIC -I /private/tmp/t81-base01-correctness-latest/include /private/tmp/t81-base01-execution/mutated-after-test_map_determinism.cpp /private/tmp/t81-base01-execution/latest-build/libt81_core.a -o /private/tmp/t81-base01-execution/assertion-after-test_map_determinism.cpp
```

Output: [logs/assertion-after-test_map_determinism.cpp-build.log](logs/assertion-after-test_map_determinism.cpp-build.log)

## assertion-after-test_map_determinism.cpp — return code -6

Working directory: `/private/tmp/t81-base01-execution`

```sh
/private/tmp/t81-base01-execution/assertion-after-test_map_determinism.cpp
```

Output: [logs/assertion-after-test_map_determinism.cpp.log](logs/assertion-after-test_map_determinism.cpp.log)

## assertion-before-test_deterministic_float_boundaries.cpp-build — return code 0

Working directory: `/private/tmp/t81-base01-execution`

```sh
/usr/bin/c++ -std=c++23 -O3 -DNDEBUG -DT81_DETERMINISTIC -I /private/tmp/t81-base01-correctness-latest/include /private/tmp/t81-base01-execution/mutated-before-test_deterministic_float_boundaries.cpp /private/tmp/t81-base01-execution/latest-build/libt81_core.a -o /private/tmp/t81-base01-execution/assertion-before-test_deterministic_float_boundaries.cpp
```

Output: [logs/assertion-before-test_deterministic_float_boundaries.cpp-build.log](logs/assertion-before-test_deterministic_float_boundaries.cpp-build.log)

## assertion-before-test_deterministic_float_boundaries.cpp — return code 0

Working directory: `/private/tmp/t81-base01-execution`

```sh
/private/tmp/t81-base01-execution/assertion-before-test_deterministic_float_boundaries.cpp
```

Output: [logs/assertion-before-test_deterministic_float_boundaries.cpp.log](logs/assertion-before-test_deterministic_float_boundaries.cpp.log)

## assertion-before-test_map_determinism.cpp-build — return code 0

Working directory: `/private/tmp/t81-base01-execution`

```sh
/usr/bin/c++ -std=c++23 -O3 -DNDEBUG -DT81_DETERMINISTIC -I /private/tmp/t81-base01-correctness-latest/include /private/tmp/t81-base01-execution/mutated-before-test_map_determinism.cpp /private/tmp/t81-base01-execution/latest-build/libt81_core.a -o /private/tmp/t81-base01-execution/assertion-before-test_map_determinism.cpp
```

Output: [logs/assertion-before-test_map_determinism.cpp-build.log](logs/assertion-before-test_map_determinism.cpp-build.log)

## assertion-before-test_map_determinism.cpp — return code 0

Working directory: `/private/tmp/t81-base01-execution`

```sh
/private/tmp/t81-base01-execution/assertion-before-test_map_determinism.cpp
```

Output: [logs/assertion-before-test_map_determinism.cpp.log](logs/assertion-before-test_map_determinism.cpp.log)

## corrected-regression-build — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
cmake --build /private/tmp/t81-base01-execution/latest-build --verbose --parallel 2 --target t81_sha3_test test_deterministic_float_boundaries test_map_determinism t81_determinism_evidence_test
```

Output: [logs/corrected-regression-build.log](logs/corrected-regression-build.log)

## environment — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
python3 -B -c 'import platform,subprocess,sys,json; print(json.dumps({"platform":platform.platform(),"machine":platform.machine(),"python":sys.version},indent=2)); [subprocess.run(a,check=True) for a in [["/usr/bin/c++","--version"],["/usr/bin/cc","--version"],["cmake","--version"],["ninja","--version"],["git","rev-parse","HEAD"],["git","-C","/private/tmp/t81-base01-execution/asio","rev-parse","HEAD","asio-1-30-2^{commit}"]]]'
```

Output: [logs/environment.log](logs/environment.log)

## foundation-build — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
cmake --build /private/tmp/t81-base01-execution/foundation-build --verbose --parallel 2
```

Output: [logs/foundation-build.log](logs/foundation-build.log)

## foundation-configure — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
cmake -S /private/tmp/t81-base01-correctness-latest/experiments/base01_b1_foundation -B /private/tmp/t81-base01-execution/foundation-build -G Ninja -DCMAKE_CXX_COMPILER=/usr/bin/c++ -DCMAKE_BUILD_TYPE=Release -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DAUDITED_SOURCE=/private/tmp/t81-base01-execution/source -DAUDITED_BUILD=/private/tmp/t81-base01-execution/source-build
```

Output: [logs/foundation-configure.log](logs/foundation-configure.log)

## foundation-tests — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
BASE01_FOUNDATION_NATIVE=/private/tmp/t81-base01-execution/foundation-build/foundation_check BASE01_FOUNDATION_RAW=/private/tmp/t81-base01-execution/foundation-evidence/native.json.gz python3 -B /private/tmp/t81-base01-execution/unit_no_timing.py /private/tmp/t81-base01-correctness-latest/experiments/base01_b1_foundation /private/tmp/t81-base01-execution/foundation-tests.json
```

Output: [logs/foundation-tests.log](logs/foundation-tests.log)

## foundation-validation — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
python3 -B /private/tmp/t81-base01-correctness-latest/experiments/base01_b1_foundation/harness.py --validate-only --source /private/tmp/t81-base01-execution/source --source-build /private/tmp/t81-base01-execution/source-build --build /private/tmp/t81-base01-execution/foundation-build --output /private/tmp/t81-base01-execution/foundation-evidence
```

Output: [logs/foundation-validation.log](logs/foundation-validation.log)

## lane-a-build — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
cmake --build /private/tmp/t81-base01-execution/lane-a-build --verbose --parallel 2
```

Output: [logs/lane-a-build.log](logs/lane-a-build.log)

## lane-a-configure — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
cmake -S /private/tmp/t81-base01-correctness-latest/experiments/base01_lane_a -B /private/tmp/t81-base01-execution/lane-a-build -G Ninja -DCMAKE_CXX_COMPILER=/usr/bin/c++ -DCMAKE_BUILD_TYPE=Release -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DBASE01_SOURCE=/private/tmp/t81-base01-execution/source -DBASE01_BUILD=/private/tmp/t81-base01-execution/source-build
```

Output: [logs/lane-a-configure.log](logs/lane-a-configure.log)

## lane-a-tests — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
BASE01_ACCEPTANCE_NATIVE=/private/tmp/t81-base01-execution/lane-a-build/base01_lane_a python3 -B /private/tmp/t81-base01-execution/unit_no_timing.py /private/tmp/t81-base01-correctness-latest/experiments/base01_lane_a /private/tmp/t81-base01-execution/lane-a-tests.json
```

Output: [logs/lane-a-tests.log](logs/lane-a-tests.log)

## lane-a-validation — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
python3 -B /private/tmp/t81-base01-correctness-latest/experiments/base01_lane_a/lane_a.py --validate-only --source /private/tmp/t81-base01-execution/source --source-build /private/tmp/t81-base01-execution/source-build --native-build /private/tmp/t81-base01-execution/lane-a-build --output /private/tmp/t81-base01-execution/lane-a-evidence
```

Output: [logs/lane-a-validation.log](logs/lane-a-validation.log)

## latest-canonfs_identity_contract_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/canonfs_identity_contract_test`

```sh
/private/tmp/t81-base01-execution/latest-build/canonfs_identity_contract_test
```

Output: [logs/latest-canonfs_identity_contract_test.log](logs/latest-canonfs_identity_contract_test.log)

## latest-canonfs_integrity_matrix_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/canonfs_integrity_matrix_test`

```sh
/private/tmp/t81-base01-execution/latest-build/canonfs_integrity_matrix_test
```

Output: [logs/latest-canonfs_integrity_matrix_test.log](logs/latest-canonfs_integrity_matrix_test.log)

## latest-canonfs_read_verify_env_contract_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/canonfs_read_verify_env_contract_test`

```sh
/private/tmp/t81-base01-execution/latest-build/canonfs_read_verify_env_contract_test
```

Output: [logs/latest-canonfs_read_verify_env_contract_test.log](logs/latest-canonfs_read_verify_env_contract_test.log)

## latest-canonfs_read_verify_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/canonfs_read_verify_test`

```sh
/private/tmp/t81-base01-execution/latest-build/canonfs_read_verify_test
```

Output: [logs/latest-canonfs_read_verify_test.log](logs/latest-canonfs_read_verify_test.log)

## latest-configure — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
cmake -S /private/tmp/t81-base01-correctness-latest -B /private/tmp/t81-base01-execution/latest-build -G Ninja -DCMAKE_CXX_COMPILER=/usr/bin/c++ -DCMAKE_BUILD_TYPE=Release -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DT81_BUILD_BENCHMARKS=OFF -DT81_BUILD_TUI=OFF -DT81_BUILD_EXAMPLES=OFF -DT81_BUILD_FUZZ_TESTS=OFF -DT81_ENABLE_TERNARYOS=OFF -DT81_ENABLE_DPE=OFF -DFETCHCONTENT_SOURCE_DIR_ASIO=/private/tmp/t81-base01-execution/asio
```

Output: [logs/latest-configure.log](logs/latest-configure.log)

## latest-final-canonfs_identity_contract_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/canonfs_identity_contract_test`

```sh
/private/tmp/t81-base01-execution/latest-build/canonfs_identity_contract_test
```

Output: [logs/latest-final-canonfs_identity_contract_test.log](logs/latest-final-canonfs_identity_contract_test.log)

## latest-final-canonfs_integrity_matrix_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/canonfs_integrity_matrix_test`

```sh
/private/tmp/t81-base01-execution/latest-build/canonfs_integrity_matrix_test
```

Output: [logs/latest-final-canonfs_integrity_matrix_test.log](logs/latest-final-canonfs_integrity_matrix_test.log)

## latest-final-canonfs_read_verify_env_contract_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/canonfs_read_verify_env_contract_test`

```sh
/private/tmp/t81-base01-execution/latest-build/canonfs_read_verify_env_contract_test
```

Output: [logs/latest-final-canonfs_read_verify_env_contract_test.log](logs/latest-final-canonfs_read_verify_env_contract_test.log)

## latest-final-canonfs_read_verify_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/canonfs_read_verify_test`

```sh
/private/tmp/t81-base01-execution/latest-build/canonfs_read_verify_test
```

Output: [logs/latest-final-canonfs_read_verify_test.log](logs/latest-final-canonfs_read_verify_test.log)

## latest-final-t81_axion_log_determinism_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/t81_axion_log_determinism_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_axion_log_determinism_test
```

Output: [logs/latest-final-t81_axion_log_determinism_test.log](logs/latest-final-t81_axion_log_determinism_test.log)

## latest-final-t81_canonfs_driver_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/t81_canonfs_driver_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_canonfs_driver_test
```

Output: [logs/latest-final-t81_canonfs_driver_test.log](logs/latest-final-t81_canonfs_driver_test.log)

## latest-final-t81_determinism_codec_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/t81_determinism_codec_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_determinism_codec_test
```

Output: [logs/latest-final-t81_determinism_codec_test.log](logs/latest-final-t81_determinism_codec_test.log)

## latest-final-t81_determinism_containers_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/t81_determinism_containers_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_determinism_containers_test
```

Output: [logs/latest-final-t81_determinism_containers_test.log](logs/latest-final-t81_determinism_containers_test.log)

## latest-final-t81_determinism_evidence_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/t81_determinism_evidence_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_determinism_evidence_test
```

Output: [logs/latest-final-t81_determinism_evidence_test.log](logs/latest-final-t81_determinism_evidence_test.log)

## latest-final-t81_determinism_float_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/t81_determinism_float_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_determinism_float_test
```

Output: [logs/latest-final-t81_determinism_float_test.log](logs/latest-final-t81_determinism_float_test.log)

## latest-final-t81_determinism_math_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/t81_determinism_math_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_determinism_math_test
```

Output: [logs/latest-final-t81_determinism_math_test.log](logs/latest-final-t81_determinism_math_test.log)

## latest-final-t81_determinism_new_types_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/t81_determinism_new_types_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_determinism_new_types_test
```

Output: [logs/latest-final-t81_determinism_new_types_test.log](logs/latest-final-t81_determinism_new_types_test.log)

## latest-final-t81_determinism_primitives_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/t81_determinism_primitives_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_determinism_primitives_test
```

Output: [logs/latest-final-t81_determinism_primitives_test.log](logs/latest-final-t81_determinism_primitives_test.log)

## latest-final-t81_determinism_vector_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/t81_determinism_vector_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_determinism_vector_test
```

Output: [logs/latest-final-t81_determinism_vector_test.log](logs/latest-final-t81_determinism_vector_test.log)

## latest-final-t81_isa_binary_io_determinism_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/t81_isa_binary_io_determinism_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_isa_binary_io_determinism_test
```

Output: [logs/latest-final-t81_isa_binary_io_determinism_test.log](logs/latest-final-t81_isa_binary_io_determinism_test.log)

## latest-final-t81_sha3_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/t81_sha3_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_sha3_test
```

Output: [logs/latest-final-t81_sha3_test.log](logs/latest-final-t81_sha3_test.log)

## latest-final-t81_ternary_arith_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/t81_ternary_arith_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_ternary_arith_test
```

Output: [logs/latest-final-t81_ternary_arith_test.log](logs/latest-final-t81_ternary_arith_test.log)

## latest-final-t81_vm_determinism_property_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/t81_vm_determinism_property_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_vm_determinism_property_test
```

Output: [logs/latest-final-t81_vm_determinism_property_test.log](logs/latest-final-t81_vm_determinism_property_test.log)

## latest-final-t81_vm_deterministic_fault_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/t81_vm_deterministic_fault_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_vm_deterministic_fault_test
```

Output: [logs/latest-final-t81_vm_deterministic_fault_test.log](logs/latest-final-t81_vm_deterministic_fault_test.log)

## latest-final-t81_vm_fault_family_determinism_matrix_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/t81_vm_fault_family_determinism_matrix_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_vm_fault_family_determinism_matrix_test
```

Output: [logs/latest-final-t81_vm_fault_family_determinism_matrix_test.log](logs/latest-final-t81_vm_fault_family_determinism_matrix_test.log)

## latest-final-t81_vm_system_registers_deterministic_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/t81_vm_system_registers_deterministic_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_vm_system_registers_deterministic_test
```

Output: [logs/latest-final-t81_vm_system_registers_deterministic_test.log](logs/latest-final-t81_vm_system_registers_deterministic_test.log)

## latest-final-t81_vm_tloadhash_decodefault_determinism_matrix_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/t81_vm_tloadhash_decodefault_determinism_matrix_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_vm_tloadhash_decodefault_determinism_matrix_test
```

Output: [logs/latest-final-t81_vm_tloadhash_decodefault_determinism_matrix_test.log](logs/latest-final-t81_vm_tloadhash_decodefault_determinism_matrix_test.log)

## latest-final-t81_vm_workload_determinism_tiers_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/t81_vm_workload_determinism_tiers_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_vm_workload_determinism_tiers_test
```

Output: [logs/latest-final-t81_vm_workload_determinism_tiers_test.log](logs/latest-final-t81_vm_workload_determinism_tiers_test.log)

## latest-final-test_deterministic_float_boundaries — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/test_deterministic_float_boundaries`

```sh
/private/tmp/t81-base01-execution/latest-build/test_deterministic_float_boundaries
```

Output: [logs/latest-final-test_deterministic_float_boundaries.log](logs/latest-final-test_deterministic_float_boundaries.log)

## latest-final-test_map_determinism — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/test_map_determinism`

```sh
/private/tmp/t81-base01-execution/latest-build/test_map_determinism
```

Output: [logs/latest-final-test_map_determinism.log](logs/latest-final-test_map_determinism.log)

## latest-final-test_resource_monitoring — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/test_resource_monitoring`

```sh
/private/tmp/t81-base01-execution/latest-build/test_resource_monitoring
```

Output: [logs/latest-final-test_resource_monitoring.log](logs/latest-final-test_resource_monitoring.log)

## latest-final-test_t81float_soft_math — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs-final/test_t81float_soft_math`

```sh
/private/tmp/t81-base01-execution/latest-build/test_t81float_soft_math
```

Output: [logs/latest-final-test_t81float_soft_math.log](logs/latest-final-test_t81float_soft_math.log)

## latest-regression-build — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
cmake --build /private/tmp/t81-base01-execution/latest-build --verbose --parallel 2 --target t81_determinism_codec_test t81_determinism_primitives_test t81_determinism_float_test t81_determinism_containers_test t81_determinism_math_test t81_determinism_vector_test t81_determinism_new_types_test test_deterministic_float_boundaries test_map_determinism test_t81float_soft_math t81_vm_determinism_property_test t81_vm_deterministic_fault_test t81_vm_fault_family_determinism_matrix_test t81_vm_tloadhash_decodefault_determinism_matrix_test t81_axion_log_determinism_test t81_vm_system_registers_deterministic_test t81_isa_binary_io_determinism_test t81_vm_workload_determinism_tiers_test t81_ternary_arith_test t81_canonfs_driver_test test_resource_monitoring canonfs_read_verify_test canonfs_read_verify_env_contract_test canonfs_integrity_matrix_test canonfs_identity_contract_test t81_sha3_test
```

Output: [logs/latest-regression-build.log](logs/latest-regression-build.log)

## latest-t81_axion_log_determinism_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/t81_axion_log_determinism_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_axion_log_determinism_test
```

Output: [logs/latest-t81_axion_log_determinism_test.log](logs/latest-t81_axion_log_determinism_test.log)

## latest-t81_canonfs_driver_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/t81_canonfs_driver_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_canonfs_driver_test
```

Output: [logs/latest-t81_canonfs_driver_test.log](logs/latest-t81_canonfs_driver_test.log)

## latest-t81_determinism_codec_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/t81_determinism_codec_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_determinism_codec_test
```

Output: [logs/latest-t81_determinism_codec_test.log](logs/latest-t81_determinism_codec_test.log)

## latest-t81_determinism_containers_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/t81_determinism_containers_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_determinism_containers_test
```

Output: [logs/latest-t81_determinism_containers_test.log](logs/latest-t81_determinism_containers_test.log)

## latest-t81_determinism_evidence_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/t81_determinism_evidence_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_determinism_evidence_test
```

Output: [logs/latest-t81_determinism_evidence_test.log](logs/latest-t81_determinism_evidence_test.log)

## latest-t81_determinism_float_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/t81_determinism_float_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_determinism_float_test
```

Output: [logs/latest-t81_determinism_float_test.log](logs/latest-t81_determinism_float_test.log)

## latest-t81_determinism_math_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/t81_determinism_math_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_determinism_math_test
```

Output: [logs/latest-t81_determinism_math_test.log](logs/latest-t81_determinism_math_test.log)

## latest-t81_determinism_new_types_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/t81_determinism_new_types_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_determinism_new_types_test
```

Output: [logs/latest-t81_determinism_new_types_test.log](logs/latest-t81_determinism_new_types_test.log)

## latest-t81_determinism_primitives_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/t81_determinism_primitives_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_determinism_primitives_test
```

Output: [logs/latest-t81_determinism_primitives_test.log](logs/latest-t81_determinism_primitives_test.log)

## latest-t81_determinism_vector_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/t81_determinism_vector_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_determinism_vector_test
```

Output: [logs/latest-t81_determinism_vector_test.log](logs/latest-t81_determinism_vector_test.log)

## latest-t81_isa_binary_io_determinism_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/t81_isa_binary_io_determinism_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_isa_binary_io_determinism_test
```

Output: [logs/latest-t81_isa_binary_io_determinism_test.log](logs/latest-t81_isa_binary_io_determinism_test.log)

## latest-t81_sha3_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/t81_sha3_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_sha3_test
```

Output: [logs/latest-t81_sha3_test.log](logs/latest-t81_sha3_test.log)

## latest-t81_ternary_arith_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/t81_ternary_arith_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_ternary_arith_test
```

Output: [logs/latest-t81_ternary_arith_test.log](logs/latest-t81_ternary_arith_test.log)

## latest-t81_vm_determinism_property_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/t81_vm_determinism_property_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_vm_determinism_property_test
```

Output: [logs/latest-t81_vm_determinism_property_test.log](logs/latest-t81_vm_determinism_property_test.log)

## latest-t81_vm_deterministic_fault_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/t81_vm_deterministic_fault_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_vm_deterministic_fault_test
```

Output: [logs/latest-t81_vm_deterministic_fault_test.log](logs/latest-t81_vm_deterministic_fault_test.log)

## latest-t81_vm_fault_family_determinism_matrix_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/t81_vm_fault_family_determinism_matrix_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_vm_fault_family_determinism_matrix_test
```

Output: [logs/latest-t81_vm_fault_family_determinism_matrix_test.log](logs/latest-t81_vm_fault_family_determinism_matrix_test.log)

## latest-t81_vm_system_registers_deterministic_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/t81_vm_system_registers_deterministic_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_vm_system_registers_deterministic_test
```

Output: [logs/latest-t81_vm_system_registers_deterministic_test.log](logs/latest-t81_vm_system_registers_deterministic_test.log)

## latest-t81_vm_tloadhash_decodefault_determinism_matrix_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/t81_vm_tloadhash_decodefault_determinism_matrix_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_vm_tloadhash_decodefault_determinism_matrix_test
```

Output: [logs/latest-t81_vm_tloadhash_decodefault_determinism_matrix_test.log](logs/latest-t81_vm_tloadhash_decodefault_determinism_matrix_test.log)

## latest-t81_vm_workload_determinism_tiers_test — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/t81_vm_workload_determinism_tiers_test`

```sh
/private/tmp/t81-base01-execution/latest-build/t81_vm_workload_determinism_tiers_test
```

Output: [logs/latest-t81_vm_workload_determinism_tiers_test.log](logs/latest-t81_vm_workload_determinism_tiers_test.log)

## latest-test_deterministic_float_boundaries — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/test_deterministic_float_boundaries`

```sh
/private/tmp/t81-base01-execution/latest-build/test_deterministic_float_boundaries
```

Output: [logs/latest-test_deterministic_float_boundaries.log](logs/latest-test_deterministic_float_boundaries.log)

## latest-test_map_determinism — return code -6

Working directory: `/private/tmp/t81-base01-execution/test-runs/test_map_determinism`

```sh
/private/tmp/t81-base01-execution/latest-build/test_map_determinism
```

Output: [logs/latest-test_map_determinism.log](logs/latest-test_map_determinism.log)

## latest-test_resource_monitoring — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/test_resource_monitoring`

```sh
/private/tmp/t81-base01-execution/latest-build/test_resource_monitoring
```

Output: [logs/latest-test_resource_monitoring.log](logs/latest-test_resource_monitoring.log)

## latest-test_t81float_soft_math — return code 0

Working directory: `/private/tmp/t81-base01-execution/test-runs/test_t81float_soft_math`

```sh
/private/tmp/t81-base01-execution/latest-build/test_t81float_soft_math
```

Output: [logs/latest-test_t81float_soft_math.log](logs/latest-test_t81float_soft_math.log)

## map-correction-build — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
cmake --build /private/tmp/t81-base01-execution/latest-build --verbose --parallel 4 --target t81_determinism_codec_test t81_determinism_primitives_test t81_determinism_float_test t81_determinism_containers_test t81_determinism_math_test t81_determinism_vector_test t81_determinism_new_types_test test_deterministic_float_boundaries test_map_determinism test_t81float_soft_math t81_vm_determinism_property_test t81_vm_deterministic_fault_test t81_vm_fault_family_determinism_matrix_test t81_vm_tloadhash_decodefault_determinism_matrix_test t81_axion_log_determinism_test t81_vm_system_registers_deterministic_test t81_isa_binary_io_determinism_test t81_vm_workload_determinism_tiers_test t81_ternary_arith_test t81_canonfs_driver_test test_resource_monitoring canonfs_read_verify_test canonfs_read_verify_env_contract_test canonfs_integrity_matrix_test canonfs_identity_contract_test t81_sha3_test t81_determinism_evidence_test
```

Output: [logs/map-correction-build.log](logs/map-correction-build.log)

## pinned-t81_canonfs_driver_test — return code 0

Working directory: `/private/tmp/t81-base01-execution`

```sh
/private/tmp/t81-base01-execution/source-build/t81_canonfs_driver_test
```

Output: [logs/pinned-t81_canonfs_driver_test.log](logs/pinned-t81_canonfs_driver_test.log)

## pinned-t81_ternary_arith_test — return code 0

Working directory: `/private/tmp/t81-base01-execution`

```sh
/private/tmp/t81-base01-execution/source-build/t81_ternary_arith_test
```

Output: [logs/pinned-t81_ternary_arith_test.log](logs/pinned-t81_ternary_arith_test.log)

## pinned-t81_vm_workload_determinism_tiers_test — return code 0

Working directory: `/private/tmp/t81-base01-execution`

```sh
/private/tmp/t81-base01-execution/source-build/t81_vm_workload_determinism_tiers_test
```

Output: [logs/pinned-t81_vm_workload_determinism_tiers_test.log](logs/pinned-t81_vm_workload_determinism_tiers_test.log)

## pinned-test_resource_monitoring — return code 0

Working directory: `/private/tmp/t81-base01-execution`

```sh
/private/tmp/t81-base01-execution/source-build/test_resource_monitoring
```

Output: [logs/pinned-test_resource_monitoring.log](logs/pinned-test_resource_monitoring.log)

## r75-build — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
cmake --build /private/tmp/t81-base01-execution/r75-build --verbose --parallel 2
```

Output: [logs/r75-build.log](logs/r75-build.log)

## r75-configure — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
cmake -S /private/tmp/t81-base01-correctness-latest/experiments/base01_r75_semantics -B /private/tmp/t81-base01-execution/r75-build -G Ninja -DCMAKE_CXX_COMPILER=/usr/bin/c++ -DCMAKE_BUILD_TYPE=Release -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DAUDITED_SOURCE=/private/tmp/t81-base01-execution/source -DAUDITED_BUILD=/private/tmp/t81-base01-execution/source-build
```

Output: [logs/r75-configure.log](logs/r75-configure.log)

## r75-validation — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
python3 -B /private/tmp/t81-base01-correctness-latest/experiments/base01_r75_semantics/verify.py --validate-only --source /private/tmp/t81-base01-execution/source --source-build /private/tmp/t81-base01-execution/source-build --build /private/tmp/t81-base01-execution/r75-build --output /private/tmp/t81-base01-execution/r75-evidence
```

Output: [logs/r75-validation.log](logs/r75-validation.log)

## resource-validation — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
python3 -B experiments/base01_resource_accounting/validate.py --validate-only --cc /usr/bin/cc --build-dir /private/tmp/t81-base01-execution/resource-build --output /private/tmp/t81-base01-execution/resource.json
```

Output: [logs/resource-validation.log](logs/resource-validation.log)

## sha3-corrupt-after-build — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
/usr/bin/c++ -std=c++23 -O3 -DNDEBUG -I /private/tmp/t81-base01-correctness-latest/include /private/tmp/t81-base01-execution/sha3-corrupt-after.cpp /private/tmp/t81-base01-correctness-latest/crypto/sha3.cpp -o /private/tmp/t81-base01-execution/sha3-corrupt-after
```

Output: [logs/sha3-corrupt-after-build.log](logs/sha3-corrupt-after-build.log)

## sha3-corrupt-after — return code 1

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
/private/tmp/t81-base01-execution/sha3-corrupt-after
```

Output: [logs/sha3-corrupt-after.log](logs/sha3-corrupt-after.log)

## sha3-corrupt-before-build — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
/usr/bin/c++ -std=c++23 -O3 -DNDEBUG -I /private/tmp/t81-base01-correctness-latest/include /private/tmp/t81-base01-execution/sha3-corrupt-before.cpp /private/tmp/t81-base01-correctness-latest/crypto/sha3.cpp -o /private/tmp/t81-base01-execution/sha3-corrupt-before
```

Output: [logs/sha3-corrupt-before-build.log](logs/sha3-corrupt-before-build.log)

## sha3-corrupt-before — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
/private/tmp/t81-base01-execution/sha3-corrupt-before
```

Output: [logs/sha3-corrupt-before.log](logs/sha3-corrupt-before.log)

## source-build — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
cmake --build /private/tmp/t81-base01-execution/source-build --verbose --parallel 4 --target t81_ternary_arith_test t81_vm_workload_determinism_tiers_test t81_canonfs_driver_test test_resource_monitoring
```

Output: [logs/source-build.log](logs/source-build.log)

## source-checkout — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
git worktree add --detach /private/tmp/t81-base01-execution/source cda9135d36144d4de2771af174e52ac7b30a83c9
```

Output: [logs/source-checkout.log](logs/source-checkout.log)

## source-configure-offline — return code 0

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
cmake -S /private/tmp/t81-base01-execution/source -B /private/tmp/t81-base01-execution/source-build -G Ninja -DCMAKE_CXX_COMPILER=/usr/bin/c++ -DCMAKE_BUILD_TYPE=Release -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DT81_BUILD_BENCHMARKS=OFF -DT81_BUILD_TUI=OFF -DT81_BUILD_EXAMPLES=OFF -DT81_BUILD_FUZZ_TESTS=OFF -DT81_ENABLE_TERNARYOS=OFF -DT81_ENABLE_DPE=OFF -DFETCHCONTENT_SOURCE_DIR_ASIO=/private/tmp/t81-base01-execution/asio
```

Output: [logs/source-configure-offline.log](logs/source-configure-offline.log)

## source-configure — return code 1

Working directory: `/private/tmp/t81-base01-correctness-latest`

```sh
cmake -S /private/tmp/t81-base01-execution/source -B /private/tmp/t81-base01-execution/source-build -G Ninja -DCMAKE_CXX_COMPILER=/usr/bin/c++ -DCMAKE_BUILD_TYPE=Release -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DT81_BUILD_BENCHMARKS=OFF -DT81_BUILD_TUI=OFF -DT81_BUILD_EXAMPLES=OFF -DT81_BUILD_FUZZ_TESTS=OFF -DT81_ENABLE_TERNARYOS=OFF -DT81_ENABLE_DPE=OFF
```

Output: [logs/source-configure.log](logs/source-configure.log)
