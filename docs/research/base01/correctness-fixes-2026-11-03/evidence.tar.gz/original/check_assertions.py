import json,pathlib,subprocess,sys
root=pathlib.Path('/private/tmp/t81-base01-execution'); repo=pathlib.Path('/private/tmp/t81-base01-correctness-latest')
checks=[]
for name in ['test_deterministic_float_boundaries.cpp','test_map_determinism.cpp']:
 s=(repo/'tests/cpp'/name).read_text()
 (root/('mutated-after-'+name)).write_text(s.replace('int main() {','int main() {\n    assert(false && "deliberate validation sentinel");',1))
 for phase in ['before','after']:
  label=f'assertion-{phase}-{name}'
  cmd=['/usr/bin/c++','-std=c++23','-O3','-DNDEBUG','-DT81_DETERMINISTIC','-I',str(repo/'include'),str(root/(f'mutated-{phase}-'+name)),str(root/'latest-build/libt81_core.a'),'-o',str(root/label)]
  subprocess.run([sys.executable,'-B',str(root/'run.py'),label+'-build',*cmd],check=True)
  p=subprocess.run([sys.executable,'-B',str(root/'run.py'),label,str(root/label)])
  # The recording wrapper exposes signal termination as a nonzero shell code.
  raw=int((root/'logs'/(label+'.exit')).read_text())
  ok=raw==0 if phase=='before' else raw!=0
  checks.append(dict(test=name,phase=phase,returncode=raw,expected_behavior=ok))
  if not ok: raise SystemExit('unexpected sentinel behavior')
(root/'assertion-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
