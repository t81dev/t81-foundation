import json,pathlib,subprocess,sys
r=pathlib.Path('/private/tmp/t81-base01-execution'); repo=pathlib.Path('/private/tmp/t81-base01-correctness-latest')
run=[sys.executable,'-B',str(r/'run.py')]
results=[]
mut=r/'publication-guard-mutants'; mut.mkdir(exist_ok=False)
(mut/'release_correctness_guard.cpp').write_bytes((repo/'tests/cpp/release_correctness_guard.cpp').read_bytes())
for kind,name in [('sha3','test_sha3.cpp'),('float','test_deterministic_float_boundaries.cpp'),('map','test_map_determinism.cpp')]:
 subprocess.run([*run,'publication-guard-'+kind,sys.executable,'-B',str(repo/'tests/python/check_release_correctness_guard.py'),kind,str(r/'latest-build'/('t81_release_'+kind+'_guard'))],check=True)
 original=subprocess.check_output(['git','-C',str(repo),'show','a98b22fb65c80f4225151cbcd5c6934ae076cbe1:tests/cpp/'+name])
 (mut/name).write_bytes(original)
 binary=mut/kind
 subprocess.run([*run,'publication-mutant-build-'+kind,'/usr/bin/c++','-std=c++23','-O3','-DNDEBUG','-DT81_DETERMINISTIC','-DT81_RELEASE_GUARD_'+kind.upper(),'-I',str(repo/'include'),str(mut/'release_correctness_guard.cpp'),str(r/'latest-build/libt81_core.a'),'-o',str(binary)],check=True)
 p=subprocess.run([*run,'publication-mutant-rejection-'+kind,sys.executable,'-B',str(repo/'tests/python/check_release_correctness_guard.py'),kind,str(binary)])
 assert p.returncode==1,(kind,p.returncode)
 results.append(dict(kind=kind,corrected_guard='PASS',original_bug_rejected=True))
(r/'publication-guard-results.json').write_text(json.dumps(results,indent=2)+'\n')
