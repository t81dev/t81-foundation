import os, pathlib, subprocess, sys
root=pathlib.Path('/private/tmp/t81-base01-execution')
repo=pathlib.Path('/private/tmp/t81-base01-correctness-latest')
def run(label,*args,env=None):
 subprocess.run([sys.executable,'-B',str(root/'run.py'),'publication-'+label,*map(str,args)],cwd=repo,env=env,check=True)
for name,dirname in [('foundation','base01_b1_foundation'),('r75','base01_r75_semantics'),('lane-a','base01_lane_a')]:
 prefix='BASE01' if name=='lane-a' else 'AUDITED'
 run(name+'-configure','cmake','-S',repo/'experiments'/dirname,'-B',root/(name+'-build'),'-G','Ninja','-DCMAKE_CXX_COMPILER=/usr/bin/c++','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',f'-D{prefix}_SOURCE={root}/source',f'-D{prefix}_BUILD={root}/source-build')
 run(name+'-build','cmake','--build',root/(name+'-build'),'--verbose','--parallel','2')
 if name=='foundation':
  run('foundation-validation','python3','-B',repo/'experiments'/dirname/'harness.py','--validate-only','--source',root/'source','--source-build',root/'source-build','--build',root/'foundation-build','--output',root/'publication-foundation-evidence')
  env=dict(os.environ,BASE01_FOUNDATION_NATIVE=str(root/'foundation-build/foundation_check'),BASE01_FOUNDATION_RAW=str(root/'publication-foundation-evidence/native.json.gz'))
  run('foundation-tests','python3','-B',root/'unit_no_timing.py',repo/'experiments'/dirname,root/'publication-foundation-tests.json',env=env)
 elif name=='r75':
  run('r75-validation','python3','-B',repo/'experiments'/dirname/'verify.py','--validate-only','--source',root/'source','--source-build',root/'source-build','--build',root/'r75-build','--output',root/'publication-r75-evidence')
 else:
  run('lane-a-validation','python3','-B',repo/'experiments'/dirname/'lane_a.py','--validate-only','--source',root/'source','--source-build',root/'source-build','--native-build',root/'lane-a-build','--output',root/'publication-lane-a-evidence')
  env=dict(os.environ,BASE01_ACCEPTANCE_NATIVE=str(root/'lane-a-build/base01_lane_a'))
  run('lane-a-tests','python3','-B',root/'unit_no_timing.py',repo/'experiments'/dirname,root/'publication-lane-a-tests.json',env=env)
