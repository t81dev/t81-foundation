import json,os,pathlib,subprocess,sys
r=pathlib.Path('/private/tmp/t81-base01-portability/macOS-final');r.mkdir();(r/'logs').mkdir()
repo=pathlib.Path('/private/tmp/t81-base01-correctness-latest'); build=pathlib.Path('/private/tmp/t81-base01-execution/latest-build')
old=json.loads(pathlib.Path('/private/tmp/t81-base01-execution/publication-regressions.json').read_text())
targets=[x['target'] for x in old]
records=[]
def run(label,argv,cwd=repo,env=None):
 entry=dict(label=label,argv=list(map(str,argv)),cwd=str(cwd))
 p=subprocess.run(entry['argv'],cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 entry['returncode']=p.returncode
 (r/'logs'/(label+'.stdout')).write_bytes(p.stdout);(r/'logs'/(label+'.stderr')).write_bytes(p.stderr)
 (r/'logs'/(label+'.command.json')).write_text(json.dumps(entry,indent=2)+'\n');records.append(entry)
 print(label,p.returncode,flush=True)
 return p.returncode
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()=='35f73ac9751423f9ac083c7f4b84def34d810443'
assert run('build',['cmake','--build',build,'--verbose','--parallel','4','--target',*targets,'t81_release_sha3_guard','t81_release_float_guard','t81_release_map_guard'])==0
native=[];guards=[];env=dict(os.environ);env.pop('T81_CANONFS_ROOT',None);env['T81_CANONFS_READ_VERIFY']='1'
for t in targets:
 cwd=r/t;cwd.mkdir();native.append(dict(target=t,returncode=run(t,[build/t],cwd,env)))
for k in ['sha3','float','map']:
 guards.append(dict(kind=k,returncode=run('guard-'+k,[sys.executable,'-B',repo/'tests/python/check_release_correctness_guard.py',k,build/('t81_release_'+k+'_guard')])))
result=dict(source_commit='35f73ac9751423f9ac083c7f4b84def34d810443',native=native,guards=guards,commands=records)
(r/'result.json').write_text(json.dumps(result,indent=2)+'\n')
assert all(x['returncode']==0 for x in native+guards)
