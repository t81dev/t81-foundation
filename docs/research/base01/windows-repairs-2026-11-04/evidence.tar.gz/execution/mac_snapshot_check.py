import hashlib,json,pathlib,subprocess
base=pathlib.Path('/private/tmp/t81-windows-repair-evidence');out=base/'macOS-snapshot';out.mkdir(exist_ok=True)
source=pathlib.Path('/private/tmp/t81-windows-repairs');binary=pathlib.Path('/private/tmp/t81-windows-repair-build/t81');root=out/'store';payload=out/'payload';payload.write_bytes(b'canonfs-read-verify-payload');records=[]
def run(label,args):
 argv=[str(binary),*map(str,args)];p=subprocess.run(argv,cwd=source,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 e=dict(label=label,argv=argv,cwd=str(source),returncode=p.returncode);records.append(e)
 (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr)
 assert p.returncode==0,(label,p.stdout,p.stderr)
 return p.stdout.decode('utf-8').strip()
identifier=run('put',['canonfs','put-file',payload,'--canonfs-root',root])
run('get',['canonfs','get',identifier,'--out',out/'returned','--canonfs-root',root,'--json']);assert (out/'returned').read_bytes()==payload.read_bytes()
snapshot=json.loads(run('snapshot',['canonfs','snapshot','--canonfs-root',root,'--json']))
manifest=(root/'snapshots'/snapshot['hash']/'MANIFEST.txt').read_text()
hexhash=hashlib.sha3_512(payload.read_bytes()).digest()[:32].hex()
expected='objects/h1-'+hexhash+'.blk\t'+identifier+'\n'
assert expected in manifest,(expected,manifest)
assert '\tsha3-256:h1-' not in manifest
(out/'manifest.txt').write_text(manifest)
(out/'result.json').write_text(json.dumps(dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),commands=records,canonical_identifier=identifier,independent_sha3_512_prefix_hex=hexhash,checks=dict(byte_equality=True,portable_physical_path=True,canonical_manifest_identity=True)),indent=2)+'\n')
print('CLI put/get/snapshot canonical identity and returned bytes: PASS')
