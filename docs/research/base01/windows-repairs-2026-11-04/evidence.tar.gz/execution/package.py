import gzip,hashlib,io,json,pathlib,subprocess,tarfile,zipfile,shlex
root=pathlib.Path('/private/tmp/t81-windows-repair-evidence');repo=pathlib.Path('/private/tmp/t81-windows-repairs');out=repo/'docs/research/base01/windows-repairs-2026-11-04';out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
files={};results={};commands=['# Recorded correctness commands\n\nSource: `e09540caeb826df7eaeb9e876be5beb745784921`.\nExact argument vectors and working directories follow. Full output, compiler/link commands, caches and controller sources are archived. Build-tool timing text is incidental, not a performance sample.\n']
for p in (root/'native-zips').glob('*.zip'):
 files['native/'+p.name]=p.read_bytes()
 with zipfile.ZipFile(p) as z:
  r=json.loads(z.read('result.json'));results[p.stem]=r
  commands.append('\n## '+p.stem+'\n')
  for e in r['commands']:commands.append('\n```json\n'+json.dumps({k:e[k] for k in ['label','argv','cwd','returncode']},ensure_ascii=False,indent=2)+'\n```\n')
for p in (root/'initial-native-zips').glob('*.zip'):
 files['initial-native/'+p.name]=p.read_bytes()
for p in (root/'fixture-native-zips').glob('*.zip'):
 files['fixture-native/'+p.name]=p.read_bytes()
for directory in ['controller','initial-controller','fixture-controller','macOS-Release','macOS-snapshot','initial-macOS-Release','initial-macOS-snapshot','identity']:
 for p in (root/directory).glob('*'):
  if p.is_file():files[directory+'/'+p.name]=p.read_bytes()
for p in root.glob('*'):
 if p.is_file() and p.suffix in ['.json','.py','.log']:files['execution/'+p.name]=p.read_bytes()
# Preserve the already-published failure record by identity, not an edited summary.
old=repo/'docs/research/base01/correctness-fixes-2026-11-03/portability'
oldfiles={p.name:sha(p.read_bytes()) for p in old.iterdir() if p.is_file()}
files['before/pr700-published-evidence-identities.json']=(json.dumps(oldfiles,indent=2)+'\n').encode()
for name in ['base01-windows-2022-Debug.zip','base01-windows-2022-Release.zip']:
 p=pathlib.Path('/private/tmp/t81-base01-portability/final-zips')/name;files['before/'+name]=p.read_bytes()
mac=json.loads((root/'macOS-Release/result.json').read_text());results['macOS-Release']=mac
for label,r in [('macOS-Release',mac),('macOS-snapshot',json.loads((root/'macOS-snapshot/result.json').read_text()))]:
 commands.append('\n## '+label+'\n')
 for e in r['commands']:commands.append('\n```json\n'+json.dumps(e,ensure_ascii=False,indent=2)+'\n```\n')
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
(out/'COMMANDS.md').write_text(''.join(commands))
files['README.txt']=b'Native raw ZIPs retain their original bytes and internal manifests. Before records are PR #700 source 35f73ac9751423f9ac083c7f4b84def34d810443; runtime/test/config bytes match reference edaa3fd67fdc08b4979faaf0bf8754866fab80c5. No performance execution.\n'
index={p:sha(b) for p,b in sorted(files.items())};(out/'archive-files.sha256.json').write_text(json.dumps(index,indent=2)+'\n')
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0) as gz:
 with tarfile.open(fileobj=gz,mode='w') as tar:
  for name,b in sorted(files.items()):
   info=tarfile.TarInfo(name);info.size=len(b);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(b))
(out/'evidence.tar.gz').write_bytes(buffer.getvalue())
print('packaged',len(files),'files',len(buffer.getvalue()),'bytes')
