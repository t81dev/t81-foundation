import hashlib,json,pathlib,subprocess,zipfile,io
root=pathlib.Path('/private/tmp/t81-windows-repair-evidence');run='41762988241';repo='t81dev/t81-foundation'
def api(path):return subprocess.check_output(['gh','api',path])
status=api('repos/'+repo+'/actions/runs/'+run);(root/'run.json').write_bytes(status)
jobs=api('repos/'+repo+'/actions/runs/'+run+'/jobs?per_page=100');(root/'jobs.json').write_bytes(jobs)
a=api('repos/'+repo+'/actions/runs/'+run+'/artifacts');(root/'artifacts.json').write_bytes(a)
(root/'native-zips').mkdir(exist_ok=True)
summary={}
for item in json.loads(a)['artifacts']:
 p=root/'native-zips'/(item['name']+'.zip')
 data=p.read_bytes() if p.exists() else api('repos/'+repo+'/actions/artifacts/'+str(item['id'])+'/zip')
 assert item['digest']=='sha256:'+hashlib.sha256(data).hexdigest()
 p.write_bytes(data)
 with zipfile.ZipFile(io.BytesIO(data)) as z:
  assert z.testzip() is None
  sums=json.loads(z.read('SHA256SUMS.json'))
  for name,h in sums.items():assert hashlib.sha256(z.read(name.replace('\\','/'))).hexdigest()==h,name
  result=json.loads(z.read('result.json'))
  summary[item['name']]=dict(status=result['status'],counts=result.get('counts'),error=result.get('error'),source_commit=result.get('source_commit'))
  ext=root/'native-extracted'/item['name'];ext.mkdir(parents=True,exist_ok=True)
  for name in ['result.json','compiler.stdout','compiler.stderr','build-vm.stdout','build-repair-regressions.stdout']:
   (ext/name).write_bytes(z.read(name))
(root/'native-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
if json.loads(status)['status']=='completed':
 for job in json.loads(jobs)['jobs']:
  data=api('repos/'+repo+'/actions/jobs/'+str(job['id'])+'/logs')
  (root/(str(job['id'])+'.log')).write_bytes(data)
