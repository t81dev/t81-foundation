from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path('/private/tmp/t81-windows-repair-evidence');out=root/'identity';out.mkdir(exist_ok=True);records=[]
for payload in ['canonfs-read-verify-payload','canonfs-identity-contract']:
 p=out/(payload+'.input');p.write_bytes(payload.encode())
 argv=['/private/tmp/t81-windows-repair-build/t81','canonfs','put-file',str(p),'--canonfs-root',str(out/'store')]
 child=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd='/private/tmp/t81-windows-repairs');assert child.returncode==0
 ident=child.stdout.decode().strip().removeprefix('sha3-256:')
 (out/(payload+'.stdout')).write_bytes(child.stdout);(out/(payload+'.stderr')).write_bytes(child.stderr)
 matches={}
 for phase,zipdir in [('before',Path('/private/tmp/t81-base01-portability/final-zips')),('after-initial',root/'initial-native-zips'),('after-final',root/'native-zips')]:
  for config in ['Debug','Release']:
   with zipfile.ZipFile(zipdir/('base01-windows-2022-'+config+'.zip')) as z:
    text=z.read('diagnostic-path.stdout').decode('utf-8')
    row=next(x for x in text.splitlines() if x.startswith('payload='+payload+' '))
    actual=row.split(' hash=',1)[1].split(' contains_angle_bracket=',1)[0]
    assert actual==ident,(phase,config,actual,ident)
    matches[phase+'-Windows-'+config]=dict(canonical_identifier_equal=True,raw_diagnostic=row)
 expected='h1-'+hashlib.sha3_512(payload.encode()).digest()[:32].hex()+'.blk'
 assert (out/'store/objects'/expected).read_bytes()==payload.encode()
 records.append(dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/private/tmp/t81-windows-repairs',text=True).strip(),payload=payload,canonical_identifier=ident,canonical_identifier_utf8_hex=ident.encode().hex(),storage_filename=expected,independent_bytes_equal=True,windows_observations=matches,command=dict(argv=argv,cwd='/private/tmp/t81-windows-repairs',returncode=child.returncode)))
(root/'identity-observations.json').write_text(json.dumps(records,indent=2,ensure_ascii=False)+'\n');print('Both legacy Base-81 identities match before/after native Windows and new macOS output; Python SHA3 and stored bytes agree.')
