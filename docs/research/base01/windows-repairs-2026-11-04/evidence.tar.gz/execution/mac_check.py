import importlib.util,json,os,pathlib,platform,subprocess,sys
root=pathlib.Path('/private/tmp/t81-windows-repair-evidence');out=root/'macOS-Release';out.mkdir(exist_ok=True)
source=pathlib.Path('/private/tmp/t81-windows-repairs');build=pathlib.Path('/private/tmp/t81-windows-repair-build')
spec=importlib.util.spec_from_file_location('controller',root/'controller/base01_portability_check.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
records=[]
def run(label,argv):
 e=dict(label=label,argv=list(map(str,argv)),cwd=str(source));p=subprocess.run(e['argv'],cwd=source,stdout=subprocess.PIPE,stderr=subprocess.PIPE);e['returncode']=p.returncode
 (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr);(out/(label+'.command.json')).write_text(json.dumps(e,indent=2)+'\n');records.append(e);print(label,p.returncode,flush=True);return e
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();assert sha=='e09540caeb826df7eaeb9e876be5beb745784921'
run('compiler',['/usr/bin/c++','--version']);run('system',['sw_vers']);run('cmake-version',['cmake','--version']);run('ninja-version',['ninja','--version'])
config=['cmake','-S',source,'-B',build,'-G','Ninja','-DCMAKE_CXX_COMPILER=/usr/bin/c++','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DT81_BUILD_BENCHMARKS=OFF','-DT81_BUILD_TUI=OFF','-DT81_BUILD_EXAMPLES=OFF','-DT81_BUILD_FUZZ_TESTS=OFF','-DT81_ENABLE_TERNARYOS=OFF','-DT81_ENABLE_DPE=OFF','-DFETCHCONTENT_SOURCE_DIR_ASIO=/private/tmp/t81-base01-execution/asio']
assert run('configure',config)['returncode']==0
assert run('build',['cmake','--build',build,'--verbose','--parallel','4','--target',*mod.CORE,*mod.VM,*mod.EXTRA,*mod.GUARDS,'t81'])['returncode']==0
native=[run('test-'+t,[build/t]) for t in mod.CORE+mod.VM];extra=[run('extra-'+t,[build/t]) for t in mod.EXTRA]
guards=[run('guard-'+k,[sys.executable,'-B',source/'tests/python/check_release_correctness_guard.py',k,build/('t81_release_'+k+'_guard')]) for k in ['sha3','float','map']]
result=dict(source_commit=sha,platform=platform.platform(),native=native,extra=extra,guards=guards,commands=records)
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');assert all(e['returncode']==0 for e in native+extra+guards)
