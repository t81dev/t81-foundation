# Open PR inventory — 2026-11-13

This is a read-only inventory, not acceptance, merge authorization, closure,
policy activation or experimental execution approval.

- [Complete 80-row decision table](DECISIONS.md)
- [Exact changed files, dependencies, overlaps and review/check evidence](FILES_AND_EVIDENCE.md)
- [Source-backed supersession recommendations](CLOSURE_EVIDENCE.md)
- [Machine-readable inventory](inventory.json)
- [Spreadsheet summary](decisions.csv)
- [Collection/checkpoint](checkpoint.json)

Main is pinned to `88300f14c1da1066ad6db25d31be0e8e912b3ef0` throughout.
There are 80 open PRs; the second REST page was empty. Every head was fetched
into an isolated temporary shared clone, and every inventory head was checked
against the local ref. Current #782 is pinned to
`125a1897b7e7e068ef6d576d97c487295c7203a7`; it changed from `d9701d8...`
during collection. Previously tested `cbb324ad...` remains historical evidence.
PR #782's body still labels cbb324ad as current, so do not use it as live metadata.

## Methods actually executed

Refreshed GitHub open-PR/main metadata; fetched all current heads; collected
submitted reviews, top-level comments, inline comments/review-thread state,
and current-head checks. All returned lists were smaller than the requested
100-item limit; review threads were small. No test/build/measurement result was
created by this inventory. Previous session/local audit receipts are explicitly
historical inputs, not new independent reproductions. CI is recorded by exact
head, with URLs and status; latest check ID per name is used in the summary.

Executed source/commit comparisons:

- `git merge-base MAIN HEAD`
- `git diff --name-status --no-renames MERGE_BASE HEAD`
- `git ls-tree -rz HEAD` and per-path blob comparison with current main
- `git patch-id --stable` for cumulative branch deltas (no identical nonempty pair)
- commit ancestry graph for open-head stack dependencies
- read-only `git merge-tree --write-tree MAIN HEAD` simulations in the isolated
  clone (not actual branch merges)
- focused pinned source/diff inspection of supersession candidates, competing
  corrections, unsafe/stale current source, and original review findings

Collection and comparison scripts are retained. Exact source bodies and review
pins are in the JSON. Shared-path overlap is mechanical, not proof of semantic
conflict, duplication or functional dependence. Actual PR base is recorded
separately from body references and inferred/conceptual dependencies.

## Important limits and disclosures

- This Codex session authored earlier #782 arithmetic/capture corrections and
  earlier audit candidates; it is not an independent reviewer of its own work.
  The latest #782 delta was only source-inspected here, not executed locally.
- Formal reviews frequently target earlier heads. Review counts and unresolved
  threads are not acceptance; outdated does not prove correction, and a thread
  marked current can describe an issue already fixed by moving a file (#648).
- Existing #779/#780 acceptance/handoff is reused within its declared bounds.
  Full-domain Cell multiplication still has 352 known representable-product
  exceptions; the exact-count test acknowledges defects. Original benchmark
  source-to-binary binding remains unverified. No new campaign is authorized.
- #782 at d9701d8 had completed Windows failures in cli_pipeline_test (logs
  inspected); the next 125a189 commit changes that diagnostic-path expectation.
  Those failed jobs do not establish the outcome at 125a189. Its fresh complete
  Windows jobs and CodeQL are still needed at the recorded checkpoint.
- The actual AI Experiments log at 125a189 fails freshness for unchanged
  AI_RFC_BACKLOG.md, CI_WORKFLOW_CONFIRMATION.md and CI_GATE_STATUS.md
  (`age_days=8`, `max_age_days=7`). No dates/checks were altered.
- Main has failed Windows/quality checks. This does not prove every PR failure
  shares main's root cause. Failed names are recorded without blanket baseline
  attribution. No all-platform readiness or comparative-performance claim follows.
- Research/host/governance prerequisites remain human decisions. No benchmark,
  model download, boot campaign, SCG-08 advancement or normative change occurred.
- Original project worktree and branches, all open PRs and remote metadata were
  unchanged. Only an isolated temporary clone and these report files were created.

## Five highest-value next actions

1. Finish #782 at 125a189: independently review path normalization, scratch-file
   ownership and current scope; correct stale head/results metadata; require full
   fresh MSVC and clang-cl jobs and inspect their actual logs before claiming repair.
2. Review production authorization fixes #748 and #750, then dependent #751.
   Retarget off no-op #747 without losing current-main/782 CLI changes; run focused
   denial-before-side-effect and literal-argv tests.
3. Choose one RFC-00E1 correction from #779/#778 using the five shared-file diff,
   preserving unique rejection evidence. Review #780 separately under its bounded
   acceptance/provenance/352-exception limits; do not promote SCG-08 gates.
4. Port #767's still-unique validator checks onto current main while preserving
   #775 generation fields/tests, and repair #761's unsupported readiness/threshold
   wording. No new experiment or retrospective authority should be inferred.
5. Ask the maintainer to approve the five source-backed supersession dispositions;
   preserve their historical receipts. Consolidate fresh operational overlays for
   #764/#773 and review #774 rather than publishing competing stale status snapshots.
