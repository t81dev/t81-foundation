import json,subprocess as s
from pathlib import Path
p=Path('/tmp/t81-pr-inventory-2026-11-13/inventory.json');data=json.loads(p.read_text());cwd='/tmp/t81-open-pr-inventory-20261113'
for r in data['records']:
 result=s.run(['git','merge-tree','--write-tree',data['main'],r['head']],cwd=cwd,stdout=s.PIPE,stderr=s.PIPE,text=True)
 lines=result.stdout.splitlines();r['merge_simulation']={'exit_code':result.returncode,'tree':lines[0] if lines else None,'conflicts':lines[1:],'stderr':result.stderr}
 r['merge_has_no_tree_change']=result.returncode==0 and r['merge_simulation']['tree']==data['main_tree']
 print(r['number'],result.returncode,'NO-OP' if r['merge_has_no_tree_change'] else '',flush=True)
p.write_text(json.dumps(data,indent=2))
