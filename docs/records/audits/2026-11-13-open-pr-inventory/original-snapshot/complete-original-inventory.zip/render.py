import json,collections,csv,hashlib,re,subprocess as sp,shutil
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from decisions import D
out=Path('/tmp/t81-pr-inventory-2026-11-13');data=json.loads((out/'inventory.json').read_text());threads=json.loads((out/'threads.json').read_text());checks={r['number']:r['checks'] for r in json.loads((out/'latest-checks.json').read_text())};checkpoint=json.loads((out/'checkpoint.json').read_text());checkpoint['no_original_repository_or_github_mutations']=checkpoint.pop('no_repository_or_github_mutations', True);(out/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2))
assert len(D)==len(data['records'])==80
assert set(D)=={r['number'] for r in data['records']}
assert len({r['head'] for r in data['records']})==80
counts=collections.Counter()
for r in data['records']:
 n=r['number'];assert sp.check_output(['git','rev-parse',f'refs/review/pr{n}'],cwd='/tmp/t81-open-pr-inventory-20261113',text=True).strip()==r['head']
 decision,purpose,note,deps=D[n];counts[decision]+=1
 r.update(classification=decision,purpose=purpose,decision_evidence=note,dependency_assessment=deps,uncertain=decision in ['NEEDS INVESTIGATION','DEFER'])
 if n in [782,778,718,698,649,603]:r['uncertain']=True
 r['checks']=checks[n];latest={}
 for c in checks[n]:
  if c['name'] not in latest or c['id']>latest[c['name']]['id']:latest[c['name']]=c
 r['latest_checks_by_name']=list(latest.values());r['ci_counts']=dict(collections.Counter(c['conclusion'] if c['status']=='completed' else 'pending' for c in latest.values()))
 r['review_threads']=threads.get(str(n),{}).get('review_threads',[])
 r['unresolved_current_thread_count']=sum(not t['is_resolved'] and not t['is_outdated'] for t in r['review_threads'])
 r['unresolved_outdated_thread_count']=sum(not t['is_resolved'] and t['is_outdated'] for t in r['review_threads'])
 r['body_pr_references']=sorted({int(s) for s in re.findall(r'#(\d+)',r['body'] or '')})
 r['snapshot_head_matches_local_ref']=True
 r['source_compare_url']=f"https://github.com/t81dev/t81-foundation/compare/{data['main']}...{r['head']}"
data.update(final_metadata_checkpoint=checkpoint,classification_counts=dict(counts),closed_dependency_metadata=json.loads((out/'closed-dependencies.json').read_text()),limitations=['No tests, benchmarks, model downloads, boot campaigns, merges, PR closures or remote writes performed in this inventory.','Review threads, bot summaries, prior reports and author measurements are retained as evidence sources; none are automatically fresh independent validation.','CI reports are snapshots at pinned heads. Latest named check wins; skipped, canceled, neutral and no checks are not equivalent to passing full coverage.','Changed-file and overlap data are mechanical. Shared paths alone do not establish duplicate behavior or a functional dependency.','Temporary isolated clone and reports were created; original workspace branches and pre-existing dirty files were not modified.'])
(out/'inventory.json').write_text(json.dumps(data,indent=2))
def ci(r):
 c=r['ci_counts'];return 'none' if not c else ', '.join(f'{c[k]} {label}' for k,label in [('success','pass'),('failure','fail'),('pending','pending'),('skipped','skip'),('cancelled','canceled'),('neutral','neutral')] if c.get(k))
def review(r):
 states=collections.Counter(x['state'] for x in r['reviews']);s=', '.join(f'{v} {k}' for k,v in states.items()) or 'No formal review'
 return f"{s}; threads {r['unresolved_current_thread_count']} current/{r['unresolved_outdated_thread_count']} outdated"
def esc(s):return s.replace('|','\\|').replace('\n',' ')
rows=['# Open PR decisions against current main','',f"Main: `{data['main']}`; tree `{data['main_tree']}`.",f"Final metadata checkpoint: {checkpoint['last_refreshed']} (America/New_York: {datetime.strptime(checkpoint['last_refreshed'],'%Y-%m-%d %H:%M:%S UTC').replace(tzinfo=ZoneInfo('UTC')).astimezone(ZoneInfo('America/New_York')).isoformat()}).",'', '80 open PRs; second REST page empty. Full 40-character heads are below. Files are own delta / main-merge-base delta; inherited files are included only in the latter. Exact file lists, blob comparisons, all overlap paths and review/check URLs are in [FILES_AND_EVIDENCE.md](FILES_AND_EVIDENCE.md) and [inventory.json](inventory.json).', '', '**?** means an unresolved scope/dependency/evidence decision, not a proven defect. REVIEW NEXT means bounded review priority, never merge readiness. No-check and skipped states are missing coverage, not green. CI failures below are statuses, not assumed root causes.', '', '| PR / exact head | Purpose; own/main file counts | Decision | Dependencies, overlap and evidence | CI |','|---|---|---|---|---|']
for r in data['records']:
 n=r['number'];dep=('base #'+str(r['base_pr'])) if r['base_pr'] else ('base '+r['base_ref']);over=sorted(r['overlap_own_paths'],key=lambda x:-len(x['paths']))[:3];ovs=', '.join(f"#{x['pr']} ({len(x['paths'])})" for x in over) or 'none'
 detail=f"{dep}; path overlap {ovs}. {r['decision_evidence']} Review: {review(r)}."
 rows.append(f"| [#{n}]({r['url']})<br>`{r['head']}` | {esc(r['purpose'])}; {len(r['files_own_delta'])}/{len(r['files_vs_main_mergebase'])} | **{r['classification']}**{' ?' if r['uncertain'] else ''} | {esc(detail)} | {ci(r)} |")
rows+=['','No DUPLICATE classification is asserted: the 80 cumulative stable patch IDs contain no equal nonempty pair. This does not prove semantic uniqueness; candidate alternatives remain explicitly uncertain. See [CLOSURE_EVIDENCE.md](CLOSURE_EVIDENCE.md) for all five source-backed supersession recommendations.']
(out/'DECISIONS.md').write_text('\n'.join(rows)+'\n')
files=['# Exact files, dependencies, overlap and review evidence','', 'All source links are pinned to heads, not mutable branches. Own delta is merge-base of actual PR base and head; main delta is merge-base of current main and head. I/D/A/X = identical to current main / different / absent on main / deleted by head, for paths in main delta. Direct head-versus-main tree differences also include later main changes; they are not automatically a proposed rollback.', '']
for r in data['records']:
 n=r['number'];files += [f'## PR {n}: {r["title"]}', '',f'- Head `{r["head"]}`; actual base `{r["base"]}` (`{r["base_ref"]}`); main merge-base `{r["merge_base_main"]}`.',f'- Purpose: {r["purpose"]}. Decision: **{r["classification"]}**.',f'- Dependency assessment: {r["dependency_assessment"]}',f'- Open heads included by ancestry: {r["contains_open_pr_heads"]}; references in body (not necessarily dependencies): {r["body_pr_references"]}.',f'- Evidence/limits: {r["decision_evidence"]}',f'- Blob counts: {r["blob_summary"]}. Merge simulation exit {r["merge_simulation"]["exit_code"]}; tree `{r["merge_simulation"]["tree"]}`; equals main: {r["merge_has_no_tree_change"]}.',f'- Review: {review(r)}. Complete bodies and original review commit pins retained in JSON; unresolved does not establish current validity, and outdated does not prove corrected.',f'- CI: {ci(r)}; all latest named check URLs are in JSON.',f'- [Pinned source comparison]({r["source_compare_url"]}).','', 'Own changed files:', '']
 for f in r['files_own_delta']:
  rev=r['own_mergebase'] if f['status']=='D' else r['head']
  files.append(f"- `{f['status']} {f['path']}` ([pinned source](https://github.com/t81dev/t81-foundation/blob/{rev}/{f['path']}))")
 files+=['','All changed files versus main merge-base (including parents):','']
 for f in r['files_vs_main_mergebase']:files.append(f"- `{f['status']} {f['path']}` — {f['comparison']}; main blob `{f['main_blob']}`; head blob `{f['head_blob']}`.")
 files+=['','Overlaps with other PR own deltas:','']
 for ov in r['overlap_own_paths']:files.append(f"- #{ov['pr']}: "+', '.join('`'+s+'`' for s in ov['paths']))
 if not r['overlap_own_paths']:files.append('- None.')
 files+=['','Review submissions:','']
 for v in r['reviews']:files.append(f"- {v.get('user',{}).get('login')} / {v['state']} / reviewed `{v.get('commit_id')}` / [review]({v.get('html_url')}).")
 if not r['reviews']:files.append('- No formal submitted review returned; comments/receipts remain separately retained.')
 files+=['','Failed or incomplete checks:','']
 for c in r['latest_checks_by_name']:
  if c['status']!='completed' or c['conclusion'] not in ['success','skipped','neutral']:files.append(f"- [{c['name']}]({c['details_url']}): {c['status']} / {c['conclusion']}.")
 files.append('')
(out/'FILES_AND_EVIDENCE.md').write_text('\n'.join(files)+'\n')
with (out/'decisions.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['PR','Head SHA','Classification','Uncertain','Purpose','Own files','Main delta files','Base PR','CI','Evidence','Dependencies']);w.writerows([[r['number'],r['head'],r['classification'],r['uncertain'],r['purpose'],len(r['files_own_delta']),len(r['files_vs_main_mergebase']),r['base_pr'],ci(r),r['decision_evidence'],r['dependency_assessment']] for r in data['records']])
print(json.dumps({'counts':dict(counts),'rows':len(data['records']),'main':data['main'],'pr782':next(r['head'] for r in data['records'] if r['number']==782)}))
