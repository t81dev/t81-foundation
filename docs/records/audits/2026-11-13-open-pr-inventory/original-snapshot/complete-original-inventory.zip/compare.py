import subprocess as sp,json,collections
from pathlib import Path
root=Path('/tmp/t81-open-pr-inventory-20261113')
def git(*a,raw=False):
 r=sp.run(['git',*a],cwd=root,check=True,stdout=sp.PIPE);return r.stdout if raw else r.stdout.decode()
data=json.loads(Path('/tmp/t81-pr-inventory-2026-11-13/github.json').read_text());main=data['main'];prs=data['records']
cache={}
def tree(rev):
 if rev not in cache:
  entries={}
  for line in git('ls-tree','-rz',rev).split('\0'):
   if line:
    info,path=line.split('\t',1);entries[path]=info.split()[2]
  cache[rev]=entries
 return cache[rev]
mt=tree(main)
for p in prs:
 head=p['head'];n=p['number'];mb=git('merge-base',main,head).strip();p['merge_base_main']=mb
 ht=tree(head);p['head_tree']=git('rev-parse',head+'^{tree}').strip();p['ancestor_of_main']=sp.run(['git','merge-base','--is-ancestor',head,main],cwd=root).returncode==0
 def diff_files(base):
  output=git('diff','--name-status','--no-renames',base,head).splitlines();return [{'status':s,'path':path} for s,path in (l.split('\t',1) for l in output)]
 p['files_vs_main_mergebase']=diff_files(mb)
 p['own_mergebase']=git('merge-base',p['base'],head).strip();p['files_own_delta']=diff_files(p['own_mergebase'])
 for f in p['files_vs_main_mergebase']:
  path=f['path'];a=mt.get(path);b=ht.get(path);f.update(main_blob=a,head_blob=b,comparison='identical' if a==b else 'absent_main' if a is None else 'deleted_head' if b is None else 'different')
 p['blob_summary']=dict(collections.Counter(f['comparison'] for f in p['files_vs_main_mergebase']))
 diff=git('diff','--binary',mb,head,raw=True);patch=sp.run(['git','patch-id','--stable'],input=diff,stdout=sp.PIPE,check=True).stdout.decode().split();p['patch_id']=patch[0] if patch else None
 p['commits_not_main']=git('log','--format=%H%x09%s',main+'..'+head).splitlines()
 print(n,p['blob_summary'],flush=True)
# Ancestor relations computed by one history traversal then memoized per head.
graph={}
for l in git('rev-list','--parents',main,*[p['head'] for p in prs]).splitlines():
 fields=l.split();graph[fields[0]]=fields[1:]
heads={p['head']:p['number'] for p in prs}
for p in prs:
 seen=set();stack=graph[p['head']][:];parents=[]
 while stack:
  node=stack.pop()
  if node in seen:continue
  seen.add(node)
  if node in heads:parents.append(heads[node])
  stack.extend(graph.get(node,[]))
 p['contains_open_pr_heads']=sorted(parents)
 own={f['path'] for f in p['files_own_delta']}
 p['overlap_own_paths']=[{'pr':q['number'],'paths':sorted(own&{f['path'] for f in q['files_own_delta']})} for q in prs if q!=p and own&{f['path'] for f in q['files_own_delta']}]
 p['patch_duplicates']=[q['number'] for q in prs if q!=p and p['patch_id'] and p['patch_id']==q['patch_id']]
data['main_tree']=git('rev-parse',main+'^{tree}').strip()
Path('/tmp/t81-pr-inventory-2026-11-13/inventory.json').write_text(json.dumps(data,indent=2))
