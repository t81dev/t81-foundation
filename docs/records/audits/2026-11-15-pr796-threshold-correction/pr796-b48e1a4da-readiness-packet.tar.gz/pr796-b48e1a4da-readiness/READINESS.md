# Combined integration readiness report

Status: **REQUIRED CI QUALIFIED; READY FOR HUMAN REVIEW WITH ONE INFORMATIONAL FAILURE**. No merge or closure performed.

Candidate: [draft PR #796](https://github.com/t81dev/t81-foundation/pull/796),
branch `candidate/pr794-pr795-pr780-main-integration`, head
`b48e1a4da29784860a528e5397f896c73bc48450`.
Refreshed main: `c2ab68e582c9f773ce94a9e13bcb805016f07dd4`.
Hosted PR merge revision: `0327f778bc39fb95778c7048130cb8b439eedee6`.

## Component preservation

| Source | Accepted head | Accepted changed files | Result |
|---|---|---:|---|
| #794 wrapper | `5f5751ae9b9f634f2af2cb020afef6f9e2cd610d` | 33 | All contents/modes/Git blobs preserved |
| #795 validator | `43747b60675444ab58f693713577d6cd42e3f234` | 8 | All contents/modes/Git blobs preserved |
| #780 Cell baseline | `c08c211bd3475d8b09e35648f84c6b5c0a7e31a2` | 7 | All contents/modes/Git blobs preserved |

There were no inter-component overlaps or overlaps with newer main changes;
this finding was reported before assembly. No substantive conflict resolution
was needed. Original source PR branch tips and main were rechecked remotely and
remain unchanged. `accepted-file-identities.json` in the published packet records
all 48 paths, blobs, file modes and SHA-256 values. All remained byte-identical
after integration-only CI work.

#795's 43-file parity packet is retained byte-for-byte, including generically
ignored CMake/CTest identity receipts, with its original manifest verified.
Those historical executions retain source #795's identity. They are not
relabeled as combined-candidate execution.

#780 raw and structured measurements retain exact source blobs; corrected
CPU-time/batch-time/provenance documentation is retained. Raw historical label
strings are not rewritten. Production Cell arithmetic, SCG-08 evidence/schema/
implementation report and existing historical benchmark reports remain unchanged
from main. No new Cell timing/performance campaign was run. The standard hosted
SIMD regression and VM smoke/guardrail jobs run within existing CI mechanisms;
SIMD thresholds/checker remain intact and report generation is disabled there.

## Test execution

Local: macOS 26.5.2 ARM64, AppleClang 21, Python 3.14.3, Release/NDEBUG.
Compiled component source was tested at assembly commit
`1201ccd421d2fec5630dbe05c6eb06e39a9134b0`; subsequent candidate commits alter
CI policy/wiring and retain receipts, with component identities verified again.

| Execution route | Result |
|---|---|
| Fresh Release CLI, process capture, repro-hash, Cell test and benchmark-runner build | PASS; benchmark runner compiled but not executed locally |
| Direct wrapper harness | PASS: 86 process receipts, zero failed checks |
| Direct execution-policy matrix | PASS: 249 CLI processes, zero failed checks |
| Direct validator positive / negative / JSON-file suites | All six normal/-O commands PASS with jsonschema==4.26.0 |
| Direct negative suites | 94 negatives each; 61 rejected / 2 positive Draft 7 parity controls each, actually executed |
| Direct JSON-file suites | 57 cases each (49 rejection / 8 positive), including actual child CLI processes |
| Registered targeted Release CTests | 10/10 PASS: wrapper, execution policy, repro-hash, process capture, Cell oracle, five validator registrations |
| CTest validator parity | Both normal and explicit -O negative registrations execute the same 61/2 controls |
| Optimized positive validator | Direct Python PASS; no separate optimized-positive CTest registration claimed |

The exhaustive Cell CTest reports 243 conversions; addition/subtraction each
44,287 valid / 14,762 overflow pairs; 441/441 safe multiplication pairs; full
multiplication 2,553 successes / 56,144 true overflows / 352 documented in-range
intermediate overflows; division 58,806 valid / 243 zero-divisor rejections.
These are correctness/known-limitation observations, not new throughput results.

Hosted validator suites: the existing CI spec/docs job now runs all six direct
Python commands on Linux/Python 3.12 with jsonschema==4.26.0. Raw logs prove
normal and -O parity execution and 57 JSON-file cases in each mode. This is
**hosted direct Python**, distinct from local CTest execution. Experiments remain
OFF in the general hosted CMake configuration; no hosted SCG-08 CTest execution
is implied. UNIX wrapper and Cell tests run through the normal matrix's CTest
selection; final matrix status and raw evidence are recorded below.

## Qualification failures and corrections

1. Local workflow audits reproduced inherited main failures: seven mutable
   action references and one missing explicit permissions block. Those refs
   were pinned to commits resolved from their actual upstream tags/branch,
   and x86 QEMU received contents: read. Original failed receipts, resolutions
   and corrected passing audits are retained. No accepted component changed.
2. Hosted main CI attempt 1 stopped on an unchanged IBM research citation's
   network/certificate request error. Validator suites had already passed;
   downstream build jobs were skipped, not passed. The raw failing job and
   original validator artifact ZIP are retained. A failed-jobs retry at the
   **same head** passed the docs/spec gate and started the complete matrix.
   No link bypass, source citation change or CI gate waiver was introduced.

The complete main hosted run
[43717280854, attempt 2](https://github.com/t81dev/t81-foundation/actions/runs/43717280854/attempts/2)
finished with workflow conclusion **success** at the pinned combined head.
All required jobs and `quality gate / required` passed. Across all 34 jobs:
**30 success, 1 informational failure, 3 schedule-only experimental skips**.
Skipped experimental architecture jobs were not validated. No gates were waived
or changed to continue-on-error by this candidate.

All six triggered workflows completed successfully: T81 Foundation CI, Format,
CodeQL, Cross-Platform Determinism Verification, AI Experiments CI and QEMU x86.
The existing ARMv9 job's continue-on-error policy explains how the overall main
workflow can succeed while retaining its explicit job failure below.

| Hosted platform/compiler | Passing full CTest count | Component checks |
|---|---:|---|
| Linux x86_64 / GCC | 429 | Policy, wrapper, Cell PASS |
| Linux x86_64 / Clang | 429 | Policy, wrapper, Cell PASS |
| Linux ARM64 / Clang | 428 | Policy, wrapper, Cell PASS |
| macOS ARM64 / Clang | 428 | Policy, wrapper, Cell PASS |
| macOS Intel / GCC | 429 | Policy, wrapper, Cell PASS |
| Windows x86_64 / MSVC | 405 | Policy and Cell PASS; UNIX wrapper not registered |
| Windows x86_64 / clang-cl | 405 | Policy and Cell PASS; UNIX wrapper not registered |

C++20 and C++23 compatibility, strict warnings, static analysis, sanitizer tests
(429 tests), repeatability, determinism slices, T3_K/T81Lang cross-architecture
identity, formal/fuzz checks and SIMD/VM regression guards all passed. The TUI
size check also passed. Seven original build artifact ZIPs are retained and their
SHA-256 digests match the GitHub artifact metadata. Their plain-text CTest logs
support the table; these hosted ZIPs do not contain JUnit XML. Local JUnit remains
retained separately. `hosted-component-test-summary.json` extracts exact passing
result lines without substituting for the raw logs.

### Remaining failure

**ARMv9 informational cross-compile, job 132829965555:** `complex_demo` fails
because `include/t81/types/all.hpp:12` includes unavailable `asio.hpp`. The failed
example, header and ARMv9 workflow section are byte-identical to base main;
`armv9-failure-scope.json` retains those identities. This supports attribution
to the existing example/profile dependency gap by source inspection. A separate
base-main cross-build was not executed, so no reproduced baseline pass/fail is
claimed. Native ARM64 tests passed; they do not establish success for this failed
cross-compile profile.

The failure's raw job log is retained, not waived or relabeled as passing.
No reviewed component was changed to conceal it. A follow-up should either fix
the example's Asio include dependency or explicitly define the cross-build lane's
intended target scope. This qualification does not claim clean ARMv9 cross-build
support. The documented Cell 352 in-range intermediate multiplication overflows
also remain a preserved implementation limitation, not a newly introduced CI
failure.

## Closure recommendations and limits

Recommend #796 as the single review/integration vehicle: required qualification
is complete, with the ARMv9 informational exception requiring an explicit human
disposition or follow-up. Keep #794, #795 and #780 open until a human chooses
and integrates this candidate. After that integration, recommend closing those
three as superseded by #796, preserving their heads and evidence rather than
separately merging duplicate deltas. No automatic closure of original #751/#767 follows.
No source PR, draft candidate or main branch was merged or closed.

Local execution is macOS ARM64 only. Hosted claims apply solely to actual
recorded platforms, steps, source and attempts; skipped jobs are not tests.
Codex authored this integration and verification with prior shared context;
these are engineering qualification results, not independent scientific
acceptance, new performance measurements, Gate 2 approval or governance activation.

Published preservation/local packet:
[records at the candidate head](https://github.com/t81dev/t81-foundation/tree/b48e1a4da29784860a528e5397f896c73bc48450/docs/records/audits/2026-11-15-pr794-pr795-pr780-integration).
Hosted logs, API responses, artifacts and this final readiness report are retained
separately in the `2026-11-15-pr796-hosted-readiness` packet so adding qualification
evidence does not change the qualified head. The committed assembly report's
"pending" wording is its historical publication state; this report supplies the
completed qualification and preserves the earlier failed attempt.
