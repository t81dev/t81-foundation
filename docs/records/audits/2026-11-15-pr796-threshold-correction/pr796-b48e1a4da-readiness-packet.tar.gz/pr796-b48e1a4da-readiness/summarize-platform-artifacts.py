import hashlib,json,re,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
results=[]
for p in sorted(root.glob('ci-build-*.zip')):
 with zipfile.ZipFile(p) as z:
  member='.github/logs/build-and-test.log'
  text=z.read(member).decode('utf-8',errors='replace')
 lines=text.splitlines()
 totals=[line.strip() for line in lines if '100% tests passed' in line]
 names=['t81_cli_execution_policy_test','t81_skill_policy_boundary_test','t81_determinism_primitives_test']
 tests=[]
 for name in names:
  matches=[line.strip() for line in lines if name in line and 'Test #' in line and 'Passed' in line]
  tests.append({'name':name,'passing_result_lines':matches})
 required=[x for x in tests if x['name']!='t81_skill_policy_boundary_test' or 'windows' not in p.name]
 if any(not x['passing_result_lines'] for x in required): raise RuntimeError((p.name,tests))
 if not totals: raise RuntimeError('Missing passing CTest total: '+p.name)
 summary={'artifact':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'members':z.namelist(),'ctest_total_lines':totals,'component_ctest_results':tests,'policy_process_receipts':[line.strip() for line in lines if 'PASS: 249 CLI processes' in line],'wrapper_process_receipts':[line.strip() for line in lines if 'PASS: 86 process receipts' in line],'cell_oracle':[line.strip() for line in lines if 'Cell oracle summary:' in line],'scg08_ctest_names_seen':[line.strip() for line in lines if 'scg08' in line.lower() and 'Test #' in line],'junit_xml_members':[m for m in z.namelist() if m.endswith('.xml')]}
 (root/(p.stem+'.summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
 results.append(summary)
(root/'hosted-component-test-summary.json').write_text(json.dumps(results,indent=2)+'\n')
print('Verified component passing CTest lines in',len(results),'platform artifacts.')
for s in results: print(s['artifact'],s['ctest_total_lines'][-1])
