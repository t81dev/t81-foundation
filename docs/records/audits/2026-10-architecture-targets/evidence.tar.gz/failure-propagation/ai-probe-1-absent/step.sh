mkdir -p build/ai-rfc0025
cmake --build build --target help > build/ai-cmake-targets.txt
if grep -qE '(^| )t81_vm_tloadhash_conformance_test$' build/ai-cmake-targets.txt; then
  cmake --build build --target t81_vm_tloadhash_conformance_test
  cmake --build build --target t81_vm_tloadhash_decodefault_determinism_matrix_test
else
  echo "❌ t81_vm_tloadhash_conformance_test target not found"
  exit 1
fi
