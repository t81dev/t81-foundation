mkdir -p build/ai-opcodes
cmake --build build --target help > build/ai-cmake-targets.txt
if grep -qE '(^| )t81_vm_ai_phase1_qmatmul_conformance_test$' build/ai-cmake-targets.txt; then
  cmake --build build --target t81_vm_ai_phase1_attention_conformance_test
  cmake --build build --target t81_vm_ai_phase1_embed_conformance_test
  cmake --build build --target t81_vm_ai_phase1_qmatmul_conformance_test
  cmake --build build --target t81_vm_ai_phase1_shared_helper_parity_test
  ctest --test-dir build --output-on-failure --verbose \
    -R 't81_vm_ai_phase1_attention_conformance_test|t81_vm_ai_phase1_embed_conformance_test|t81_vm_ai_phase1_qmatmul_conformance_test|t81_vm_ai_phase1_shared_helper_parity_test' \
    2>&1 | tee build/ai-opcodes/ai_phase1_opcode_ctest.log
else
  echo "❌ t81_vm_ai_phase1_qmatmul_conformance_test target not found"
  exit 1
fi
