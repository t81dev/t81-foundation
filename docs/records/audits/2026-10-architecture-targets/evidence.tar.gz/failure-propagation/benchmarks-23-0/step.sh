python3 scripts/ci/check_simd_regression.py bench.json 2>&1 | tee -a .github/logs/benchmark.log
