cmake --build build --target help > build/ai-cmake-targets.txt
if grep -qE '(^| )t81_ai$' build/ai-cmake-targets.txt; then
  echo "has_target=true" >> "$GITHUB_OUTPUT"
  cmake --build build --target t81_ai
else
  echo "has_target=false" >> "$GITHUB_OUTPUT"
  echo "ℹ️ target t81_ai is not defined in this configuration; skipping AI build."
  exit 0
fi
