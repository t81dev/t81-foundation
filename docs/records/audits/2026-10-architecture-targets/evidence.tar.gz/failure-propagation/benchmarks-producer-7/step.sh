bash -c 'echo producer-out; echo producer-err >&2; exit 7' 2>&1 | tee command.log
printf reached > following-command
