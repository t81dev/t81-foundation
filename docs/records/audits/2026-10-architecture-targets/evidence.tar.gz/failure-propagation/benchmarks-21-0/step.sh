mkdir -p .github/logs
./build/benchmarks/benchmark_runner --benchmark_format=json --benchmark_out=bench.json 2>&1 | tee .github/logs/benchmark.log
