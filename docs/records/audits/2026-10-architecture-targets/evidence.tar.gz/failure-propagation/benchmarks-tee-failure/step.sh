printf producer-out | tee absent-parent/command.log
