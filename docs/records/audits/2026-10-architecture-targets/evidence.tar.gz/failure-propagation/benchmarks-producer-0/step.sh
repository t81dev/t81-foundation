bash -c 'echo producer-out; echo producer-err >&2; exit 0' 2>&1 | tee command.log
printf reached > following-command
