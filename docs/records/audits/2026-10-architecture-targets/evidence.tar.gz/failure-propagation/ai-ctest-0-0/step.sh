ctest --test-dir build --output-on-failure --verbose \
  -R 't81_vm_tloadhash_conformance_test|t81_vm_tloadhash_decodefault_determinism_matrix_test' \
  2>&1 | tee build/ai-rfc0025/tloadhash-ctest.log
