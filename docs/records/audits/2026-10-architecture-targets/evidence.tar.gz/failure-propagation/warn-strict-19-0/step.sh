cmake --build build-warn-strict --parallel $(nproc) 2>&1 | tee warn-strict.log
