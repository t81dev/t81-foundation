mkdir -p build/ai-vm-trace
cmake --build build --target help > build/ai-cmake-targets.txt
if grep -qE '(^| )t81_vm_trace_test$' build/ai-cmake-targets.txt && \
   grep -qE '(^| )canonfs_axion_trace_test$' build/ai-cmake-targets.txt; then
  cmake --build build --target t81_vm_trace_test canonfs_axion_trace_test
  ctest --test-dir build --output-on-failure --verbose \
    -R 't81_vm_trace_test|canonfs_axion_trace_test' \
    2>&1 | tee build/ai-vm-trace/ai_vm_trace_ctest.log
else
  echo "❌ required VM trace targets not found (t81_vm_trace_test, canonfs_axion_trace_test)"
  exit 1
fi
python3 scripts/ci/check_ai_vm_trace_evidence.py \
  --out-dir build/ai-vm-trace \
  --ctest-log build/ai-vm-trace/ai_vm_trace_ctest.log
