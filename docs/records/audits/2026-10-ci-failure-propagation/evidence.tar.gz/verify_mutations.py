from pathlib import Path
import json,shutil,subprocess
repo=Path('/private/tmp/t81-ci-failure-propagation');out=Path('/private/tmp/t81-ci-integrity-evidence');rows=[]
for name in ['swallow-validator','conditional-producer']:
 root=out/('mutant-'+name)
 for folder in ['.github/workflows','scripts/ci']:(root/folder).mkdir(parents=True,exist_ok=True)
 for file in ['.github/workflows/ci.yml','.github/workflows/ai-experiments-ci.yml','scripts/ci/test_failure_propagation.py']:shutil.copy2(repo/file,root/file)
 if name=='swallow-validator':
  p=root/'.github/workflows/ci.yml';s=p.read_text();a='python3 scripts/governance/check_root_structure.py 2>&1 | tee -a .github/logs/spec-and-docs.log';assert s.count(a)==1;p.write_text(s.replace(a,a+' || true'))
 else:
  p=root/'.github/workflows/ai-experiments-ci.yml';s=p.read_text();a="cmake --build build --target help > build/ai-cmake-targets.txt\n        if grep -qE '(^| )t81_ai$' build/ai-cmake-targets.txt; then";b="if cmake --build build --target help | grep -qE '(^| )t81_ai$'; then";assert s.count(a)==1;p.write_text(s.replace(a,b))
 command=['python3',str(root/'scripts/ci/test_failure_propagation.py'),'--output-dir',str(root/'observed')]
 process=subprocess.run(command,capture_output=True,text=True);(root/'stdout.log').write_text(process.stdout);(root/'stderr.log').write_text(process.stderr)
 results=json.loads((root/'observed/results.json').read_text());failed=[x for x in results['results'] if not x['passed']]
 witness=next(x for x in failed if x['name']==('governance-first' if name=='swallow-validator' else 'ai-probe-0-help-failed-with-matching-output'))
 assert process.returncode==1 and witness['actual_exit']!=witness['expected_exit']
 rows.append(dict(mutation=name,process_exit=process.returncode,semantic_witness=witness,killed=True))
(out/'mutation-results.json').write_text(json.dumps(rows,indent=2)+'\n');print([(x['mutation'],x['semantic_witness']['expected_exit'],x['semantic_witness']['actual_exit']) for x in rows])
