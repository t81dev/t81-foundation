from pathlib import Path
import json,subprocess,yaml,shlex
repo=Path('/private/tmp/t81-ci-failure-propagation');out=Path('/private/tmp/t81-ci-integrity-evidence')
for name in ['ci.yml','ai-experiments-ci.yml']:(out/('before-'+name)).write_bytes((repo/'.github/workflows'/name).read_bytes())
workflow=yaml.safe_load((out/'before-ci.yml').read_text());rows=[]
for step in workflow['jobs']['spec-and-docs']['steps']:
 for line in step.get('run','').splitlines():
  if not line.strip().startswith('python3 ') or '| tee' not in line:continue
  command=line.split(' 2>&1 | tee',1)[0].strip()
  index=len(rows);direct=subprocess.run(shlex.split(command),cwd=repo,text=True,capture_output=True)
  log=out/f'baseline-{index:02}.log'
  pipeline=command+' 2>&1 | tee '+shlex.quote(str(log))
  old=subprocess.run(['bash','-e','-c',pipeline],cwd=repo,text=True,capture_output=True)
  rows.append(dict(step=step['name'],command=command,underlying_exit=direct.returncode,underlying_stdout=direct.stdout,underlying_stderr=direct.stderr,old_step_exit=old.returncode,log_exists=log.exists(),log_bytes=log.stat().st_size,log=log.name))
(out/'baseline.json').write_text(json.dumps(dict(base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),commands=rows),indent=2)+'\n')
print('Underlying commands',len(rows),'failures',sum(r['underlying_exit']!=0 for r in rows),'masked failures',sum(r['underlying_exit']!=0 and r['old_step_exit']==0 for r in rows))
for row in rows:
 if row['underlying_exit']:print(row['command'],row['underlying_exit'],row['old_step_exit'])
